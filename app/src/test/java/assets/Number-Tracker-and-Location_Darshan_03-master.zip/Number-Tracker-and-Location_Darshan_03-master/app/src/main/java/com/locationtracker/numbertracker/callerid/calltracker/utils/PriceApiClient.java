package com.locationtracker.numbertracker.callerid.calltracker.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.moderntoolsapp.mobilenumbertracker.Fuel.CityPrice;
import com.moderntoolsapp.mobilenumbertracker.Fuel.Extion;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Mayank Gupta on 29-06-2017.
 */

public class PriceApiClient {

    private String urlPetrol = "https://www.mypetrolprice.com/petrol-price-in-india.aspx";
    //private String urlDiesel = "http://www.mypetrolprice.com/diesel-price-in-india.aspx";
    private RequestQueue reqQueue;
    private LinkExtractor extractor;

    private String state, date;
    private Context ctx;

    private int arraySize = 0, count = 0;

    public static final String TAG = "Fuel Buddy";
    private OnSuccessListener onSuccessListener;

    public PriceApiClient(Context ctx) {
        reqQueue = Volley.newRequestQueue(ctx);
        this.ctx = ctx;
    }

    public interface OnSuccessListener{
        void onSuccess(HashMap<String, List<CityPrice>> hashMap);
    }

    public void getFuelPriceList(OnSuccessListener onSuccessListener) {
        this.onSuccessListener = onSuccessListener;
        StringRequest request = getRequest(urlPetrol);

        reqQueue.add(request);
    }

    private StringRequest getRequest(final String url) {
        final StringRequest stringReq = new StringRequest(Request.Method.GET, url,
                response -> {
                    extractor = new LinkExtractor();
                    extractor.execute(url);
                },
                error -> {
                    Toast.makeText(ctx, "Unable to fetch data. Please try again later.", Toast.LENGTH_SHORT).show();
                });


        stringReq.setTag(TAG);
        return stringReq;
    }

    private class LinkExtractor extends AsyncTask<String, String, Void> {
        HashMap<String, List<CityPrice>> hashMap=new HashMap<>();

        @Override
        protected Void doInBackground(String... params) {
            try {
                Document doc = Jsoup.connect(params[0]).timeout(20000).get();
                hashMap = Extion.INSTANCE.extract(doc);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(ctx, "Unable to fetch data. Please try again later.", Toast.LENGTH_SHORT).show();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if(onSuccessListener!=null)
                onSuccessListener.onSuccess(hashMap);
        }
    }
}
