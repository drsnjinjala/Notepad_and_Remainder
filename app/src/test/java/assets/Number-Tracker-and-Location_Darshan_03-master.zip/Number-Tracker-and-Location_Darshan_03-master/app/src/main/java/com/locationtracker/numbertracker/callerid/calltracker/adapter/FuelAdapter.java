package com.locationtracker.numbertracker.callerid.calltracker.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.moderntoolsapp.mobilenumbertracker.Fuel.CityPrice;

import java.util.List;

public class FuelAdapter extends RecyclerView.Adapter<FuelAdapter.ViewHolder> {

    private final Activity context;
    private List<CityPrice> cityPriceList;
    private LayoutInflater inflater;

    public FuelAdapter(Activity activity, List<CityPrice> cityPriceList) {
        this.context = activity;
        this.cityPriceList = cityPriceList;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_fuel_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CityPrice cityPrice = cityPriceList.get(position);
        holder.txtCityName.setText(cityPrice.getName());
        holder.txtPrice.setText(cityPrice.getPrice());
//        holder.ixiDown.setText(cityPrice.getArrow());
//        if (cityPrice.getArrow().equalsIgnoreCase("▼")) {
//            holder.ixiDown.setTextColor(Color.RED);
//        } else holder.ixiDown.setTextColor(Color.GREEN);
    }

    @Override
    public int getItemCount() {
        return cityPriceList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView txtCityName;
        private TextView txtPrice;
        private ImageView ixiDown;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtCityName = (TextView) itemView.findViewById(R.id.txtCityName);
            txtPrice = (TextView) itemView.findViewById(R.id.txtPrice);
            ixiDown = (ImageView) itemView.findViewById(R.id.ixiDown);
        }
    }
}
