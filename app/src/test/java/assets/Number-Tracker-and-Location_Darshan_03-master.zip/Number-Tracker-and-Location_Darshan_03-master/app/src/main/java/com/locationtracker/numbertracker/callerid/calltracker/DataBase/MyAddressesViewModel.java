package com.locationtracker.numbertracker.callerid.calltracker.DataBase;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class MyAddressesViewModel extends AndroidViewModel {
    private LiveData<List<MyAddresses>> allItems;
    private MyAddressesRepository repository;

    public MyAddressesViewModel(Application application) {
        super(application);
        MyAddressesRepository myAddressesRepository = new MyAddressesRepository(application);
        this.repository = myAddressesRepository;
        this.allItems = myAddressesRepository.getAllNotes();
    }

    public void insert(MyAddresses myAddresses) {
        this.repository.insert(myAddresses);
    }

    public void update(MyAddresses myAddresses) {
        this.repository.update(myAddresses);
    }

    public void delete(MyAddresses myAddresses) {
        this.repository.delete(myAddresses);
    }

    public void deleteAllNotes() {
        this.repository.deleteAllNotes();
    }

    public LiveData<List<MyAddresses>> getAllNotes() {
        return this.allItems;
    }
}
