package com.locationtracker.numbertracker.callerid.calltracker.ui.settings;

import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.widget.TextView;

import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivitySystemInfoBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import think.outside.the.box.handler.APIManager;

public class SystemInfoActivity extends ParentActivity {

    private ActivitySystemInfoBinding binding;
    private long total = 0;
    private static final String ERROR = null;
    private long free = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_system_info);

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
         binding.btnBack.setOnClickListener(view -> onBackPressed());

        initView();
    }

    private void initView() {
        updateInfo();
        Boolean.valueOf(Environment.getExternalStorageState().equals("mounted"));
    }

    private static boolean externalMemoryAvailable() {
        return !Environment.getExternalStorageState().equals("mounted");
    }

    private static String getAvailableInternalMemorySize() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        return formatSize((double) (((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize())));
    }

    private static String getTotalInternalMemorySize() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        return formatSize((double) (((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize())));
    }

    private static String getAvailableExternalMemorySize() {
        if (externalMemoryAvailable()) {
            return ERROR;
        }
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        return formatSize((double) (((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize())));
    }

    private static String getTotalExternalMemorySize() {
        if (externalMemoryAvailable()) {
            return ERROR;
        }
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        return formatSize((double) (((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize())));
    }

    private static String formatSize(double d) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        double d2 = d / 1048576.0d;
        double d3 = d / 1.073741824E9d;
        double d4 = d / 1.099511627776E12d;
        if (d4 > 1.0d) {
            return decimalFormat.format(d4).concat(" TB");
        }
        if (d3 > 1.0d) {
            return decimalFormat.format(d3).concat(" GB");
        }
        if (d2 > 1.0d) {
            return decimalFormat.format(d2).concat(" MB");
        }
        return decimalFormat.format(d).concat(" KB");
    }

    private void updateInfo() {
        getMemorySize();
        Runtime.getRuntime().totalMemory();
        Runtime.getRuntime().freeMemory();
        TextView textView = binding.ramSize;
        if (textView != null) {
            textView.setText(calSize((double) total));
        }
        if (binding.ramSize != null) {
            binding.ramSize.setText(calSize((double) free));
        }
        TextView textView2 = binding.ramUsed;
        if (textView2 != null) {
            textView2.setText(calSize((double) (total - free)));
        }
        TextView textView3 = binding.sdcardTotal;
        if (textView3 != null) {
            textView3.setText(getTotalInternalMemorySize());
        }
        TextView textView4 = binding.sdFree;
        if (textView4 != null) {
            textView4.setText(getAvailableInternalMemorySize());
        }
        TextView textView5 = binding.sdFree;
        if (textView5 != null) {
            textView5.setText(getAvailableExternalMemorySize());
        }
        TextView textView6 = binding.sdcardTotal;
        if (textView6 != null) {
            textView6.setText(getTotalExternalMemorySize());
        }
    }

    private String calSize(double d) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        double d2 = d / 1048576.0d;
        double d3 = d / 1.073741824E9d;
        double d4 = d / 1.099511627776E12d;
        if (d4 > 1.0d) {
            return decimalFormat.format(d4).concat(" TB");
        }
        if (d3 > 1.0d) {
            return decimalFormat.format(d3).concat(" GB");
        }
        if (d2 > 1.0d) {
            return decimalFormat.format(d2).concat(" MB");
        }
        return decimalFormat.format(d).concat(" KB");
    }

    private void getMemorySize() {
        Pattern compile = Pattern.compile("([a-zA-Z]+):\\s*(\\d+)");
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("/proc/meminfo", "r");
            while (true) {
                String readLine = randomAccessFile.readLine();
                if (readLine != null) {
                    Matcher matcher = compile.matcher(readLine);
                    if (matcher.find()) {
                        String group = matcher.group(1);
                        String group2 = matcher.group(2);
                        if (group.equalsIgnoreCase("MemTotal")) {
                            total = Long.parseLong(group2);
                        } else if (group.equalsIgnoreCase("MemFree") || group.equalsIgnoreCase("SwapFree")) {
                            free = Long.parseLong(group2);
                        }
                    }
                } else {
                    randomAccessFile.close();
                    total *= 1024;
                    free *= 1024;
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}