package com.locationtracker.numbertracker.callerid.calltracker.ui.Language;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.RcvLanguage2Binding;

import java.util.ArrayList;
import java.util.List;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.ViewHolder> {
    public Activity activity;
    private OnClickListener onClickListener;
    List<Language> languageList = new ArrayList();
    private static String selected;

    public String getLang() {
        return selected;
    }


    public interface OnClickListener {
        void onClickListener(int position, String codeKey, int image);
    }


    public LanguageAdapter(Activity activity2, OnClickListener onClickListener) {
        this.activity = activity2;
        this.onClickListener = onClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(RcvLanguage2Binding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Language language = languageList.get(position);
        holder.binding.languageName.setText(language.getName());
        holder.binding.languageIcon.setImageResource(language.getImg());
        if (language.getKey().equals(selected)) {
            holder.binding.rdbSelect.setChecked(true);
            holder.binding.languageName.setTypeface(null, Typeface.BOLD);
            holder.binding.language.setBackgroundResource(R.drawable.custom_item_language_2_selected);
        } else {
            holder.binding.rdbSelect.setChecked(false);
            holder.binding.languageName.setTypeface(null, Typeface.NORMAL);
            holder.binding.language.setBackgroundResource(R.drawable.custom_item_language_2);
        }
        holder.binding.languageName.setHorizontallyScrolling(true);
        holder.binding.languageName.setSelected(true);
        holder.itemView.setOnClickListener(view -> {
            onClickListener.onClickListener(position, language.getKey(), language.getImg());
        });

    }

    @Override
    public int getItemCount() {
        return languageList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RcvLanguage2Binding binding;

        public ViewHolder(RcvLanguage2Binding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public final void updateData(ArrayList<Language> data) {
        this.languageList.clear();
        this.languageList.addAll(data);
        notifyDataSetChanged();
    }

    public final void updatePosition(String i) {
        selected = i;
        notifyDataSetChanged();
    }


}
