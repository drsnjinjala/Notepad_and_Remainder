package com.locationtracker.numbertracker.callerid.calltracker.ui.Language

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.PagerAdapter
import com.locationtracker.numbertracker.callerid.calltracker.R
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityIntroBinding
import com.locationtracker.numbertracker.callerid.calltracker.ui.defaults.PermissionActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.showInter
import think.outside.the.box.util.TinyDB


class IntroScreen : ParentActivity() {
    private lateinit var binding: ActivityIntroBinding
    private var myViewPagerAdapter: MyViewPagerAdapter? = null
    private var layouts: IntArray = intArrayOf(R.layout.intro1, R.layout.intro2, R.layout.intro3)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setLightTheme(true)
        binding = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        APIManager.showTopSmallNative(binding.adContainer)
        myViewPagerAdapter = MyViewPagerAdapter()
        binding.viewpager.adapter = myViewPagerAdapter
        binding.indicator.setViewPager(binding.viewpager)
        binding.btnNext.setOnClickListener { v: View? ->
            val current = getItem(+1)
            if (current < layouts.size) {
                if (current == 2) {
                    APIManager.showInter(this@IntroScreen, false, object : AdsCallback {
                        override fun onClose(isfail: Boolean) {
                            TinyDB(this@IntroScreen).putBoolean("AppOpenFirst", true)
                            binding.viewpager.currentItem = current
                        }
                    })
                } else binding.viewpager.currentItem = current
            } else {
                launchHomeScreen()
            }
        }
    }

    private fun getItem(i: Int): Int {
        return binding.viewpager.currentItem + i
    }

    private fun launchHomeScreen() {
        showInter(this@IntroScreen, false, object : AdsCallback {
            override fun onClose(isfail: Boolean) {
                TinyDB(this@IntroScreen).putBoolean("AppOpenFirst", true)
                startActivity(Intent(this@IntroScreen, PermissionActivity::class.java))
                finish()
            }
        })
    }

    inner class MyViewPagerAdapter : PagerAdapter() {
        private lateinit var layoutInflater: LayoutInflater
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val view = layoutInflater.inflate(layouts[position], container, false)
            container.addView(view)
            return view
        }

        override fun getCount(): Int {
            return layouts.size
        }

        override fun isViewFromObject(view: View, obj: Any): Boolean {
            return view === obj
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            val view = `object` as View
            container.removeView(view)
        }
    }

    override fun onBackPressed() {
        finish()
    }
}