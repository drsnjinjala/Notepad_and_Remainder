package com.locationtracker.numbertracker.callerid.calltracker.ui.fragment;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.kwabenaberko.openweathermaplib.BuildConfig;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MapUtility;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.FragmentShareLocationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.dialog.SaveAddressDialog;

import java.io.IOException;
import java.util.List;

import think.outside.the.box.handler.APIManager;

public class FragmentShareLocation extends Fragment implements View.OnClickListener, OnMapReadyCallback {

    private FragmentShareLocationBinding binding;
    private static final String TAG = "FragmentShareLocation";
    private FusedLocationProviderClient fusedLocationProviderClient;
    private double mLat = -1.0d;
    private double mLng = -1.0d;
    private GoogleMap mMap;
    private int mapType = 2;
    private long pressedTime;
    private boolean secondClick = false;
    private boolean isZooming = true;
    private Location lastKnownLocation;
    Animation fabOpen, fabClose, rotateForward, rotateBackward;
    private boolean isOpen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentShareLocationBinding.inflate(inflater, container, false);
        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

     //   APIManager.showBanner(binding.ads65);
        binding.btnBack.setOnClickListener(view1 -> getActivity().onBackPressed());

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) getActivity());
        ((SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map_view_share_loc)).getMapAsync(this);

        fabOpen = AnimationUtils.loadAnimation(requireContext(), R.anim.fab_open);
        fabClose = AnimationUtils.loadAnimation(requireContext(), R.anim.fab_close);
        rotateForward = AnimationUtils.loadAnimation(requireContext(), R.anim.rotate_forward);
        rotateBackward = AnimationUtils.loadAnimation(requireContext(), R.anim.rotate_backward);

        binding.addFab.setOnClickListener(view1 -> animateFab());

        initView();
    }

    private void animateFab() {
        if (isOpen) {
            binding.addFab.startAnimation(rotateForward);
            binding.imgZoomOut.startAnimation(fabClose);
            binding.imgZoomIn.startAnimation(fabClose);
            binding.imgMyLocation.startAnimation(fabClose);
            binding.imgZoomOut.setClickable(false);
            binding.imgZoomIn.setClickable(false);
            binding.imgMyLocation.setClickable(false);
            isOpen = false;
        } else {
            binding.addFab.startAnimation(rotateBackward);
            binding.imgZoomOut.startAnimation(fabOpen);
            binding.imgZoomIn.startAnimation(fabOpen);
            binding.imgMyLocation.startAnimation(fabOpen);
            binding.imgZoomOut.setClickable(true);
            binding.imgZoomIn.setClickable(true);
            binding.imgMyLocation.setClickable(true);
            isOpen = true;
        }
    }

    private void initView() {
        binding.layoutSearch.setOnClickListener(this);
        binding.imgSearchAddress.setOnClickListener(this);
        binding.imgZoomOut.setOnClickListener(this);
        binding.imgZoomIn.setOnClickListener(this);
        binding.imgMyLocation.setOnClickListener(this);
        binding.imgMapType.setOnClickListener(this);
        setGridOnClickEvent(binding.gridShareLoc);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgMyLocation:
                showCurrentLocationOnMap();
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.imgZoomIn:
                GoogleMap googleMap = this.mMap;
                if (googleMap != null) {
                    googleMap.animateCamera(CameraUpdateFactory.zoomTo(googleMap.getCameraPosition().zoom + 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.imgZoomOut:
                GoogleMap googleMap2 = this.mMap;
                if (googleMap2 != null) {
                    googleMap2.animateCamera(CameraUpdateFactory.zoomTo(googleMap2.getCameraPosition().zoom - 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.img_map_type:
                GoogleMap googleMap3 = this.mMap;
                if (googleMap3 != null) {
                    int i = this.mapType;
                    if (i == 1) {
                        googleMap3.setMapType(2);
                        this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_stander)));
                        this.mapType = 2;
                    } else if (i == 2) {
                        googleMap3.setMapType(1);
                        this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_stander)));
                        this.mapType = 3;
                    } else if (i == 3) {
                        googleMap3.setMapType(1);
                        this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_json)));
                        this.mapType = 4;
                    } else if (i == 4) {
                        googleMap3.setMapType(3);
                        this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_stander)));
                        this.mapType = 1;
                    }
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.img_search_address:
                if (this.pressedTime + 2000 > System.currentTimeMillis()) {
                    Log.d(TAG, "onClick: do nothing when double click");
                } else if (binding.tvAddress.getText().toString() != null) {
                    goToLocationFromAddress(binding.tvAddress.getText().toString());
                }
                this.pressedTime = System.currentTimeMillis();
                return;

            case R.id.layoutSearch:
                binding.tvAddress.setText((CharSequence) null);
                return;
            default:
                return;
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.mMap = googleMap;
        googleMap.clear();
        this.mMap.setMapType(2);
        this.mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {


            @Override
            public void onMapClick(LatLng latLng) {
                if (!MapUtility.isNetworkAvailable(getContext())) {
                    Variables.showToast(getContext(), "Please Connect to Internet");
                    return;
                }
                mMap.clear();
                addMarker("", latLng.latitude, latLng.longitude);
                mLat = latLng.latitude;
                mLng = latLng.longitude;
                MapUtility.getAddressFromLatLng(getContext(), latLng.latitude, latLng.longitude, binding.tvAddressNew, true);
            }
        });
        updateLocationUI();
        getDeviceLocation();
    }

    private void updateLocationUI() {
        if (this.mMap != null) {
            try {
                if (MapUtility.checkAndRequestPermissions(getContext(), getActivity())) {
                    this.mMap.setMyLocationEnabled(true);
                    this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                    return;
                }
                this.mMap.setMyLocationEnabled(false);
                this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                this.lastKnownLocation = null;
                Variables.checkPermission(getActivity());
            } catch (SecurityException e) {
                Log.e("Exception: %s", e.getMessage());
            }
        }
    }

    private void getDeviceLocation() {
        try {
            if (MapUtility.checkAndRequestPermissions(getContext(), getActivity())) {
                this.fusedLocationProviderClient.getLastLocation().addOnCompleteListener(getActivity(), new OnCompleteListener<Location>() {


                    @Override
                    public void onComplete(Task<Location> task) {
                        if (task.isSuccessful()) {
                            lastKnownLocation = task.getResult();
                            if (lastKnownLocation != null) {
                                addMarker("", lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                                MapUtility.getAddressFromLatLng(getContext(), lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude(), binding.tvAddressNew, false);
                                mLat = lastKnownLocation.getLatitude();
                                mLng = lastKnownLocation.getLongitude();
                            }
                        } else if (MapUtility.defaultLocation != null) {
                            MapUtility.getAddressFromLatLng(getContext(), MapUtility.defaultLocation.latitude, MapUtility.defaultLocation.longitude, binding.tvAddressNew, false);
                            mLat = MapUtility.defaultLocation.latitude;
                            mLng = MapUtility.defaultLocation.longitude;
                        } else {
                            mMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }

    private void setGridOnClickEvent(GridLayout gridLayout2) {
        for (int i = 0; i < gridLayout2.getChildCount(); i++) {
            int finalI = i;
            ((LinearLayout) gridLayout2.getChildAt(i)).setOnClickListener(new View.OnClickListener() {


                public void onClick(View view) {

                    if (finalI == 0) {
                        if (!(mLat == -1.0d || mLng == -1.0d)) {
                            sharePin(mLat + "," + mLng);
                        }
                    } else if (finalI == 1) {
                        if (binding.tvAddressNew != null) {
                            try {
                                ((ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Address ", binding.tvAddress.getText().toString()));
//                                Snackbar.make(getView(), "Address Copied To Clipboard", BaseTransientBottomBar.LENGTH_SHORT).show();
                                Toast toast = Toast.makeText(requireContext(), "Address Copied To Clipboard", Toast.LENGTH_SHORT);
                                toast.setGravity(Gravity.BOTTOM, 0, 0);
                                toast.setDuration(Toast.LENGTH_SHORT);
                                toast.show();

                            } catch (Exception e) {
                                e.getMessage();
                            }
                        } else {
                            Toast.makeText(getContext(), "Select Location First...", Toast.LENGTH_SHORT).show();
                        }
                    } else if (finalI == 2) {
                        if (!(binding.tvAddress.getText().toString() == null || mLat == -1.0d || mLng == -1.0d)) {
                            new SaveAddressDialog(binding.tvAddressNew.getText().toString(), mLat, mLng).show(getChildFragmentManager(), "savedDialog");
                        }
                    } else if (!(finalI != 3 || binding.tvAddress.getText().toString() == null || mLat == -1.0d || mLng == -1.0d)) {
                        String charSequence = binding.tvAddressNew.getText().toString();
                        shareAddress(charSequence, mLat + "," + mLng);
                    }
                    if (secondClick) {
                        secondClick = false;
                    } else {
                        secondClick = true;
                    }
                }
            });
        }
    }


    private void showCurrentLocationOnMap() {
        if (MapUtility.checkAndRequestPermissions(getContext(), getActivity())) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            if (fusedLocationProviderClient == null) {
                return;
            }
            Task<Location> lastLocation = this.fusedLocationProviderClient.getLastLocation();
            lastLocation.addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {


                public void onSuccess(Location location) {
                    if (location != null) {
                        addMarker("", location.getLatitude(), location.getLongitude());
                        mLat = location.getLatitude();
                        mLng = location.getLongitude();
                        MapUtility.getAddressFromLatLng(getContext(), location.getLatitude(), location.getLongitude(), binding.tvAddressNew, false);
                        return;
                    }
                    Variables.showToast(getContext(), "Location not Available");
                }
            });
            lastLocation.addOnFailureListener(new OnFailureListener() {


                @Override
                public void onFailure(Exception exc) {
                    Variables.showToast(getContext(), "Location Not Available");
                }
            });
        }
    }

    public void goToLocationFromAddress(String str) {
        try {
            List<Address> fromLocationName = new Geocoder(getContext()).getFromLocationName(str, 5);
            if (fromLocationName != null) {
                try {
                    Address address = fromLocationName.get(0);
                    addMarker("", address.getLatitude(), address.getLongitude());
                    MapUtility.getAddressFromLatLng(getContext(), address.getLatitude(), address.getLongitude(), binding.tvAddressNew, true);
                    this.mLat = address.getLatitude();
                    this.mLng = address.getLongitude();
                    hideKeyboard(getContext());
                } catch (IndexOutOfBoundsException unused) {
                    Toast.makeText(getContext(), "Location isn't available", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addMarker(String str, double d, double d2) {
        CameraUpdate cameraUpdate;
        String str2 = "Latitude: " + String.format("%.2f", Double.valueOf(d)) + ", Longitude: " + String.format("%.2f", Double.valueOf(d2));
        LatLng latLng = new LatLng(d, d2);
        GoogleMap googleMap = this.mMap;
        if (googleMap != null) {
            try {
                googleMap.clear();
                MarkerOptions title = new MarkerOptions().position(latLng).title(str2);
                if (this.isZooming) {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 15.0f);
                } else {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, this.mMap.getCameraPosition().zoom);
                }
                this.mMap.animateCamera(cameraUpdate);
                this.mMap.addMarker(title).showInfoWindow();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        str.equals("search");
    }

    public Bitmap resizeMapIcons(String str, int i, int i2) {
        return Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(str, "drawable", getActivity().getPackageName())), i, i2, false);
    }

    public static void hideKeyboard(Context context) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputMethodManager.isActive()) {
                inputMethodManager.hideSoftInputFromWindow(((Activity) context).getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void shareAddress(String str, String str2) {
        String str3 = "Address:\n" + str + "\n--------------------------------\nClick to navigate:\nhttp://www.google.com/maps?daddr=" + str2 + "\n--------------------------------\n";
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
            intent.putExtra("android.intent.extra.TEXT", str3 + ("\nLet me recommend you this application\n\n" + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n"));
            startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sharePin(String str) {
        String str2 = "Click to navigate:\nhttp://www.google.com/maps?daddr=" + str;
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
            intent.putExtra("android.intent.extra.TEXT", str2);
            startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}