package com.locationtracker.numbertracker.callerid.calltracker.ui.recharge;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityRechargeBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo.LocationInfoMainActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import think.outside.the.box.handler.APIManager;

public class RechargeActivity extends ParentActivity {

    private ActivityRechargeBinding binding;
    public static String circle;
    public static String circle1;
    public static String operator;
    String[] Operator = {"Airtel", "Jio", "Vodafone", "Idea", "BSNL", "MTNL", "Tata Docomo", "T24"};
    String[] OperatorShort = {"Airtel", "Jio", "Vodafone", "Idea", "BSNL", "MTNL", "Docomo", "T24"};
    String[] State;
    String[] StateShort;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_recharge);

        binding.btnBack.setOnClickListener(view -> onBackPressed());

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);

        this.State = new String[]{"AndhraPradesh", "Assam", "Bihar", "Chennai", "Delhi NCR", "Gujarat", "Himachal Pradesh", "Haryana", "Jammu-Kashmir", "Karnataka", "Kerala", "Kolkata", "Goa", "Madhya Pradesh", "Mumbai", "North East", "North East 1", "North East 2", "Orrisa", "Punjab", "Rajasthan", "Tamil Nadu", "Uttar Pradesh East", "Uttar Pradesh West", "West Bengal"};
        this.StateShort = new String[]{"AP", "AS", "BR", "Chennai", "Delhi", "GJ", "HP", "HR", "JK", "KA", "KL", "Kolkata", "MH", "MP", "Mumbai", "NE", "NE1", "NE2", "OR", "PB", "RJ", "TN", "UPE", "UPW", "WB"};


        ArrayAdapter arrayAdapter = new ArrayAdapter(this, (int) R.layout.rv_spiner_item, this.Operator);
        arrayAdapter.setDropDownViewResource(17367049);
        binding.operatorspinner.setAdapter(arrayAdapter);

        ArrayAdapter arrayAdapter2 = new ArrayAdapter(this, (int) R.layout.rv_spiner_item, this.State);
        arrayAdapter2.setDropDownViewResource(17367049);
        binding.locSpinner.setAdapter(arrayAdapter2);


        binding.btnCheckPlan.setOnClickListener(view -> {
            operator = binding.operatorspinner.getText().toString();
            circle1 = (String) binding.locSpinner.getText().toString();
            circle = binding.locSpinner.getText().toString();
            if (operator.equals("") || circle1.equals("")) {
                Toast.makeText(RechargeActivity.this, "" + R.string.select_operator, Toast.LENGTH_SHORT).show();
                return;
            }
           APIManager.showInter(RechargeActivity.this, false, isfail -> {
                Intent intent = new Intent(this, RechargePlanActivity.class);
                intent.putExtra("a", RechargeActivity.operator);
                intent.putExtra("b", RechargeActivity.circle1);
                intent.putExtra("c", RechargeActivity.circle);
                startActivity(intent);
             });
        });
    }


}