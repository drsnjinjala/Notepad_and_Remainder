package com.locationtracker.numbertracker.callerid.calltracker.model;

public class RechargePlan {
    private String category;
    private String detail;
    private String keywords;
    private Integer  price;
    private Double  talktime;
    private String updated;
    private String validity;

    public RechargePlan(String category, String detail, String keywords, Integer price, Double talktime, String updated, String validity) {
        this.category = category;
        this.detail = detail;
        this.keywords = keywords;
        this.price = price;
        this.talktime = talktime;
        this.updated = updated;
        this.validity = validity;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Double getTalktime() {
        return talktime;
    }

    public void setTalktime(Double talktime) {
        this.talktime = talktime;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }
}
