package com.locationtracker.numbertracker.callerid.calltracker.ui.defaults

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import com.locationtracker.numbertracker.callerid.calltracker.R
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivitySplashBinding
import com.locationtracker.numbertracker.callerid.calltracker.ui.Language.BaseActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.Language.LanguageActivity
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.callback.SplashCallback
import think.outside.the.box.handler.APIManager.getExtraData
import think.outside.the.box.handler.APIManager.initializeSplash
import think.outside.the.box.handler.APIManager.showSplashAD


class SplashActivity : BaseActivity() {

    var abc = true

    private var binding: ActivitySplashBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)


        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
//
//        Aanibrothers.subscribeNotification(this)
//        Aanibrothers.configureNotification(
//            this,
//            resources.getString(R.string.app_name),
//            R.drawable.vector,
//            R.color.transParent
//        )

        binding?.progressBar?.max = 15000
        object : CountDownTimer(15000, 10) {
            override fun onTick(millisUntilFinished: Long) {
                binding?.progressText?.text = "" + (15 - (15000 - millisUntilFinished) / 1000)
                binding?.progressBar?.progress = 15000 - millisUntilFinished.toInt()
            }

            override fun onFinish() {
                binding?.progressText?.text = "0"
                binding?.progressBar?.progress = 0
            }
        }.start()

        initializeSplash(this, object : SplashCallback {
            override fun onSuccess() {
                showSplashAD(this@SplashActivity, object : AdsCallback {
                    override fun onClose(b: Boolean) {
                        try {
                            val s = getExtraData()!!.getString("AppStatus")
                            if (s == "OFF") {
                                Handler(Looper.getMainLooper()).postDelayed({
                                    val intent =
                                        Intent(this@SplashActivity, ComingSoonActivity::class.java)
                                    startActivity(intent)
                                    finish()
                                }, 2000)
                                return
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        val i = Intent(this@SplashActivity, LanguageActivity::class.java)
                        startActivity(i)
                        finish()
                    }
                })
            }
        }, true)
    }
}
