package com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MapUtility;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityRouteFinderBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import think.outside.the.box.handler.APIManager;

public class RouteFinderActivity extends ParentActivity implements View.OnClickListener, OnMapReadyCallback {

    private ActivityRouteFinderBinding binding;
    private static final String TAG = "RouteFinderActivity";
    private double mLatDestination = -1.0d;
    private double mLatOrigin = -1.0d;
    private double mLngDestination = -1.0d;
    private double mLngOrigin = -1.0d;
    private GoogleMap mMap;
    private long pressedTime;
    private boolean secondClick = false;
    protected LatLng start;
    private boolean isZooming = true;
    private Location lastKnownLocation;
    protected LatLng end;
    private FusedLocationProviderClient fusedLocationProviderClient;
    Animation fabOpen, fabClose, rotateForward, rotateBackward;
    private boolean isOpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_route_finder);

        this.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_view_route_finder)).getMapAsync(this);

        fabOpen = AnimationUtils.loadAnimation(this, R.anim.fab_open);
        fabClose = AnimationUtils.loadAnimation(this, R.anim.fab_close);
        rotateForward = AnimationUtils.loadAnimation(this, R.anim.rotate_forward);
        rotateBackward = AnimationUtils.loadAnimation(this, R.anim.rotate_backward);

        binding.addFab.setOnClickListener(view -> animateFab());

        binding.btnBack.setOnClickListener(view -> {
            onBackPressed();
        });

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);

        initView();
    }

    private void animateFab() {
        if (isOpen) {
            binding.addFab.startAnimation(rotateForward);
            binding.imgZoomOut.startAnimation(fabClose);
            binding.imgZoomIn.startAnimation(fabClose);
            binding.imgMyLocation.startAnimation(fabClose);
            binding.imgZoomOut.setClickable(false);
            binding.imgZoomIn.setClickable(false);
            binding.imgMyLocation.setClickable(false);
            isOpen = false;
        } else {
            binding.addFab.startAnimation(rotateBackward);
            binding.imgZoomOut.startAnimation(fabOpen);
            binding.imgZoomIn.startAnimation(fabOpen);
            binding.imgMyLocation.startAnimation(fabOpen);
            binding.imgZoomOut.setClickable(true);
            binding.imgZoomIn.setClickable(true);
            binding.imgMyLocation.setClickable(true);
            isOpen = true;
        }
    }

    private void initView() {
        binding.layoutSearch1.setOnClickListener(this);
        binding.layoutSearch2.setOnClickListener(this);
        binding.imgSearchAddress1.setOnClickListener(this);
        binding.imgSearchAddress2.setOnClickListener(this);
        binding.imgZoomIn.setOnClickListener(this);
        binding.imgZoomOut.setOnClickListener(this);
        binding.imgMyLocation.setOnClickListener(this);
        binding.btnNavigation.setOnClickListener(this);
        binding.imgEd1.setOnClickListener(this);
        binding.imgEd2.setOnClickListener(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.mMap = googleMap;
        googleMap.clear();
        this.mMap.setMapType(1);
        updateLocationUI();
        getDeviceLocation();
    }

    private void updateLocationUI() {
        if (this.mMap != null) {
            try {
                if (MapUtility.checkAndRequestPermissions(this, this)) {
                    this.mMap.setMyLocationEnabled(true);
                    this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                    return;
                }
                this.mMap.setMyLocationEnabled(false);
                this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                this.lastKnownLocation = null;
                Variables.checkPermission(this);
            } catch (SecurityException e) {
                Log.e("Exception: %s", e.getMessage());
            }
        }
    }

    private void getDeviceLocation() {
        try {
            if (MapUtility.checkAndRequestPermissions(this, this)) {
                this.fusedLocationProviderClient.getLastLocation().addOnCompleteListener(this, new OnCompleteListener<Location>() {

                    @Override
                    public void onComplete(Task<Location> task) {
                        if (task.isSuccessful()) {
                            lastKnownLocation = task.getResult();
                            if (lastKnownLocation != null) {
                                CameraUpdate newLatLngZoom = CameraUpdateFactory.newLatLngZoom(new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude()), 15.0f);
                                if (mMap != null) {
                                    mMap.animateCamera(newLatLngZoom);
                                }
                            }
                        } else if (MapUtility.defaultLocation != null) {
                            Log.d(TAG, "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            CameraUpdate newLatLngZoom2 = CameraUpdateFactory.newLatLngZoom(new LatLng(MapUtility.defaultLocation.latitude, MapUtility.defaultLocation.longitude), 15.0f);
                            if (mMap != null) {
                                mMap.animateCamera(newLatLngZoom2);
                            }
                        } else {
                            Log.d(TAG, "Current location is null and default location cannot get .");
                            Log.e(TAG, "Exception: %s", task.getException());
                            if (mMap != null) {
                                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                            }
                        }
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }

    public void goToLocationFromAddressOrigin(String str) {
        try {
            List<Address> fromLocationName = new Geocoder(this).getFromLocationName(str, 5);
            if (fromLocationName != null) {
                try {
                    Address address = fromLocationName.get(0);
                    addMarker("origin", address.getLatitude(), address.getLongitude());
                    MapUtility.getAddressFromLatLng(this, address.getLatitude(), address.getLongitude(), binding.tvAddress1, true);
                    this.mLatOrigin = address.getLatitude();
                    this.mLngOrigin = address.getLongitude();
                    hideKeyboard(this);
                    EditText editText = binding.tvAddress1;
                    editText.setSelection(editText.getText().length());
                    this.start = new LatLng(address.getLatitude(), address.getLongitude());
                    setNavigationButtonStatus();
                } catch (IndexOutOfBoundsException unused) {
                    Toast.makeText(this, "Origin Location isn't available", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToLocationFromAddressDestination(String str) {
        try {
            List<Address> fromLocationName = new Geocoder(this).getFromLocationName(str, 5);
            if (fromLocationName != null) {
                try {
                    Address address = fromLocationName.get(0);
                    addMarker("", address.getLatitude(), address.getLongitude());
                    MapUtility.getAddressFromLatLng(this, address.getLatitude(), address.getLongitude(), binding.tvAddress2, true);
                    this.mLatDestination = address.getLatitude();
                    this.mLngDestination = address.getLongitude();
                    hideKeyboard(this);
                    EditText editText = this.binding.tvAddress2;
                    editText.setSelection(editText.getText().length());
                    this.end = new LatLng(address.getLatitude(), address.getLongitude());
                    setNavigationButtonStatus();
                } catch (IndexOutOfBoundsException unused) {
                    Toast.makeText(this, "Destination Location isn't available", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("NonConstantResourceId")
    public void onClick(View view) {
        getSharedPreferences(Variables.pref_name, 0).getString(Variables.interstitial_am_id, "");
        switch (view.getId()) {
            case R.id.btn_navigation:
                if (this.mLatOrigin == -1.0d && this.mLngOrigin == -1.0d) {
                    Toast.makeText(this, "please select starting address...", Toast.LENGTH_SHORT).show();
                    return;
                } else if (this.mLatDestination == -1.0d && this.mLngDestination == -1.0d) {
                    Toast.makeText(this, "please select destination address...", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString(Variables.KEY, Variables.KEY_ROUTE_FINDER);
                    bundle.putDouble(Variables.KEY_LAT_ORG, this.mLatOrigin);
                    bundle.putDouble(Variables.KEY_LNG_ORG, this.mLngOrigin);
                    bundle.putDouble(Variables.KEY_LAT_DES, this.mLatDestination);
                    bundle.putDouble(Variables.KEY_LNG_DES, this.mLngDestination);
                APIManager.showInter(RouteFinderActivity.this, false, isfail -> {
                        Intent intent = new Intent(this, NavigateRouteActivity.class);
                        intent.putExtras(bundle);
                        startActivity(intent);
                     });
                    return;
                }

            case R.id.imgMyLocation:
                showCurrentLocationOnMap();
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }

            case R.id.imgZoomIn:
                GoogleMap googleMap = this.mMap;
                if (googleMap != null) {
                    googleMap.animateCamera(CameraUpdateFactory.zoomTo(googleMap.getCameraPosition().zoom + 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.imgZoomOut:
                GoogleMap googleMap2 = this.mMap;
                if (googleMap2 != null) {
                    googleMap2.animateCamera(CameraUpdateFactory.zoomTo(googleMap2.getCameraPosition().zoom - 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.img_ed1:
                selectCurrentLocationOnMap();
                return;
            case R.id.img_ed2:
                Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
                intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", "en-US");
                try {
                    startActivityForResult(intent2, 11);
                    return;
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(getApplicationContext(), "This device doesn't support Speech to Text", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.img_search_address1:
                if (this.pressedTime + 2000 > System.currentTimeMillis()) {
                    Log.d(TAG, "onClick: do nothing when double click");
                } else if (binding.tvAddress1.getText() != null && !binding.tvAddress1.getText().toString().isEmpty()) {
                    goToLocationFromAddressOrigin(binding.tvAddress1.getText().toString());
                }
                this.pressedTime = System.currentTimeMillis();
                return;
            case R.id.img_search_address2:
                if (this.pressedTime + 2000 > System.currentTimeMillis()) {
                    Log.d(TAG, "onClick: do nothing when double click");
                } else if (binding.tvAddress2.getText() != null && !binding.tvAddress2.getText().toString().isEmpty()) {
                    goToLocationFromAddressDestination(binding.tvAddress2.getText().toString());
                }
                this.pressedTime = System.currentTimeMillis();
                return;
            case R.id.layoutSearch1:
                binding.tvAddress1.setText((CharSequence) null);
                return;
            case R.id.layoutSearch2:
                binding.tvAddress2.setText((CharSequence) null);
                return;
            default:
        }
    }

    private void selectCurrentLocationOnMap() {
        if (MapUtility.checkAndRequestPermissions(this, this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            if (fusedLocationProviderClient == null) {
                return;
            }
            Task<Location> lastLocation = this.fusedLocationProviderClient.getLastLocation();
            lastLocation.addOnSuccessListener(this, new OnSuccessListener<Location>() {
                public void onSuccess(Location location) {
                    if (location != null) {
                        addMarker("origin", location.getLatitude(), location.getLongitude());
                        mLatOrigin = location.getLatitude();
                        mLngOrigin = location.getLongitude();
                        MapUtility.getAddressFromLatLng(RouteFinderActivity.this, location.getLatitude(), location.getLongitude(), binding.tvAddress1, false);
                        binding.tvAddress1.setSelection(binding.tvAddress1.getText().length());
                        start = new LatLng(location.getLatitude(), location.getLongitude());
                        setNavigationButtonStatus();
                        return;
                    }
                    Variables.showToast(RouteFinderActivity.this, "Location not Available");
                }
            });
            lastLocation.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception exc) {
                    Variables.showToast(RouteFinderActivity.this, "Location Not Available");
                }
            });
        }
    }

    private void showCurrentLocationOnMap() {
        if (MapUtility.checkAndRequestPermissions(this, this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            Task<Location> lastLocation = this.fusedLocationProviderClient.getLastLocation();
            lastLocation.addOnSuccessListener(this, new OnSuccessListener<Location>() {
                public void onSuccess(Location location) {
                    if (location != null) {
                        CameraUpdate newLatLngZoom = CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 15.0f);
                        if (mMap != null) {
                            mMap.animateCamera(newLatLngZoom);
                            return;
                        }
                        return;
                    }
                    Variables.showToast(RouteFinderActivity.this, "Location not Available");
                }
            });
            lastLocation.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception exc) {
                    Variables.showToast(RouteFinderActivity.this, "Location Not Available");
                }
            });
        }
    }

    private void addMarker(String str, double d, double d2) {
        MarkerOptions markerOptions;
        CameraUpdate cameraUpdate;
        LatLng latLng = new LatLng(d, d2);
        GoogleMap googleMap = this.mMap;
        if (googleMap != null) {
            try {
                googleMap.clear();
                if (str.equals("origin")) {
                    MarkerOptions position = new MarkerOptions().position(latLng);
                    markerOptions = position.title(d + "," + d2).icon(BitmapDescriptorFactory.fromBitmap(resizeMapIcons("marker_origin", 100, 100)));
                } else {
                    MarkerOptions position2 = new MarkerOptions().position(latLng);
                    markerOptions = position2.title(d + "," + d2);
                }
                if (this.isZooming) {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 15.0f);
                } else {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, this.mMap.getCameraPosition().zoom);
                }
                this.mMap.animateCamera(cameraUpdate);
                this.mMap.addMarker(markerOptions);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public Bitmap resizeMapIcons(String str, int i, int i2) {
        return Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(str, "drawable", getPackageName())), i, i2, false);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null && i == 11) {
            ArrayList<String> stringArrayListExtra = intent.getStringArrayListExtra("android.speech.extra.RESULTS");
            if (stringArrayListExtra.size() > 0) {
                try {
                    Log.e(TAG, "onActivityResult: addreess   " + stringArrayListExtra.get(0));
                    goToLocationFromAddressDestination(stringArrayListExtra.get(0));
                } catch (Exception e) {
                    Log.e(TAG, "Exception While Searching:" + e.getMessage());
                    Toast.makeText(this, "Error While Searching For Endpoint", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "We had a failure to communicate.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void hideKeyboard(Context context) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
            if (inputMethodManager.isActive()) {
                inputMethodManager.hideSoftInputFromWindow(((Activity) context).getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    private void setNavigationButtonStatus() {
        if (this.mLatOrigin == -1.0d || this.mLngOrigin == -1.0d || this.mLatDestination == -1.0d || this.mLngDestination == -1.0d) {
            binding.btnNavigation.setEnabled(false);
        } else {
            binding.btnNavigation.setEnabled(true);
        }
    }


}