package com.locationtracker.numbertracker.callerid.calltracker.ui.bank;

import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.BankListAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.FBNativeAdAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityBankInformationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import think.outside.the.box.handler.APIManager;

public class BankInformationActivity extends ParentActivity {

    private ActivityBankInformationBinding binding;
    static final String[] bank_care = {"18004253800", "18001024455", "18002001947", "18002001911",
            "18004254332", "1800226747", "18002095577", "18602662666", "18002000", "18001802222",
            "18002336427", "18004250018", "1800220229", "18004253555", "18001030123", "18001030123",
            "18004255885", "18008431800", "1800446630", "18001034722", "18004251199", "18004254445",
            "18004209900", "18602001916", "1800112224", "1800226061", "18004251515", "18002000269",
            "18002334526", "00442476842100", "180042500000", "01147472100", "1800221908", "1800225087",
            "1800229999", "18004253555", "18003455000", "18001806005", "18001236601", "18004255566",
            "08026639966", "18004251747", "18003450345", "18004251444"};
    static final String[] bank_inquiry = {"09223766666", "09223011311", "18008431122", "09222250000",
            "18002703333", "18004252484", "18004195959", "18002740110", "09840909000", "18001802222",
            "09289356677", "09015483483", "09015135135", "09268892688", "09278792787", "09278792787",
            "18002665555", "09223008488", "1800446630", "18001034722", "8431900900", "18004254445",
            "18004259900", "09266292666", "1800112224", "09224150150", "09223011300", "18002000269",
            "09222281818", "18002336565", "09289592895", "09212438888", "1800221908", "1800225087",
            "9223040000", "1800443555", "18003451212", "09223866666", "18001236601", "09223866666",
            "09664552255", "08067747700", "09015431345", "18004251445"};
    static final String[] bankName = {" State Bank Of India ", " Bank Of Baroda ", " IDBI Bank ",
            " Central Bank Of India ", " HDFC Bank ", " Citi Bank ", " Axis Bank ",
            " Kotak Mahindra Bank ", " Yes Bank ", " Punjab National Bank ", " Dena Bank ",
            " Canara Bank ", " Bank Of India ", " Corporation Bank ", " Union Bank Of India ",
            " UCO Bank ", " Vijaya Bank ", " South Indian Bank ", " American Express ", " HSBC Bank ",
            " Federal Bank ", " Indian Overseas Bank ", " ING Vysya Bank ", " Karur Vysya Bank ",
            " ABN AMRO ", " Allahabad Bank ", " Andhra Bank ", " ANZ Bank ", " Bank Of Maharashtra ",
            " Barclays Bank ", " Indian bank ", " Bharatiya Mahila Bank ", " Punjab and Sind Bank ",
            " Cashnet India ", " Saraswat Bank ", " Centurion Bank Of Punjab ", " Standard Chartered Bank ",
            " State Bank Of Jaipur ", " Deutsche Bank ", " State Bank Of Travancore ", " Syndicate Bank ",
            " Dhanalakshmi Bank ", " United Bank Of India ", " Karnataka Bank "};
    Integer[] imgId;

    public BankInformationActivity() {
        Integer valueOf = (int) R.drawable.ic_bob_bank;
        Integer valueOf2 = (int) R.drawable.ic_punjab_bank;
        imgId = new Integer[]{(int) R.drawable.ic_sbi_bank,
                valueOf, (int) R.drawable.ic_idbi_bank, (int) R.drawable.ic_central_bank,
                (int) R.drawable.ic_hdfc_bank, (int) R.drawable.ic_citi_bank,
                (int) R.drawable.ic_axis_bank, (int) R.drawable.ic_kotak_bank,
                (int) R.drawable.ic_yash_bank, valueOf2, (int) R.drawable.ic_dena_bank,
                (int) R.drawable.ic_canara_bank, valueOf, (int) R.drawable.ic_corporation_bank,
                (int) R.drawable.ic_union_bank, (int) R.drawable.ic_uco_bank,
                (int) R.drawable.ic_vijay_bank, (int) R.drawable.ic_south_bank,
                (int) R.drawable.ic_american_express, (int) R.drawable.ic_hsbc_bank,
                (int) R.drawable.ic_federal_bank, (int) R.drawable.ic_indian_overseas_bank,
                (int) R.drawable.ic_ing_bank, (int) R.drawable.ic_karur_vyasya_bank,
                (int) R.drawable.ic_adb_bank, (int) R.drawable.ic_alhabaad_bank,
                (int) R.drawable.ic_andhra_bank, (int) R.drawable.ic_anz_bank,
                (int) R.drawable.ic_maharatra_bank, (int) R.drawable.ic_barclays_bank,
                (int) R.drawable.ic_indian_bank, (int) R.drawable.ic_bmb_bank,
                valueOf2, (int) R.drawable.ic_cashnet_bank, (int) R.drawable.ic_saraswat_bank,
                (int) R.drawable.ic_centurion_bank, (int) R.drawable.ic_standard_chartered_bank,
                (int) R.drawable.ic_state_bank_of_bikaner_and_jaipur, (int) R.drawable.ic_desutsche_bank,
                (int) R.drawable.ic_state_bank_of_travancore, (int) R.drawable.ic_syndicate_bank,
                (int) R.drawable.ic_dhanlaxmi_bank, (int) R.drawable.ic_united_bank_of_india,
                (int) R.drawable.ic_karnataka_bank};
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_bank_information);

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        binding.recyclerViewBank.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        binding.btnBack.setOnClickListener(view -> onBackPressed());
        initView();
    }

    private void initView() {

        BankListAdapter adapter = new BankListAdapter(this, bankName, imgId, bank_inquiry, bank_care);


        FBNativeAdAdapter fbAdapter = FBNativeAdAdapter.Builder.with(this, adapter)
                .adItemInterval(2)
                .build();

        binding.recyclerViewBank.setAdapter(adapter);
    }


}