package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Process;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ScreenSatelliteCompassBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import think.outside.the.box.handler.APIManager;


public class ScreenSatelliteCompass extends ParentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    public ScreenSatelliteCompassBinding compassBinding;
    CompassSensorListener compassSensorListener = null;
    boolean z = false;
    LocationManager locationManager = null;
    LocationRequest v;
    GoogleApiClient u = null;
    Marker t;
    GoogleMap w = null;
    public float r = 0f;
    GoogleApiAvailability availability;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        compassBinding = ScreenSatelliteCompassBinding.inflate(getLayoutInflater());
        View view = compassBinding.getRoot();
        setContentView(view);
        compassBinding.back.setOnClickListener(v -> onBackPressed());
       // APIManager.showBanner(compassBinding.bannerRelative);

      


        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        compassSensorListener = new CompassSensorListener(this);
        compassSensorListener.f4976d = new CompassHandler(this);

        if ((checkPermission("android.permission.ACCESS_FINE_LOCATION", Process.myPid(), Process.myUid())) != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale("android.permission.ACCESS_FINE_LOCATION")) {
                requestPermissions(new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 99);
            } else {
                requestPermissions(new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 99);
            }
        }

        availability = GoogleApiAvailability.getInstance();
        int isGooglePlayServicesAvailable = availability.isGooglePlayServicesAvailable(this);
        if (isGooglePlayServicesAvailable != 0) {
            if (availability.isUserResolvableError(isGooglePlayServicesAvailable)) {
                availability.getErrorDialog(this, isGooglePlayServicesAvailable, 0).show();
            }
            finish();
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        w = googleMap;
        googleMap.addCircle(new CircleOptions()
                .center(new LatLng(37.4, -122.1)).radius(1000.0).strokeWidth(10.0f).strokeColor(-16711936).fillColor(Color.argb(128, 255, 0, 0))
                .clickable(true));
        googleMap.setOnCircleClickListener(new GoogleMap.OnCircleClickListener() {
            @Override
            public void onCircleClick(@NonNull Circle circle) {
                circle.setStrokeColor(circle.getStrokeColor() == 0 ? 16777215 : circle.getStrokeColor());
            }
        });

        w.setMapType(1);

        if ((checkPermission("android.permission.ACCESS_FINE_LOCATION", Process.myPid(), Process.myUid())) == PackageManager.PERMISSION_GRANTED) {
            ClientBuilder();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            w.setMyLocationEnabled(true);
        }

    }

    public void ClientBuilder() {
        u = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        u.connect();
    }

    @Override
    protected void onPause() {
        super.onPause();
        compassSensorListener.manager.unregisterListener(compassSensorListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        compassSensorListener.a();
    }

    @Override
    protected void onStart() {
        super.onStart();
        compassSensorListener.a();
    }

    @Override
    protected void onStop() {
        super.onStop();
        compassSensorListener.manager.unregisterListener(compassSensorListener);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        v = new LocationRequest();
        v.setInterval(1000);
        v.setFastestInterval(1000);
        v.setPriority(102);
        if ((checkPermission("android.permission.ACCESS_FINE_LOCATION", Process.myPid(), Process.myUid())) == PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
            ) {
                return;
            }
            LocationServices.FusedLocationApi.requestLocationUpdates(u, v, new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    compassBinding.humidityText.setText(String.valueOf(location.getLongitude()));
                    compassBinding.windText.setText(String.valueOf(location.getLatitude()));
                    LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng);
                    markerOptions.title("You are Here!");
                    markerOptions.icon(BitmapDescriptorFactory.defaultMarker(210.0f));
                    t = w.addMarker(markerOptions);
                    w.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                    w.animateCamera(CameraUpdateFactory.zoomTo(11.0f));
                    Toast.makeText(ScreenSatelliteCompass.this, "Your Current Location", Toast.LENGTH_LONG).show();
                    if (u != null) {
                        LocationServices.FusedLocationApi.removeLocationUpdates(u, this);
                    }
                }
            });
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 99) {
            if (grantResults.length <= 0 || grantResults[0] != 0) {
                Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
            } else if ((checkPermission("android.permission.ACCESS_FINE_LOCATION", Process.myPid(), Process.myUid())) == PackageManager.PERMISSION_GRANTED) {
                if (u == null) {
                    ClientBuilder();
                }
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                w.setMyLocationEnabled(true);
            }
        }
    }


    @Override
    public void onLocationChanged(@NonNull Location location) {
        compassBinding.humidityText.setText(String.valueOf(location.getLongitude()));
        compassBinding.windText.setText(String.valueOf(location.getLatitude()));
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("You are Here!");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(210.0f));
        t = w.addMarker(markerOptions);
        w.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        w.animateCamera(CameraUpdateFactory.zoomTo(11.0f));
        if (u != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(u, new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    compassBinding.humidityText.setText(String.valueOf(location.getLongitude()));
                    compassBinding.windText.setText(String.valueOf(location.getLatitude()));
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng);
                    markerOptions.title("You are Here!");
                    markerOptions.icon(BitmapDescriptorFactory.defaultMarker(210.0f));
                    t = w.addMarker(markerOptions);
                    w.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                    w.animateCamera(CameraUpdateFactory.zoomTo(11.0f));
                    if (u != null) {
                        LocationServices.FusedLocationApi.removeLocationUpdates(u, this);
                    }
                }
            });
        }
    }
}