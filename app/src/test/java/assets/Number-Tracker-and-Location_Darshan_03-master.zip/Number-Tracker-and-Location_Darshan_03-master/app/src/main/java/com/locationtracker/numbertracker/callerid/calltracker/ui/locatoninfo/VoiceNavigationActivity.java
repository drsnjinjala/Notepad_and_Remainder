package com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MapUtility;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityVoiceNavigationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import think.outside.the.box.handler.APIManager;

public class VoiceNavigationActivity extends ParentActivity implements View.OnClickListener, OnMapReadyCallback {

    private ActivityVoiceNavigationBinding binding;
    private static final String TAG = "VoiceNavigationActivity";
    private double mLat = -1.0d;
    private double mLng = -1.0d;
    private GoogleMap mMap;
    private boolean secondClick = false;
    private boolean isZooming = true;
    private Location lastKnownLocation;
    private FusedLocationProviderClient fusedLocationProviderClient;
    Animation fabOpen, fabClose, rotateForward, rotateBackward;
    private boolean isOpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_voice_navigation);

        binding.btnBack.setOnClickListener(view -> onBackPressed());

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);

        this.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_view_voice)).getMapAsync(this);

        fabOpen = AnimationUtils.loadAnimation(this, R.anim.fab_open);
        fabClose = AnimationUtils.loadAnimation(this, R.anim.fab_close);
        rotateForward = AnimationUtils.loadAnimation(this, R.anim.rotate_forward);
        rotateBackward = AnimationUtils.loadAnimation(this, R.anim.rotate_backward);

        binding.addFab.setOnClickListener(view -> animateFab());

        intiView();
    }

    private void animateFab() {
        if (isOpen) {
            binding.addFab.startAnimation(rotateForward);
            binding.imgZoomOut.startAnimation(fabClose);
            binding.imgZoomIn.startAnimation(fabClose);
            binding.imgMyLocation.startAnimation(fabClose);
            binding.imgZoomOut.setClickable(false);
            binding.imgZoomIn.setClickable(false);
            binding.imgMyLocation.setClickable(false);
            isOpen = false;
        } else {
            binding.addFab.startAnimation(rotateBackward);
            binding.imgZoomOut.startAnimation(fabOpen);
            binding.imgZoomIn.startAnimation(fabOpen);
            binding.imgMyLocation.startAnimation(fabOpen);
            binding.imgZoomOut.setClickable(true);
            binding.imgZoomIn.setClickable(true);
            binding.imgMyLocation.setClickable(true);
            isOpen = true;
        }
    }

    private void intiView() {
        binding.imgInputVoice.setOnClickListener(this);
        binding.imgZoomIn.setOnClickListener(this);
        binding.imgZoomOut.setOnClickListener(this);
        binding.imgMyLocation.setOnClickListener(this);
        binding.imgSearchAddress.setOnClickListener(this);
        binding.imgSearchAddress.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_blinking));
        binding.btnStart.setOnClickListener(view -> {
            if (mLat != -1.0d && mLng != -1.0d) {
                Bundle bundle = new Bundle();
                bundle.putString(Variables.KEY, Variables.KEY_VOICE);
                bundle.putDouble(Variables.KEY_LAT, mLat);
                bundle.putDouble(Variables.KEY_LNG, mLng);
                Intent intent = new Intent(VoiceNavigationActivity.this, NavigateRouteActivity.class);
                intent.putExtras(bundle);
                APIManager.showInter(VoiceNavigationActivity.this, false, isfail -> {
                    startActivity(intent);
                });
            }
        });
    }

    @Override
    public void onClick(View view) {
        getSharedPreferences(Variables.pref_name, 0).getString(Variables.interstitial_am_id, "");
        switch (view.getId()) {
            case R.id.imgMyLocation:
                showCurrentLocationOnMap();
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.imgZoomIn:
                GoogleMap googleMap = this.mMap;
                if (googleMap != null) {
                    googleMap.animateCamera(CameraUpdateFactory.zoomTo(googleMap.getCameraPosition().zoom + 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.imgZoomOut:
                GoogleMap googleMap2 = this.mMap;
                if (googleMap2 != null) {
                    googleMap2.animateCamera(CameraUpdateFactory.zoomTo(googleMap2.getCameraPosition().zoom - 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.img_input_voice:
            case R.id.img_search_address:
                Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
                intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "en-US");
                try {
                    startActivityForResult(intent, 11);
                    return;
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(getApplicationContext(), "This device doesn't support Speech to Text", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.img_traffic:
                GoogleMap googleMap3 = this.mMap;
                if (googleMap3 != null) {
                    googleMap3.setTrafficEnabled(!googleMap3.isTrafficEnabled());
                    return;
                }
                return;
            default:
                return;
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.mMap = googleMap;
        googleMap.clear();
        this.mMap.setMapType(2);
        this.mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if (!MapUtility.isNetworkAvailable(VoiceNavigationActivity.this)) {
                    Variables.showToast(VoiceNavigationActivity.this, "Please Connect to Internet");
                    return;
                }
                mMap.clear();
                addMarker("", latLng.latitude, latLng.longitude);
                mLat = latLng.latitude;
                mLng = latLng.longitude;
                binding.btnStart.setEnabled(true);
                MapUtility.getAddressFromLatLng(VoiceNavigationActivity.this, latLng.latitude, latLng.longitude, binding.tvAddress, true);
            }
        });
        updateLocationUI();
        getDeviceLocation();
    }

    private void updateLocationUI() {
        if (this.mMap != null) {
            try {
                if (MapUtility.checkAndRequestPermissions(this, this)) {
                    this.mMap.setMyLocationEnabled(true);
                    this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                    return;
                }
                this.mMap.setMyLocationEnabled(false);
                this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                this.lastKnownLocation = null;
                Variables.checkPermission(this);
            } catch (SecurityException e) {
                Log.e("Exception: %s", e.getMessage());
            }
        }
    }

    private void getDeviceLocation() {
        try {
            if (MapUtility.checkAndRequestPermissions(this, this)) {
                this.fusedLocationProviderClient.getLastLocation().addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(Task<Location> task) {
                        if (task.isSuccessful()) {
                            lastKnownLocation = task.getResult();
                            if (lastKnownLocation != null) {
                                VoiceNavigationActivity voiceNavigationActivity = VoiceNavigationActivity.this;
                                voiceNavigationActivity.addMarker("", voiceNavigationActivity.lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                                VoiceNavigationActivity voiceNavigationActivity2 = VoiceNavigationActivity.this;
                                MapUtility.getAddressFromLatLng(voiceNavigationActivity2, voiceNavigationActivity2.lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude(), binding.tvAddress, false);
                                VoiceNavigationActivity voiceNavigationActivity3 = VoiceNavigationActivity.this;
                                voiceNavigationActivity3.mLat = voiceNavigationActivity3.lastKnownLocation.getLatitude();
                                VoiceNavigationActivity voiceNavigationActivity4 = VoiceNavigationActivity.this;
                                voiceNavigationActivity4.mLng = voiceNavigationActivity4.lastKnownLocation.getLongitude();
                            }
                        } else if (MapUtility.defaultLocation != null) {
                            Log.d(TAG, "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            MapUtility.getAddressFromLatLng(VoiceNavigationActivity.this, MapUtility.defaultLocation.latitude, MapUtility.defaultLocation.longitude, binding.tvAddress, false);
                            mLat = MapUtility.defaultLocation.latitude;
                            mLng = MapUtility.defaultLocation.longitude;
                        } else {
                            Log.d(TAG, "Current location is null and default location cannot get .");
                            Log.e(TAG, "Exception: %s", task.getException());
                            mMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }

    private void showCurrentLocationOnMap() {
        if (MapUtility.checkAndRequestPermissions(this, this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            if (fusedLocationProviderClient == null) {
                return;
            }
            Task<Location> lastLocation = this.fusedLocationProviderClient.getLastLocation();
            lastLocation.addOnSuccessListener(this, new OnSuccessListener<Location>() {
                public void onSuccess(Location location) {
                    if (location != null) {
                        addMarker("", location.getLatitude(), location.getLongitude());
                        mLat = location.getLatitude();
                        mLng = location.getLongitude();
                        MapUtility.getAddressFromLatLng(VoiceNavigationActivity.this, location.getLatitude(), location.getLongitude(), binding.tvAddress, false);
                        return;
                    }
                    Variables.showToast(VoiceNavigationActivity.this, "Location not Available");
                }
            });
            lastLocation.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception exc) {
                    Variables.showToast(VoiceNavigationActivity.this, "Location Not Available");
                }
            });
        }
    }

    public void goToLocationFromAddress(String str) {
        try {
            List<Address> fromLocationName = new Geocoder(this).getFromLocationName(str, 5);
            if (fromLocationName != null) {
                try {
                    Address address = fromLocationName.get(0);
                    addMarker("", address.getLatitude(), address.getLongitude());
                    MapUtility.getAddressFromLatLng(this, address.getLatitude(), address.getLongitude(), binding.tvAddress, true);
                    this.mLat = address.getLatitude();
                    this.mLng = address.getLongitude();
                    binding.btnStart.setEnabled(true);
                } catch (IndexOutOfBoundsException unused) {
                    Toast.makeText(this, "Location isn't available", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addMarker(String str, double d, double d2) {
        CameraUpdate cameraUpdate;
        LatLng latLng = new LatLng(d, d2);
        GoogleMap googleMap = this.mMap;
        if (googleMap != null) {
            try {
                googleMap.clear();
                MarkerOptions position = new MarkerOptions().position(latLng);
                MarkerOptions title = position.title(d + "," + d2);
                if (this.isZooming) {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 15.0f);
                } else {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, this.mMap.getCameraPosition().zoom);
                }
                this.mMap.animateCamera(cameraUpdate);
                this.mMap.addMarker(title);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        str.equals("Search");
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null && i == 11) {
            ArrayList<String> stringArrayListExtra = intent.getStringArrayListExtra("android.speech.extra.RESULTS");
            if (stringArrayListExtra.size() > 0) {
                try {
                    Log.e(TAG, "onActivityResult: addreess   " + stringArrayListExtra.get(0));
                    goToLocationFromAddress(stringArrayListExtra.get(0));
                } catch (Exception e) {
                    Log.e(TAG, "Exception While Searching:" + e.getMessage());
                    Toast.makeText(this, "Error While Searching For Endpoint", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "We had a failure to communicate.", Toast.LENGTH_SHORT).show();
            }
        }
    }


}