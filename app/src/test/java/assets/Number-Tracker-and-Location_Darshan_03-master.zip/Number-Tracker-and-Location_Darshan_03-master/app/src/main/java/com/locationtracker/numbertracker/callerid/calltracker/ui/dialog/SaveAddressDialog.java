package com.locationtracker.numbertracker.callerid.calltracker.ui.dialog;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProviders;

import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MyAddresses;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MyAddressesViewModel;
import com.locationtracker.numbertracker.callerid.calltracker.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SaveAddressDialog extends DialogFragment {
    private final String TAG = getClass().getSimpleName();
    private String address;
    private MyAddressesViewModel itemViewModel;
    private double lat;
    private double lng;

    public SaveAddressDialog(String str, double d, double d2) {
        this.address = str;
        this.lat = d;
        this.lng = d2;
    }

    @Override
    public Dialog onCreateDialog(Bundle bundle) {
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.getWindow().requestFeature(1);
        onCreateDialog.setCancelable(false);
        return onCreateDialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(-2, -2);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        final View inflate = layoutInflater.inflate(R.layout.dialog_saved_location, viewGroup, false);
        ((TextView) inflate.findViewById(R.id.tv_title)).setText(this.address);
        final EditText editText = (EditText) inflate.findViewById(R.id.tvAddress);
        this.itemViewModel = (MyAddressesViewModel) ViewModelProviders.of(this).get(MyAddressesViewModel.class);
        inflate.findViewById(R.id.btn_no).setOnClickListener(view -> SaveAddressDialog.this.dismiss());
        inflate.findViewById(R.id.img_cancel).setOnClickListener(view -> SaveAddressDialog.this.dismiss());
        inflate.findViewById(R.id.btn_yes).setOnClickListener(view -> {
            if (editText.getText().equals(null) || editText.getText().toString().isEmpty()) {
                Toast.makeText(SaveAddressDialog.this.getContext(), "Please add Title of Address", Toast.LENGTH_SHORT).show();
            } else if (editText.getText().toString().length() > 18) {
                Toast.makeText(SaveAddressDialog.this.getContext(), "Please Enter Short Title", Toast.LENGTH_SHORT).show();
            } else {
                SaveAddressDialog.this.itemViewModel.insert(new MyAddresses(editText.getText().toString(), SaveAddressDialog.this.address, SaveAddressDialog.this.lat, SaveAddressDialog.this.lng, SaveAddressDialog.this.getDateTime()));
                try {
                    SaveAddressDialog.this.dismiss();
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            }
        });
        return inflate;
    }

    private String getDateTime() {
        return SimpleDateFormat.getDateTimeInstance().format(new Date());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
