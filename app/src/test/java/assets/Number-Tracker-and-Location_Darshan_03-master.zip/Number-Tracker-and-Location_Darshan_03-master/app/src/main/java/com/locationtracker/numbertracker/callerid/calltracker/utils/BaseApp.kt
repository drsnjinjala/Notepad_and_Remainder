package com.locationtracker.numbertracker.callerid.calltracker.utils

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.LifecycleObserver
import think.outside.the.box.util.TinyDB

open class BaseApp : Application(), Application.ActivityLifecycleCallbacks, LifecycleObserver {

    override fun onCreate() {
        super.onCreate()
        context = this
    }


    fun themeToggleMode() {
        if (TinyDB(this).getInt("theme", 1) == 1) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
    }

    companion object {
        @JvmField
        var context: BaseApp? = null

        var currentActivity: Activity? = null
        var classes = java.util.ArrayList<Class<*>>()
    }

    fun loadOpenAd() {

    }

    open fun setAvoidClass(aClass: Class<*>) {
        classes.add(aClass)
    }

    @Keep
    open fun setAvoidMultipleClass(aClass: ArrayList<Class<*>>) {
        classes.addAll(aClass)
    }


    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
    }

    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {
    }

    override fun onActivityStopped(activity: Activity) {
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
    }

    override fun onActivityDestroyed(activity: Activity) {
    }

}