package com.locationtracker.numbertracker.callerid.calltracker.ui.simcard;

import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.FBNativeAdAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.SimCardAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivitySimCardInfoBinding;
import com.locationtracker.numbertracker.callerid.calltracker.model.SimModel;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import java.util.ArrayList;

import think.outside.the.box.handler.APIManager;

public class SimCardInfoActivity extends ParentActivity {

    private ActivitySimCardInfoBinding binding;
    public static int abc;
    public static String[] arr;
    public static String[] names;
    public static ArrayList<SimModel> dataModels;
    public static int[] images =
            {R.drawable.ic_airtel,
                    R.drawable.ic_gio,
                    R.drawable.ic_aircel,
                    R.drawable.ic_idea,
                    R.drawable.ic_vadaphone,
                    R.drawable.ic_uninor,
                    R.drawable.ic_docomo,
                    R.drawable.ic_bsnl,
                    R.drawable.ic_virgin};
    private static RecyclerView recyclerView;
    String[] f214n = {"*120*(16 digits code)#", "*123#", "*555#", "*123*10#/*123*11#", "*121*9#", "121 or 198"};
    String[] f215o = {"*124*(16 digits code)#", "*125#", "*111*5#and*111*12#", "*123*1#", "*1#", "121 or 198"};
    String[] f216p = {"*124*(16 digits code)#", "*111#", "*167*3#", "*125#", "*1#", "12345"};
    String[] f217q = {"*140*(16 digits code)#", "*145# or *146#", "*142#", "*111*6# or *111*6*2#", "*777*0#", "198 or 9825098250"};
    String[] f218r = {"*222*3*(16 digits code)#", "*222*2#", "*222*2#", "*123#", "*1#", "121 or 9059090590"};
    String[] f219t = {"*135*2*(16 digits code)#", "*111#", "*111*1#", "*123*1#", "*580#", "121"};
    String[] f220u = {"*123*(16 digits code)#", "*333#", "*112# then press 3", "*333# then press 2", "*1#", "1800 889 9999"};
    String[] f221v = {"*124*2*(16 digits code)#", "*123#", "*123*10# ", "*124#", "*1#", "1503 or 1800-345-1500"};
    String[] vir = {"*222*1*(16 digits code)#", "123", "*125*10# ", "*12#", "*1#", "121"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_sim_card_info);
        names = getResources().getStringArray(R.array.tv_name);
        arr = getResources().getStringArray(R.array.arrr);
        initView();
        binding.btnBack.setOnClickListener(view -> onBackPressed());

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
    }

    private void initView() {
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        dataModels = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            SimModel simmodal = new SimModel();
            simmodal.setName(names[i]);
            simmodal.setImage(images[i]);
            SimModel simmodal2 = new SimModel();
            if (i == 0) {
                abc = 0;
                simmodal2.setTitles(this.f214n);
            } else if (i == 1) {
                abc = 1;
                simmodal2.setTitles(this.f220u);
            } else if (i == 2) {
                abc = 2;
                simmodal2.setTitles(this.f215o);
            } else if (i == 3) {
                abc = 3;
                simmodal2.setTitles(this.f216p);
            } else if (i == 4) {
                abc = 4;
                simmodal2.setTitles(this.f217q);
            } else if (i == 5) {
                abc = 5;
                simmodal2.setTitles(this.f218r);
            } else if (i == 6) {
                abc = 6;
                simmodal2.setTitles(this.f219t);
            } else if (i == 7) {
                abc = 7;
                simmodal2.setTitles(this.f221v);
            } else if (i == 8) {
                abc = 8;
                simmodal2.setTitles(this.vir);
            }
            simmodal.setDatamodels1(simmodal2);
            dataModels.add(simmodal);
            setView();
        }
    }

    private void setView() {
        RecyclerView recyclerView2 = (RecyclerView) findViewById(R.id.my_recycler_view);
        recyclerView = recyclerView2;
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));
        SimCardAdapter itemAdapter = new SimCardAdapter(this, dataModels);
        FBNativeAdAdapter fbAdapter = FBNativeAdAdapter.Builder.with(this, itemAdapter)
                .adItemInterval(2)
                .build();
        recyclerView.setAdapter(itemAdapter);
    }


}