package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ScreenSportMeterBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.util.List;

import think.outside.the.box.callback.AdsCallback;
import think.outside.the.box.handler.APIManager;

public class ScreenSportMeter extends ParentActivity implements LocationListener {


    ScreenSportMeterBinding meterBinding;
    float f2178c = 0f;
    float f2179d = 0f;
    float f2180e = 0f;
    private boolean provider = false;
    boolean f2182g = false;
    MediaPlayer mediaPlayer;
    String mesurestr = "KMPH";
    LocationManager locationManager;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        meterBinding = ScreenSportMeterBinding.inflate(getLayoutInflater());
        View view = meterBinding.getRoot();
        setContentView(view);

        APIManager.showSmallNative(meterBinding.ads130);
        APIManager.showBanner(meterBinding.ads65);

        meterBinding.back.setOnClickListener(v -> onBackPressed());

        mediaPlayer = MediaPlayer.create(this, R.raw.car_simon);
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mediaPlayer.release();
            }
        });
        mediaPlayer.start();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        } else {
            locationManager.requestLocationUpdates("gps", 0, BitmapDescriptorFactory.HUE_RED, this);
        }

        provider = locationManager.isProviderEnabled("network");

        if (!locationManager.isProviderEnabled("gps") && !provider) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getResources().getString(R.string.no_gps)).setCancelable(false).setPositiveButton(getResources().getString(R.string.enable_gps), (dialogInterface, i) -> startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS")));
            builder.setNegativeButton(getResources().getString(R.string.compass_cancel), (dialogInterface, i) -> dialogInterface.cancel());
            AlertDialog create = builder.create();
            builder.setCancelable(false);
            create.show();
        }

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        if (location == null) {
            meterBinding.speedometerView.setCurrentSpeed(BitmapDescriptorFactory.HUE_RED);
            meterBinding.speedometerView.invalidate();
        } else {
            float speed = location.getSpeed();
            if (mesurestr.equals("KMPH")) {
                f2179d = speed * 3600.0f;
                f2180e = 1000.0f;
            } else if (mesurestr.equals("MPH")) {
                f2179d = speed * 3600.0f;
                f2180e = 1609.0f;
            } else {
                f2178c = speed * 3.0f * 0.539957f;
                meterBinding.speedometerView.setCurrentSpeed(f2178c);
                meterBinding.speedometerView.invalidate();
                meterBinding.measureText.setText(String.format("%.1f", Float.valueOf(f2178c)) + " " + mesurestr);
            }
            f2178c = f2179d / f2180e;
            meterBinding.speedometerView.setCurrentSpeed(f2178c);
            meterBinding.speedometerView.invalidate();
            meterBinding.measureText.setText(String.format("%.1f", Float.valueOf(f2178c)) + " " + mesurestr);
        }
    }

    @Override
    public void onLocationChanged(@NonNull List<Location> locations) {

    }

    @Override
    public void onFlushComplete(int requestCode) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        APIManager.showInter(this, true, new AdsCallback() {
            @Override
            public void onClose(boolean b) {
                finish();
            }
        });

    }

}