package com.locationtracker.numbertracker.callerid.calltracker.ui.single;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityGpsInformationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import think.outside.the.box.handler.APIManager;

public class GpsInformationActivity extends ParentActivity {

    private ActivityGpsInformationBinding binding;
    Double latitude;
    LocationManager locationManager;
    Double longitude;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setLightTheme(true);
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_gps_information);

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        initView();
        binding.btnBack.setOnClickListener(view -> onBackPressed());

    }

    private void initView() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        ProgressDialog progressDialog2 = new ProgressDialog(this);
        progressDialog = progressDialog2;
        progressDialog2.setMessage("Please Wait While Fetching Location....!!!!");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        progressDialog.show();
        binding.showMap.setOnClickListener(view -> {
            if (latitude != null && longitude != null) {
               APIManager.showInter(GpsInformationActivity.this, false, isfail -> {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse(String.format(Locale.ENGLISH, "geo:%f,%f", latitude, longitude))));
                });
            }
        });
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            locationManager.requestLocationUpdates("network", 1000, 10.0f, new Listener());
            locationManager.requestLocationUpdates("gps", 1000, 10.0f, new Listener());
        }
    }

    private class Listener implements LocationListener {
        public void onProviderDisabled(String str) {

        }

        public void onProviderEnabled(String str) {

        }

        public void onStatusChanged(String str, int i, Bundle bundle) {

        }

        private Listener() {

        }

        public void onLocationChanged(Location location) {
            latitude = Double.valueOf(location.getLatitude());
            longitude = Double.valueOf(location.getLongitude());
            TextView textView = binding.txtLatitude;
            textView.setText("" + latitude);
            TextView textView2 = binding.txtLongitude;
            textView2.setText("" + longitude);
            try {
                List<Address> fromLocation = new Geocoder(GpsInformationActivity.this, Locale.getDefault()).getFromLocation(latitude.doubleValue(), longitude.doubleValue(), 1);
                String countryName = fromLocation.get(0).getCountryName();
                String adminArea = fromLocation.get(0).getAdminArea();
                String locality = fromLocation.get(0).getLocality();
                String postalCode = fromLocation.get(0).getPostalCode();
                String addressLine = fromLocation.get(0).getAddressLine(0);
                binding.txtCity.setText(locality);
                binding.txtState.setText(adminArea);
                binding.txtCountry.setText(countryName);
                binding.txtAddress.setText(addressLine);
                binding.txtCode.setText(postalCode);
                progressDialog.dismiss();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}