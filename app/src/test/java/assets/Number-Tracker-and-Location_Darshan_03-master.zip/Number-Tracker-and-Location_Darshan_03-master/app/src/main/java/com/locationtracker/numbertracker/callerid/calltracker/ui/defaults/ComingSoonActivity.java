package com.locationtracker.numbertracker.callerid.calltracker.ui.defaults;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.locationtracker.numbertracker.callerid.calltracker.R;

import think.outside.the.box.handler.APIManager;

public class ComingSoonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_soon);

    }
}