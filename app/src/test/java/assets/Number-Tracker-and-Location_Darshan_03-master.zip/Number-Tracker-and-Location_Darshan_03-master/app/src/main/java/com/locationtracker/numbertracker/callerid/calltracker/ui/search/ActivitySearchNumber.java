package com.locationtracker.numbertracker.callerid.calltracker.ui.search;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MapUtility;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import think.outside.the.box.handler.APIManager;

public class ActivitySearchNumber extends ParentActivity implements OnMapReadyCallback {
    Double latitude;
    Double longitude;
    private SearchDatabase ad;
    public static String[] countries = new String[]{
            "+91(India)", "+1(United States of America)", "+93(Afghanistan)", "+358(Aland Islands)", "+355(Albania)", "+213(Algeria)",
            "+1(American Samoa)", "+376(Andorra)",
            "+244(Angola)", "+1(Anguilla)",
            "+672(Antarctica)", "+1(Antigua)",
            "+54(Argentina)",
            "+374(Armenia)", "+297(Aruba)",
            "+61(Australia)", "+43(Austria)", "+994(Azerbaijan)",
            "+1(Bahamas)",
            "+973(Bahrain)", "+880(Bangladesh)", "+1(Barbados)", "+375(Belarus)", "+32(Belgium)", "+501(Belize)",
            "+229(Benin)", "+1(Bermuda)", "+975(Bhutan)",
            "+591(Bolivia)", "+387(Bosnia and Herzegovina)",
            "+267(Botswana)", "+55(Brazil)",
            "+246(British Indian Ocean Territory)", "+673(Brunei)",
            "+359(Bulgaria)", "+226(Burkina Faso)", "+257(Burundi)", "+855(Cambodia)",
            "+237(Cameroon)", "+1(Canada)", "+238(Cape Verde Islands)",
            "+345(Cayman Islands)", "+236(Central African Republic)", "+235(Chad)", "+56(Chile)", "+86(China)", "+61(Christmas Island)", "+61(Cocos Island)",
            "+57(Colombia)", "+269(Comoros)",
            "+682(Cook Islands)", "+506(Costa Rica)",
            "+225(Cote D'Ivoire)",
            "+385(Croatia)", "+53(Cuba)", "+537(Cyprus)", "+420(Czech Republic)",
            "+45(Denmark)", "+253(Djibouti)", "+1 767(Dominica)", "+1 849(Dominican Republic)",
            "+593(Ecuador)", "+20(Egypt)",
            "+503(El Salvador)", "+240(Equatorial Guinea)",
            "+291(Eritrea)", "+372(Estonia)",
            "+251(Ethiopia)", "+500(Falkland Islands)", "+298(Faroe Islands)", "+358(Finland)", "+33(France)", "+594(French Guiana)",
            "+689French Polynesia)",
            "+241(Gabon)", "+220(Gambia)",
            "+995(Georgia)", "+49(Germany)", "+233(Ghana)", "+350(Gibraltar)", "+30(Greece)",
            "+299(Greenland)", "+1 473(Grenada)", "+590(Guadeloupe)", "+1 671(Guam)",
            "+502(Guatemala)", "+44(Guernsey)", "+224(Guinea)",
            "+245(Guinea-Bissau)",
            "+595(Guyana)", "+509(Haiti)", "+504(Honduras)", "+852(Hong Kong)",
            "+36(Hungary)", "+354(Iceland)", "+62(Indonesia)",
            "+98(Iran)", "+964(Iraq)", "+353(Ireland)",
            "+44(Isle of Man)", "+972(Israel)", "+39(Italy)", "+1 876(Jamaica)", "+81(Japan)",
            "+44(JERSEY)", "+962(Jordan)", "+962(Kazakhstan)", "+254(Kenya)", "+371(Latvia)", "+961(Lebanon)",
            "+266(Lesotho)", "+231(Liberia)", "+218(Libya)", "+423(Liechtenstein)",
            "+370(Lithuania)", "+352(Luxembourg)", "+853(Macao)", "+389(Macedonia)",
            "+261(Madagascar)", "+265(Malawi)", "+60(Malaysia)", "+960(Maldives)", "+223(Mali)", "+356(Malta)",
            "+692(Marshall Islands)", "+596(Martinique)", "+222(Mauritania)",
            "+230(Mauritius)", "+262(Mayotte)", "+52(Mexico)", "+691(Micronesia)", "+373(Moldova)", "+377(Monaco)", "+976(Mongolia)",
            "+382(Montenegro)", "+1664(Montserrat)", "+212(Morocco)",
            "+258(Mozambique)", "+95(Myanmar)", "+264(Namibia)", "+674(Nauru)", "+977(Nepal)", "+31(Netherlands)",
            "+599(Netherlands Antilles)",
            "+687(New Caledonia)", "+64(New Zealand)", "+505(Nicaragua)", "+227(Niger)", "+234(Nigeria)", "+683(Niue)", "+672(Norfolk Island)", "+1 670(North Korea)", "+47(Norway)", "+968(Oman)",
            "+92(Pakistan)", "+680(Palau)", "+970(Palestine)", "+507(Panama)",
            "+675(Papua New Guinea)", "+595(Paraguay)", "+51(Peru)", "+63(Philippines)", "+48(Poland)", "+351(Portugal)", "+1 939(Puerto Rico)", "+974(Qatar)", "+40(Romania)", "+7(Russia Federation)", "+250(Rwanda)", "+590(Saint Barthelemy)", "+386(Slovenia)",
            "+27(South Africa)", "+34(Spain)",
            "+249(Sudan)", "+597(Suriname)", "+268(Swaziland)", "+46(Sweden)", "+41(Switzerland)", "+886(Taiwan)", "+992(Tajikistan)", "+255(Tanzania)", "+66(Thailand)",
            "+670(Timor-leste)", "+228(Togo)", "+690(Tokelau)", "+676(Tonga)", "+1 868(Trinidad and Tobago)", "+216(Tunisia)", "+90(Turkey)", "+993(Turkmenistan)", "+1 649(Turks and Caicos Island)",
            "+688(Tuvalu)", "+256(Uganda)", "+380(Ukraine)", "+971(United Arab Emirates)", "+44(United Kingdom)", "+598(Uruguay)", "+1 284(US Virgin Islands)", "+998(Uzbekistan)",
            "+678(Vanuatu)", "+58(Venezuela)", "+681(Wallis and Futuna)", "+967(Yemen)", "+260(Zambia)",
            "+263(Zimbabwe)"};

    private Spinner country_code;
    private String country_code_value;
    private Cursor cursor;
    private String entered_mobile_number;
    ImageView iv_close;
    private ImageView localImageView;
    private TextView localTextView;
    private TextView localoperator;
    private OnFragmentInteractionListener mListener;
    private EditText mobile_number;
    private TextView numberText;
    private RelativeLayout searchResult_layout;
    private LinearLayout showMap;
    private String nameget;
    private String namefind;
    ProgressDialog progressDialog;
    GoogleMap map;
    GoogleMap mMap;
    private ArrayList mList = new ArrayList();
    private String data;
    ImageView backbtn;
    private FusedLocationProviderClient fusedLocationProviderClient;

    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        if (!(this.mMap == null)) {

        }
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") != 0) {
            ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION");
        }
    }

    private void showCurrentLocationOnMap() {
        if (MapUtility.checkAndRequestPermissions(this, this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            if (fusedLocationProviderClient == null) {
                return;
            }
            Task<Location> lastLocation = this.fusedLocationProviderClient.getLastLocation();
            lastLocation.addOnSuccessListener(this, location -> {
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    if (Geocoder.isPresent()) {
                        try {
                            List<Address> fromLocationName = new Geocoder(this).getFromLocation(latitude, longitude, 5);
                            this.mList = new ArrayList(fromLocationName.size());
                            for (Address address : fromLocationName) {
                                if (address.hasLatitude() && address.hasLongitude() && address.hasLatitude() && address.hasLongitude()) {
                                    LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                                    MarkerOptions markerOptions = new MarkerOptions();
                                    markerOptions.position(latLng);
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(latLng.latitude);
                                    sb.append(" : ");
                                    sb.append(latLng.longitude);
                                    Log.e("arpitaaa", sb.toString());
                                    markerOptions.title(sb.toString());
                                    this.mMap.clear();
                                    this.mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5.0f));
                                    this.mMap.addMarker(markerOptions);
                                }
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                return;
            });
            lastLocation.addOnFailureListener(exc -> Variables.showToast(this, "Location Not Available"));
        }
    }

    interface OnFragmentInteractionListener {
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_number);
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait ...!!!!");
        this.progressDialog.setCanceledOnTouchOutside(false);
        this.progressDialog.setCancelable(false);
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map1)).getMapAsync(this);
        this.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        showCurrentLocationOnMap();

        this.showMap = (LinearLayout) findViewById(R.id.showMap);
        this.numberText = (TextView) findViewById(R.id.textView1);
        this.localTextView = (TextView) findViewById(R.id.textViewCallScreen);
        localoperator = (TextView) findViewById(R.id.operator);
        localImageView = (ImageView) findViewById(R.id.imageViewCallScreen);
        searchResult_layout = (RelativeLayout) findViewById(R.id.relativeLayout1);
        ImageView button = (ImageView) findViewById(R.id.find);
        mobile_number = (EditText) findViewById(R.id.mobile_number);
        iv_close = (ImageView) findViewById(R.id.iv_close);
        backbtn = findViewById(R.id.btn_back);


        APIManager.showTopSmallNative(findViewById(R.id.ads130));
        APIManager.showBanner(findViewById(R.id.ads65));

        this.backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        this.iv_close.setOnClickListener(view -> {
            mobile_number.setText("");
            searchResult_layout.setVisibility(View.GONE);
        });

        mobile_number.setOnClickListener(v -> searchResult_layout.setVisibility(View.GONE));

        this.showMap.setOnClickListener(view -> {
            String url = "http://maps.google.com/maps?daddr=" + namefind;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        Display defaultDisplay = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        int i = point.y;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(point.x - 50, -2, 2002, 8, -3);
        layoutParams.gravity = 49;
        layoutParams.x = 0;
        double d = (double) (i * 3);
        Double.isNaN(d);
        Double.isNaN(d);
        layoutParams.y = (int) (d / 4.5d);
        this.country_code = (Spinner) findViewById(R.id.country_code);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, 17367048, this.countries);
        arrayAdapter.setDropDownViewResource(17367049);
        this.country_code.setAdapter((SpinnerAdapter) arrayAdapter);
        this.country_code.setOnItemSelectedListener(new country_code());
        SearchDatabase database_Search = new SearchDatabase(this);
        this.ad = database_Search;
        database_Search.createDatabase();
        try {
            this.ad.open();
        } catch (Exception e) {
            e.printStackTrace();
        }
        button.setOnClickListener(new find_location());
    }

    class country_code implements AdapterView.OnItemSelectedListener {
        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
        }

        country_code() {
        }

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            ((TextView) adapterView.getChildAt(0)).setTextColor(getResources().getColor(R.color.colorText));
            mobile_number.setText("");
            searchResult_layout.setVisibility(View.GONE);
            StringBuilder sb = new StringBuilder();
            sb.append(country_code.getSelectedItem());

            data = sb.toString();
        }
    }

    class find_location implements View.OnClickListener {

        public class location implements DialogInterface.OnClickListener {
            location() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        }

        find_location() {
        }

        public void onClick(View view) {
            if (((InputMethodManager) getApplicationContext().getSystemService(INPUT_METHOD_SERVICE)).isAcceptingText()) {
                ((InputMethodManager) Objects.requireNonNull(((ActivitySearchNumber) Objects.requireNonNull(ActivitySearchNumber.this)).getSystemService(INPUT_METHOD_SERVICE))).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 2);
            }
            localImageView.setImageResource(R.drawable.ic_call);
            entered_mobile_number = String.valueOf(mobile_number.getText());
            if (entered_mobile_number.length() == 4) {
                showError(view);
            } else if (entered_mobile_number.length() == 10) {
                if (entered_mobile_number.charAt(0) == '0') {
                    showError(view);
                } else if (country_code.getSelectedItem().toString().equalsIgnoreCase("+91(India)")) {
                    getDataFromDB(entered_mobile_number.substring(0, 4), view);
                } else if (country_code.getSelectedItem().toString().equalsIgnoreCase("+1(United States of America)")) {
//                    getdataset(view, country_code.getSelectedItem().toString());
                    getDataFromDB(entered_mobile_number.substring(0, 3), view);
                } else {
                    getdataset(view, country_code.getSelectedItem().toString());
                }
            } else if (entered_mobile_number.length() > 4 && entered_mobile_number.length() < 10) {
                showError(view);
            } else if (entered_mobile_number.length() <= 4) {
                showError(view);
            } else {
                entered_mobile_number.length();
                showError(view);
            }
        }

        private void getDataFromDB(String str, View view) {
            try {
                cursor = ad.get_details(str, country_code_value);
            } catch (Exception e) {
                e.printStackTrace();
            }
            localImageView.setImageResource(R.drawable.ic_call);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    if (numberText != null) {
                        TextView textView = numberText;
                        StringBuilder sb = new StringBuilder();
                        sb.append(mobile_number.getText().toString());
                        textView.setText(sb);
                    }
                    if (localTextView != null) {
                        TextView textView2 = localTextView;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(cursor.getString(2));
                        String nameget = sb2.toString();
                        String arrayString[] = nameget.split("\\++");
                        String dataget = arrayString[0];
                        Log.e("vallllllll", dataget);
                        String[] findldata = dataget.split("\\)+");

                        CallMapMethod(findldata[0]);
                        textView2.setText(sb2);
                    }
                    if (localoperator != null) {
                        TextView textView3 = localoperator;
                        StringBuilder sb3 = new StringBuilder();
//                        sb3.append("Operator : ");
                        sb3.append(cursor.getString(1));
                        textView3.setText(sb3);
                    }
                    if (localoperator != null) {
//                        latitude = cursor.getDouble(4);
//                        longitude = cursor.getDouble(5);
                    }
                    if (searchResult_layout != null) {
                        searchResult_layout.setVisibility(View.VISIBLE);
                    }

//                    }

                } while (cursor.moveToNext());
//                cursor.moveToFirst();

            }
        }

        private void showError(View view) {
            new AlertDialog.Builder((Context) Objects.requireNonNull(ActivitySearchNumber.this)).setTitle("Confirm").setMessage("Please enter a valid mobile Number").setPositiveButton("OK", new location()).show();
        }
    }

    private void getdataset(View view, String name) {
        if (numberText != null) {
            TextView textView = numberText;
            StringBuilder sb = new StringBuilder();
            sb.append(mobile_number.getText().toString());
            textView.setText(sb);
        }
        if (localTextView != null) {
            TextView textView2 = localTextView;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(name);
            String nameget = sb2.toString();
            String arrayString[] = nameget.split("\\(+");
            String dataget = arrayString[1];
            String[] findldata = dataget.split("\\)+");
            Log.e("vallllllll", findldata[0]);
            CallMapMethod(findldata[0]);
            textView2.setText(findldata[0]);
        }
        if (localoperator != null) {
            TextView textView3 = localoperator;
            StringBuilder sb3 = new StringBuilder();
            sb3.append("Unknown");
            textView3.setText(sb3);
        }
        if (localoperator != null) {
        }
        if (searchResult_layout != null) {
            searchResult_layout.setVisibility(View.VISIBLE);
        }
    }

    private class Listener implements LocationListener {

        public void onProviderDisabled(String str) {
        }

        public void onProviderEnabled(String str) {
        }

        public void onStatusChanged(String str, int i, Bundle bundle) {
        }

        private Listener() {
        }

        public void onLocationChanged(Location location) {
//            latitude = Double.valueOf(location.getLatitude());
//            longitude = Double.valueOf(location.getLongitude());
//            progressDialog.dismiss();
//
//            try {
//                List<Address> fromLocation = new Geocoder(ActivitySearchNumber.this, Locale.getDefault()).getFromLocation(latitude.doubleValue(), longitude.doubleValue(), 1);
//                String countryName = fromLocation.get(0).getCountryName();
//                String adminArea = fromLocation.get(0).getAdminArea();
//                String locality = fromLocation.get(0).getLocality();
//                String postalCode = fromLocation.get(0).getPostalCode();
//                String addressLine = fromLocation.get(0).getAddressLine(0);
//                progressDialog.dismiss();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
        }
    }

    @Override
    protected void onResume() {
//        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
//        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
//        mapView.onLowMemory();
    }

    public void CallMapMethod(String str) {
        if (Geocoder.isPresent()) {
            try {
                List<Address> fromLocationName = new Geocoder(this).getFromLocationName(str, 5);
                this.mList = new ArrayList(fromLocationName.size());
                for (Address address : fromLocationName) {
                    if (address.hasLatitude() && address.hasLongitude() && address.hasLatitude() && address.hasLongitude()) {
                        LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                        MarkerOptions markerOptions = new MarkerOptions();
                        markerOptions.position(latLng);
                        StringBuilder sb = new StringBuilder();
                        sb.append(latLng.latitude);
                        sb.append(" : ");
                        sb.append(latLng.longitude);
                        Log.e("arpitaaa", sb.toString());
                        markerOptions.title(sb.toString());
                        this.mMap.clear();
                        this.mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5.0f));
                        this.mMap.addMarker(markerOptions);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        showCurrentLocationOnMap();
    }
}