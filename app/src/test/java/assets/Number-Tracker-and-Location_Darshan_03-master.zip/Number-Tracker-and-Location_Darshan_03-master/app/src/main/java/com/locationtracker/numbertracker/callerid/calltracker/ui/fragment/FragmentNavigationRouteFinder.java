package com.locationtracker.numbertracker.callerid.calltracker.ui.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;

import java.util.Objects;

import think.outside.the.box.handler.APIManager;

public class FragmentNavigationRouteFinder extends Fragment {
    private static final String TAG = "ActionNavigationFrag";

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        final double d;
        final double d2;
        final double d3;
        final double d4;
        View inflate = layoutInflater.inflate(R.layout.fragment_navigation, viewGroup, false);
        Bundle arguments = getArguments();
        if (arguments != null) {
            double d5 = arguments.getDouble(Variables.KEY_LAT_ORG);
            double d6 = arguments.getDouble(Variables.KEY_LNG_ORG);
            double d7 = arguments.getDouble(Variables.KEY_LAT_DES);
            d = arguments.getDouble(Variables.KEY_LNG_DES);
            d3 = d6;
            d2 = d7;
            d4 = d5;
        } else {
            Log.d(TAG, "onCreateView: destroying fragment");
            Toast.makeText(getContext(), "Something Went Wrong", Toast.LENGTH_SHORT).show();
            d4 = 0.0d;
            d3 = 0.0d;
            d2 = 0.0d;
            d = 0.0d;
        }
        inflate.findViewById(R.id.btn_navigation).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (d4 != 0.0 && d3 != 0.0 && d2 != 0.0 && d != 0.0) {
                    try {
                      APIManager.showInter(getActivity(), false, isfail -> {
                            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://maps.google.com/maps?saddr=" + d4 + "," + d3 + "&daddr=" + d2 + "," + d + "")));
                            FragmentActivity activity = getActivity();
                            Objects.requireNonNull(activity);
                            activity.finish();
                       });
                    } catch (Exception e) {
                        Log.e(TAG, "onClick: " + e.getMessage());
                    }
                }
            }
        });
        return inflate;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
