package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ScreenDigitalMeterBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.util.List;

import think.outside.the.box.handler.APIManager;

public class ScreenDigitalMeter extends ParentActivity implements LocationListener {

    ScreenDigitalMeterBinding digitalMeterBinding;
    boolean view = false;
    MediaPlayer mediaPlayer;
    String mesurestr = "KMPH";
    int mval = 1;
    LocationManager locationManager;
    boolean provider = false;
    float f2198c = 0f;
    float f2199d = 0f;
    float f2200e = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        digitalMeterBinding = ScreenDigitalMeterBinding.inflate(getLayoutInflater());
        View vi = digitalMeterBinding.getRoot();
        setContentView(vi);
        APIManager.showSmallNative(digitalMeterBinding.nativeRelative);
         APIManager.showBanner(digitalMeterBinding.bannerAds);
        digitalMeterBinding.back.setOnClickListener(v -> onBackPressed());
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        } else {
            locationManager.requestLocationUpdates("gps", 0, BitmapDescriptorFactory.HUE_RED, this);
        }
        provider = locationManager.isProviderEnabled("network");

        if (!locationManager.isProviderEnabled("gps") && !provider) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getResources().getString(R.string.no_gps)).setCancelable(false).setPositiveButton(getResources().getString(R.string.enable_gps), (dialogInterface, i) -> startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS")));
            builder.setNegativeButton(getResources().getString(R.string.compass_cancel), (dialogInterface, i) -> dialogInterface.cancel());
            AlertDialog create = builder.create();
            builder.setCancelable(false);
            create.show();
        }

        mediaPlayer = MediaPlayer.create(this, R.raw.car_simon);
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mediaPlayer.release();
            }
        });
        mediaPlayer.start();

        if (mesurestr.equals("KMPH")) {
            mval = 1;
        } else if (mesurestr.equals("MPH")) {
            mval = 2;
        }

        digitalMeterBinding.changeMeasureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mval == 1) {
                    mesurestr = "MPH";
                    mval = 2;
                } else if (mval == 2) {
                    mesurestr = "KMPH";
                    mval = 1;
                }
            }
        });

        digitalMeterBinding.changeViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (view) {
                    digitalMeterBinding.measureText.setScaleX(1.0f);
                    digitalMeterBinding.measureText.setScaleY(1.0f);
                    digitalMeterBinding.measureText.setTranslationX(1.0f);
                    view = false;
                } else {
                    digitalMeterBinding.measureText.setScaleX(-1.0f);
                    digitalMeterBinding.measureText.setScaleY(1.0f);
                    digitalMeterBinding.measureText.setTranslationX(1.0f);
                    view = true;
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
       APIManager.showInter(this,true, state -> finish());
finish();
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        if (location != null) {
            float speed = location.getSpeed();
            if (mesurestr.equals("KMPH")) {
                f2199d = speed * 3600.0f;
                f2200e = 1000.0f;
            } else if (mesurestr.equals("MPH")) {
                f2199d = speed * 3600.0f;
                f2200e = 1609.0f;
            } else {
                f2198c = speed * 3.0f * 0.539957f;
                digitalMeterBinding.measureText.setText(String.format("%.1f", Float.valueOf(f2198c)) + " " + mesurestr);
            }
            f2198c = f2199d / f2200e;
            digitalMeterBinding.measureText.setText(String.format("%.1f", Float.valueOf(f2198c)) + " " + mesurestr);
        }
    }

    @Override
    public void onLocationChanged(@NonNull List<Location> locations) {

    }

    @Override
    public void onFlushComplete(int requestCode) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

    }

}