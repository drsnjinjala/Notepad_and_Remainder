package com.locationtracker.numbertracker.callerid.calltracker.model;

public class SimModel {
    SimModel datamodels1;
    int image;
    String name;
    String[] titles;

    public SimModel getDatamodels1() {
        return this.datamodels1;
    }

    public void setDatamodels1(SimModel simmodal) {
        this.datamodels1 = simmodal;
    }

    public String[] getTitles() {
        return this.titles;
    }

    public void setTitles(String[] strArr) {
        this.titles = strArr;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public int getImage() {
        return this.image;
    }

    public void setImage(int i) {
        this.image = i;
    }
}
