package com.locationtracker.numbertracker.callerid.calltracker.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.model.RechargePlan;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargePlanActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class RechargePlanAdapter extends RecyclerView.Adapter<RechargePlanAdapter.ViewHolder> {

    private String Circlejson = "{\"Airtel\" : \"0\", \"Jio\":\"1\",\"Vodafone\":\"2\", \"Idea\" : \"3\", \"BSNL\" :\"4\",\"MTNL\" :\"5\",\"Tata Docomo\" :\"6\",\"T24\" :\"7\" }";
    private JSONObject circlej;
    private List<Object> contents;
    private Context context;
    private TypedArray service;
    private TypedArray sservice;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_recharge_plan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RechargePlan recharge_Plan = (RechargePlan) contents.get(position);

            TextView textView = holder.itemprice;
            textView.setText("₹ " + recharge_Plan.getPrice());
            TextView textView2 = holder.itemvalidity;
            textView2.setText("Validity : " + recharge_Plan.getValidity());
            if (recharge_Plan.getDetail().equals("")) {
                TextView textView3 = holder.itemdesc;
                textView3.setText("Talktime ₹ " + recharge_Plan.getTalktime());
            } else {
                holder.itemdesc.setText(recharge_Plan.getDetail());
            }
        //     holder.itemprice.setBackground(service.getDrawable(Integer.parseInt(circlej.getString(RechargePlanActivity.operator))));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showDialog(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return contents.size();
    }

    public RechargePlanAdapter(Context context2, List<Object> list) {
        contents = list;
        context = context2;
        service = context2.getResources().obtainTypedArray(R.array.operator);
        sservice = context2.getResources().obtainTypedArray(R.array.operators);
        try {
            circlej = new JSONObject(Circlejson);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void showDialog(int i) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        RechargePlan recharge_Plan = (RechargePlan) contents.get(i);
        builder.setTitle(RechargePlanActivity.operator + "-" + RechargePlanActivity.circle1);
        Integer price = recharge_Plan.getPrice();
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(price);
        String validity = recharge_Plan.getValidity();
        if (recharge_Plan.getDetail().equals("")) {
            stringBuilder.append("Talktime ₹ ");
            Double aDouble = recharge_Plan.getTalktime();
            stringBuilder.append(aDouble);
        } else {
            str = recharge_Plan.getDetail();
            stringBuilder.append(str);
        }
        Log.e("sdkjsdkskds", stringBuilder1.toString());
        Log.e("sdkjsdkskds1", stringBuilder.toString());
        builder.setMessage("Price :₹" + stringBuilder1.toString() + "\nValidity :" + validity + "\n\nDetails :" + stringBuilder.toString() + "\n\nUpdated On :" + recharge_Plan.getUpdated());
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView itemdesc;
        TextView itemprice;
        TextView itemvalidity;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemprice = itemView.findViewById(R.id.tv_price);
            itemdesc = itemView.findViewById(R.id.description);
            itemvalidity = itemView.findViewById(R.id.txtvalid);
        }
    }
}
