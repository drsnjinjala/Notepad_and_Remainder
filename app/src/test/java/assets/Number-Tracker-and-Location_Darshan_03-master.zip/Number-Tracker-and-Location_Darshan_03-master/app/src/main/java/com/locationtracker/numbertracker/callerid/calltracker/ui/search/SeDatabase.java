package com.locationtracker.numbertracker.callerid.calltracker.ui.search;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class SeDatabase extends SQLiteOpenHelper {
    private static String DB_NAME = "mobileNumberfinderdatabase.db";
    private static String DB_PATH = "";
    private final Context mContext;
    private SQLiteDatabase mDataBase;

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    SeDatabase(Context context) {
        super(context, DB_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        this.mContext = context;
    }

    private boolean checkDataBase() {
        return new File(DB_PATH + DB_NAME).exists();
    }

    private void copyDataBase() throws IOException {
        InputStream open = this.mContext.getAssets().open(DB_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(DB_PATH + DB_NAME);
        byte[] bArr = new byte[63];
        while (true) {
            int read = open.read(bArr);
            if (read <= 0) {
                fileOutputStream.flush();
                fileOutputStream.close();
                open.close();
                return;
            }
            fileOutputStream.write(bArr, 0, read);
        }
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        if (sQLiteDatabase != null) {
            sQLiteDatabase.close();
        }
        super.close();
    }

    public void createDataBase() {
        if (!checkDataBase()) {
            getReadableDatabase();
            close();
        }
        try {
            copyDataBase();
        } catch (IOException unused) {
          unused.printStackTrace();
        }
    }

    public void openDataBase() throws SQLException {
        this.mDataBase = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME, null, SQLiteDatabase.CREATE_IF_NECESSARY);
    }
}
