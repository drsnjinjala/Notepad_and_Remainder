package com.locationtracker.numbertracker.callerid.calltracker.ui.search;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class SearchDatabase {
    private SeDatabase dataBase;
    private SQLiteDatabase db;
    String tablename = "mobileNumberfinder";

    public SearchDatabase(Context context) {
        this.dataBase = new SeDatabase(context);
    }

    public void createDatabase() {
        this.dataBase.createDataBase();
    }

    public Cursor get_details(String str, String str2) {
        try {
            SQLiteDatabase sQLiteDatabase = this.db;
            Cursor rawQuery = sQLiteDatabase.rawQuery("select  *  from " + this.tablename + " where mobilenumber=" + str, null);
            if (rawQuery != null) {
                rawQuery.moveToNext();
            }
            return rawQuery;
        } catch (Exception e) {
            Log.e("ccc", "getTestData >>" + e.toString());
            throw e;
        }
    }

    public void open() {
        try {
            dataBase.openDataBase();
            this.dataBase.close();
            this.db = this.dataBase.getReadableDatabase();
        } catch (Exception e) {
            Log.e("error", "open >>" + e.toString());
            throw e;
        }
    }
}
