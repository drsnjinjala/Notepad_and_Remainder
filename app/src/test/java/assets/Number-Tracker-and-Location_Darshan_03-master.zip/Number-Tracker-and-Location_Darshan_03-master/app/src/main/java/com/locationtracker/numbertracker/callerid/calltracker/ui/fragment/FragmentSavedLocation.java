package com.locationtracker.numbertracker.callerid.calltracker.ui.fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MyAddressesViewModel;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.AddressAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.FragmentSavedLocationBinding;

import think.outside.the.box.handler.APIManager;

public class FragmentSavedLocation extends Fragment {

    private FragmentSavedLocationBinding binding;
    private static final String TAG = "FragmentSavedLocation";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSavedLocationBinding.inflate(inflater, container, false);
        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //  APIManager.showBanner(binding.ads65);
        binding.btnBack.setOnClickListener(view1 -> getActivity().onBackPressed());

        binding.rvSavedLoc.setLayoutManager(new LinearLayoutManager(requireContext()));

        final AddressAdapter addressAdapter = new AddressAdapter();
        binding.rvSavedLoc.setAdapter(addressAdapter);
        final MyAddressesViewModel myAddressesViewModel = (MyAddressesViewModel) ViewModelProviders.of(this).get(MyAddressesViewModel.class);
        myAddressesViewModel.getAllNotes().observe(getActivity(), list -> {
            addressAdapter.submitList(list);
            if (list.isEmpty()) {
                binding.layoutNoData.setVisibility(View.VISIBLE);
            }
        });

        addressAdapter.setOnItemClickListener((i, myAddresses, str) -> {
            AlertDialog create = new AlertDialog.Builder(getContext()).create();
            create.setTitle("Alert");
            create.setMessage("Are you sure you want to delete ?");
            create.setButton(-1, "yes", (dialogInterface, i1) -> {
                myAddressesViewModel.delete(myAddresses);
                dialogInterface.dismiss();
            });
            create.setButton(-2, "cancel", (dialogInterface, i12) -> dialogInterface.dismiss());
            create.show();
        });

        binding.btnSaveLocation.setOnClickListener(view1 -> {
            FragmentShareLocation shareLocationFrag = new FragmentShareLocation();
            FragmentTransaction beginTransaction = getParentFragmentManager().beginTransaction();
            beginTransaction.replace(R.id.commonContainer, shareLocationFrag);
            beginTransaction.commit();
        });
    }
}