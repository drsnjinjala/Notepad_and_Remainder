package com.locationtracker.numbertracker.callerid.calltracker.DataBase;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "MyAddresses")
public class MyAddresses {

    @ColumnInfo(name = "address")
    String address;
    @ColumnInfo(name = "dateTime")
    String dateTime;

    @PrimaryKey(autoGenerate = true)
    int id;

    @ColumnInfo(name = "lat")
    double lat;

    @ColumnInfo(name = "lng")
    double lng;

    @ColumnInfo(name = "title")
    String title;

    public MyAddresses(){

    }

    public MyAddresses(String str, String str2, double d, double d2, String str3) {
        this.title = str;
        this.address = str2;
        this.lat = d;
        this.lng = d2;
        this.dateTime = str3;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String str) {
        this.address = str;
    }

    public double getLat() {
        return this.lat;
    }

    public void setLat(double d) {
        this.lat = d;
    }

    public double getLng() {
        return this.lng;
    }

    public void setLng(double d) {
        this.lng = d;
    }

    public String getDateTime() {
        return this.dateTime;
    }

    public void setDateTime(String str) {
        this.dateTime = str;
    }
}
