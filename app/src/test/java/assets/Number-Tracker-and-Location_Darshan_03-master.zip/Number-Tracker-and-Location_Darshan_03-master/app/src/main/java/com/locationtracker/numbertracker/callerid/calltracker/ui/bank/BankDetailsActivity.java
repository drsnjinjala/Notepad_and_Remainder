package com.locationtracker.numbertracker.callerid.calltracker.ui.bank;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityBankDetailsBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Store;

import think.outside.the.box.handler.APIManager;

public class BankDetailsActivity extends ParentActivity {

    private ActivityBankDetailsBinding binding;
    private static final String TAG = "BankDetailsActivity";
    String bankName;
    String customer;
    String enquiry;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_bank_details);

        enquiry = getIntent().getStringExtra("enquiry");
        customer = getIntent().getStringExtra("customer");
        bankName = getIntent().getStringExtra("bankName");
        name = getIntent().getStringExtra("bank_name");

        initView();

        APIManager.showBanner(binding.ads65);
        APIManager.showSmallNative(binding.ads130);
        binding.btnBack.setOnClickListener(view -> onBackPressed());
    }

    private void initView() {
        binding.balanceNumber.setText(Store.bank_inquiry);
        binding.customerNumber.setText(Store.bank_care);
        binding.bankName.setText(name);
        byte[] byteArray = getIntent().getExtras().getByteArray("bank_img");
        ((ImageView) findViewById(R.id.bank_img)).setImageBitmap(BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length));
        binding.checkBalance.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    String str = Store.bank_inquiry;
                    Intent intent = new Intent("android.intent.action.DIAL");
                    intent.setData(Uri.parse("tel:" + str));
                    startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                }
            }
        });
        binding.btnCheckCustomer.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    String str = Store.bank_care;
                    Intent intent = new Intent("android.intent.action.DIAL");
                    intent.setData(Uri.parse("tel:" + str));
                    startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                }
            }
        });
    }
}