package com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo;

import android.os.Bundle;
import android.util.Log;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentTransaction;

import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivitySaveLocationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.fragment.FragmentSavedLocation;
import com.locationtracker.numbertracker.callerid.calltracker.ui.fragment.FragmentShareLocation;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import think.outside.the.box.handler.APIManager;

public class SaveLocationActivity extends ParentActivity {

    private ActivitySaveLocationBinding binding;
    private static final String TAG = "CommonActivity";
    private Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setLightTheme(true);
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_save_location);



        Bundle extras = getIntent().getExtras();
        this.bundle = extras;
        if (extras.getString(Variables.KEY) != null) {
            String string = this.bundle.getString(Variables.KEY);
            if (string.equals(Variables.KEY_SHARE_LOC)) {
                FragmentShareLocation shareLocationFrag = new FragmentShareLocation();
                FragmentTransaction beginTransaction5 = getSupportFragmentManager().beginTransaction();
                beginTransaction5.replace(R.id.commonContainer, shareLocationFrag);
                beginTransaction5.addToBackStack("tag");
                beginTransaction5.commit();
            } else if (string.equals(Variables.KEY_SAVED_LOC)) {
                FragmentSavedLocation savedLocationFrag = new FragmentSavedLocation();
                FragmentTransaction beginTransaction6 = getSupportFragmentManager().beginTransaction();
                beginTransaction6.replace(R.id.commonContainer, savedLocationFrag);
                beginTransaction6.addToBackStack("tag1");
                beginTransaction6.commit();
            }
        } else {
            Log.d(TAG, "onCreate: Check your key commn acitivyt ");
        }
    }


}