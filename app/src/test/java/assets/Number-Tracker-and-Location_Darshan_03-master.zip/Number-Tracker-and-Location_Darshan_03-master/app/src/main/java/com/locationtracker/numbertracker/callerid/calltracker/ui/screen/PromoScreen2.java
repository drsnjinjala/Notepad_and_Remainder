package com.locationtracker.numbertracker.callerid.calltracker.ui.screen;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityPromoScreen2Binding;

import think.outside.the.box.handler.APIManager;

public class PromoScreen2 extends ParentActivity {

    private ActivityPromoScreen2Binding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = ActivityPromoScreen2Binding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
    }
}
