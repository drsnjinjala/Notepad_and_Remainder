package com.locationtracker.numbertracker.callerid.calltracker.ui.single;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.FuelAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityFuelCostBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;
import com.locationtracker.numbertracker.callerid.calltracker.utils.PriceApiClient;
import com.moderntoolsapp.mobilenumbertracker.Fuel.CityPrice;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import think.outside.the.box.handler.APIManager;

public class FuelCostActivity extends ParentActivity {

    private ActivityFuelCostBinding binding;
    private ProgressBar simpleProgressBar;
    private PriceApiClient priceApiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_fuel_cost);

        binding.btnBack.setOnClickListener(view -> onBackPressed());

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        initView();
    }

    @SuppressLint("ResourceType")
    private void initView() {
        binding.layoutProgress.setVisibility(View.VISIBLE);
        binding.layoutData.setVisibility(View.GONE);
        priceApiClient = new PriceApiClient(this);
        priceApiClient.getFuelPriceList(hashMap -> {
            Log.e("TAG", "onSuccess: " + hashMap.size());
            Set<String> strings = hashMap.keySet();
            ArrayList<String> arrayList = new ArrayList<>(strings);
            ArrayAdapter arrayAdapter2 = new ArrayAdapter(this, (int) R.layout.rv_spiner_item, arrayList);
            arrayAdapter2.setDropDownViewResource(17367049);
            binding.fuelSpinner.setAdapter(arrayAdapter2);
            binding.fuelSpinner.setOnItemClickListener((adapterView, view, i, l) -> setAdapter(hashMap.get(binding.fuelSpinner.getText().toString())));

            if (arrayList.size() > 0) {
                setAdapter(hashMap.get(arrayList.get(0)));
                binding.layoutProgress.setVisibility(View.GONE);
                binding.layoutData.setVisibility(View.VISIBLE);
            } else {
                binding.layoutProgress.setVisibility(View.VISIBLE);
                binding.layoutData.setVisibility(View.GONE);
            }
        });
    }

    public void setAdapter(List<CityPrice> cityPriceList) {
        binding.recyclerViewFuel.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        binding.recyclerViewFuel.setAdapter(new FuelAdapter(this, cityPriceList));
    }


}