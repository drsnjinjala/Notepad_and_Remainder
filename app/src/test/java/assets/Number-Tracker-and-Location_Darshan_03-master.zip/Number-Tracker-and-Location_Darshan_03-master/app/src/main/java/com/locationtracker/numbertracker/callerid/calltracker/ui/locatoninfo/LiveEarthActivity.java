package com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.GridLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MapUtility;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityLiveEarthBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import java.io.IOException;
import java.util.List;

import think.outside.the.box.handler.APIManager;

public class LiveEarthActivity extends ParentActivity implements View.OnClickListener, OnMapReadyCallback {

    private ActivityLiveEarthBinding binding;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private GoogleMap mMap;
    private double mLat = -1.0d;
    private double mLng = -1.0d;
    private boolean isZooming = true;
    private boolean secondClick = false;
    private Location lastKnownLocation;
    private long pressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_live_earth);

        this.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_view_satellite)).getMapAsync(this);

        binding.btnBack.setOnClickListener(view -> onBackPressed());

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);

        showCurrentLocationOnMap();
        initView();
    }

    private void initView() {

        binding.imgZoomIn.setOnClickListener(this);
        binding.imgZoomOut.setOnClickListener(this);
        binding.imgShare.setOnClickListener(this);
        binding.imgMyLocation.setOnClickListener(this);
        binding.imgSearchAddress.setOnClickListener(this);
        binding.imgShare.setOnClickListener(this);
        binding.imgTraffic.setOnClickListener(this);
        binding.layoutSearch.setOnClickListener(this);
        setGridOnClickEvent(binding.gridContainer);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.mMap = googleMap;
        googleMap.clear();
        this.mMap.setMapType(2);
        this.mMap.setOnMapClickListener(latLng -> {
            binding.tvAddressMarque.setVisibility(View.GONE);
            if (!MapUtility.isNetworkAvailable(LiveEarthActivity.this)) {
                Variables.showToast(LiveEarthActivity.this, "Please Connect to Internet");
                return;
            }
            mMap.clear();
            addMarker("", latLng.latitude, latLng.longitude);
            mLat = latLng.latitude;
            mLng = latLng.longitude;
            MapUtility.getAddressFromLatLng(LiveEarthActivity.this, latLng.latitude, latLng.longitude, binding.tvAddress, true);
        });
        updateLocationUI();
        getDeviceLocation();
    }

    private void updateLocationUI() {
        if (this.mMap != null) {
            try {
                if (MapUtility.checkAndRequestPermissions(this, this)) {
                    this.mMap.setMyLocationEnabled(true);
                    this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                    return;
                }
                this.mMap.setMyLocationEnabled(false);
                this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
                this.lastKnownLocation = null;
                Variables.checkPermission(this);
            } catch (SecurityException e) {
                Log.e("Exception: %s", e.getMessage());
            }
        }
    }

    private void getDeviceLocation() {
        try {
            if (MapUtility.checkAndRequestPermissions(this, this)) {
                this.fusedLocationProviderClient.getLastLocation().addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        lastKnownLocation = task.getResult();
                        if (lastKnownLocation != null) {
                            addMarker("", lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                            MapUtility.getAddressFromLatLng(LiveEarthActivity.this, lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude(), binding.tvAddressMarque, false);
                            mLat = lastKnownLocation.getLatitude();
                            mLng = lastKnownLocation.getLongitude();
                            if (mMap != null) {
                                mMap.setTrafficEnabled(true);
                            }
                        }
                    } else if (MapUtility.defaultLocation != null) {
                        Log.d("TAG", "Current location is null. Using defaults.");
                        Log.e("TAG", "Exception: %s", task.getException());
                        MapUtility.getAddressFromLatLng(LiveEarthActivity.this, MapUtility.defaultLocation.latitude, MapUtility.defaultLocation.longitude, binding.tvAddressMarque, false);
                        mLat = MapUtility.defaultLocation.latitude;
                        mLng = MapUtility.defaultLocation.longitude;
                        if (mMap != null) {
                            mMap.setTrafficEnabled(true);
                        }
                    } else {
                        Log.d("TAG", "Current location is null and default location cannot get .");
                        Log.e("TAG", "Exception: %s", task.getException());
                        mMap.getUiSettings().setMyLocationButtonEnabled(false);
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }

    private void showCurrentLocationOnMap() {
        binding.tvAddressMarque.setVisibility(View.GONE);
        if (MapUtility.checkAndRequestPermissions(this, this)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            if (fusedLocationProviderClient == null) {
                return;
            }
            Task<Location> lastLocation = this.fusedLocationProviderClient.getLastLocation();
            lastLocation.addOnSuccessListener(this, location -> {
                if (location != null) {
                    addMarker("", location.getLatitude(), location.getLongitude());
                    mLat = location.getLatitude();
                    mLng = location.getLongitude();
                    MapUtility.getAddressFromLatLng(LiveEarthActivity.this, location.getLatitude(), location.getLongitude(), binding.tvAddress, false);
                    binding.tvAddress.setSelection(binding.tvAddress.getText().length());
                }
                return;
            });
            lastLocation.addOnFailureListener(exc -> Variables.showToast(LiveEarthActivity.this, "Location Not Available"));
        }
    }

    public void goToLocationFromAddress(String str) {
        try {
            List<Address> fromLocationName = new Geocoder(this).getFromLocationName(str, 5);
            if (fromLocationName != null) {
                try {
                    Address address = fromLocationName.get(0);
                    addMarker("", address.getLatitude(), address.getLongitude());
                    MapUtility.getAddressFromLatLng(this, address.getLatitude(), address.getLongitude(), binding.tvAddress, true);
                    this.mLat = address.getLatitude();
                    this.mLng = address.getLongitude();
                    hideKeyboard(this);
                } catch (IndexOutOfBoundsException unused) {
                    Toast.makeText(this, "Location isn't available", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (IOException e) {
            Log.e("TAG", "goToLocationFromAddress: " + e.getMessage());
        }
    }

    private void setGridOnClickEvent(GridLayout gridLayout2) {
        for (int i = 0; i < gridLayout2.getChildCount(); i++) {
            int finalI = i;
            ((RelativeLayout) gridLayout2.getChildAt(i)).setOnClickListener(view -> changeLayout(finalI));
        }
    }

    public void onClick(View view) {
        getSharedPreferences(Variables.pref_name, 0).getString(Variables.interstitial_am_id, "");
        switch (view.getId()) {
            case R.id.imgMyLocation:
                showCurrentLocationOnMap();
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }

            case R.id.imgZoomIn:
                GoogleMap googleMap = this.mMap;
                if (googleMap != null) {
                    googleMap.animateCamera(CameraUpdateFactory.zoomTo(googleMap.getCameraPosition().zoom + 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.imgZoomOut:
                GoogleMap googleMap2 = this.mMap;
                if (googleMap2 != null) {
                    googleMap2.animateCamera(CameraUpdateFactory.zoomTo(googleMap2.getCameraPosition().zoom - 1.0f));
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.img_search_address:
                if (pressedTime + 2000 > System.currentTimeMillis()) {
                    Log.d("TAG", "onClick: do nothing when double click");
                } else if (binding.tvAddress.getText().toString() != null) {
                    goToLocationFromAddress(binding.tvAddress.getText().toString());
                }
                pressedTime = System.currentTimeMillis();
                return;
            case R.id.img_share:
                if (this.mLat == -1.0d || this.mLng == -1.0d) {
                    Toast.makeText(this, "Select Location First...", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    String obj = binding.tvAddress.getText().toString();
                    share(obj, String.valueOf(this.mLat + "," + this.mLng));
                    return;
                } catch (NullPointerException e) {
                    Log.i("TAG", "Exception  " + e.getMessage());
                    return;
                }
            case R.id.img_traffic:
                GoogleMap googleMap3 = this.mMap;
                if (googleMap3 != null) {
                    googleMap3.setTrafficEnabled(!googleMap3.isTrafficEnabled());
                    if (this.mMap.isTrafficEnabled()) {
                        binding.imgTraffic.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_traffic));
                    } else {
                        binding.imgTraffic.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_traffic));
                    }
                }
                if (this.secondClick) {
                    this.secondClick = false;
                    return;
                } else {
                    this.secondClick = true;
                    return;
                }
            case R.id.layoutSearch:
                binding.tvAddress.setText((CharSequence) null);
                return;
            default:
                return;
        }
    }

    private void changeLayout(int i) {
        if (i == 0) {
            GoogleMap googleMap = this.mMap;
            if (googleMap != null) {
                googleMap.setMapType(2);
                this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_stander)));
            }

        } else if (i == 1) {
            GoogleMap googleMap2 = this.mMap;
            if (googleMap2 != null) {
                googleMap2.setMapType(1);
                this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_stander)));
            }

        } else if (i == 2) {
            GoogleMap googleMap3 = this.mMap;
            if (googleMap3 != null) {
                googleMap3.setMapType(1);
                this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_json)));
            }

        } else if (i == 3) {
            GoogleMap googleMap4 = this.mMap;
            if (googleMap4 != null) {
                googleMap4.setMapType(3);
                this.mMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_stander)));
            }

        }
        if (this.secondClick) {
            this.secondClick = false;
        } else {
            this.secondClick = true;
        }
    }

    private void addMarker(String str, double d, double d2) {
        CameraUpdate cameraUpdate;
        LatLng latLng = new LatLng(d, d2);
        GoogleMap googleMap = this.mMap;
        if (googleMap != null) {
            try {
                googleMap.clear();
                MarkerOptions position = new MarkerOptions().position(latLng);
                MarkerOptions title = position.title(d + "," + d2);
                if (this.isZooming) {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 15.0f);
                } else {
                    cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, this.mMap.getCameraPosition().zoom);
                }
                this.mMap.animateCamera(cameraUpdate);
                this.mMap.addMarker(title);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        str.equals("search");
    }

    public static void hideKeyboard(Context context) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
            if (inputMethodManager.isActive()) {
                inputMethodManager.hideSoftInputFromWindow(((Activity) context).getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void share(String str, String str2) {
        String str3 = "Address:\n" + str + "\n--------------------------------\nClick to navigate:\nhttp://www.google.com/maps?daddr=" + str2 + "\n--------------------------------\n";
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
            intent.putExtra("android.intent.extra.TEXT", str3 + ("\nLet me recommend you this application\n\n" + "https://play.google.com/store/apps/details?id=" + getPackageName() + "\n\n"));
            startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}