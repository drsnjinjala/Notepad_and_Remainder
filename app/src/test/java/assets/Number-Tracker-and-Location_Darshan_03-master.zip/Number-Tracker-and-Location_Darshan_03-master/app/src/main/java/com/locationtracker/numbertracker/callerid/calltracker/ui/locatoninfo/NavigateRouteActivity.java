package com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo;

import android.os.Bundle;
import android.util.Log;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentTransaction;

import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityNavigateRouteBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.fragment.FragmentNavigationRouteFinder;
import com.locationtracker.numbertracker.callerid.calltracker.ui.fragment.FragmentNavigationVoice;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import think.outside.the.box.handler.APIManager;

public class NavigateRouteActivity extends ParentActivity {

    private ActivityNavigateRouteBinding binding;
    private static final String TAG = "NavigateRouteActivity";
    private String key = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_navigate_route);

        Bundle extras = getIntent().getExtras();
        if (extras.getString(Variables.KEY) != null) {
            String string = extras.getString(Variables.KEY);
            this.key = string;
            if (string.equals(Variables.KEY_VOICE)) {
                Bundle bundle2 = new Bundle();
                bundle2.putDouble(Variables.KEY_LAT, extras.getDouble(Variables.KEY_LAT));
                bundle2.putDouble(Variables.KEY_LNG, extras.getDouble(Variables.KEY_LNG));
                FragmentNavigationVoice actionNavigationVoiceFrag = new FragmentNavigationVoice();
                actionNavigationVoiceFrag.setArguments(bundle2);
                FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
                beginTransaction.replace(R.id.actionContainer, actionNavigationVoiceFrag);
                beginTransaction.commit();
            } else if (this.key.equals(Variables.KEY_ROUTE_FINDER)) {
                Bundle bundle3 = new Bundle();
                bundle3.putDouble(Variables.KEY_LAT_ORG, extras.getDouble(Variables.KEY_LAT_ORG));
                bundle3.putDouble(Variables.KEY_LNG_ORG, extras.getDouble(Variables.KEY_LNG_ORG));
                bundle3.putDouble(Variables.KEY_LAT_DES, extras.getDouble(Variables.KEY_LAT_DES));
                bundle3.putDouble(Variables.KEY_LNG_DES, extras.getDouble(Variables.KEY_LNG_DES));
                FragmentNavigationRouteFinder actionNavigationRouteFinderFrag = new FragmentNavigationRouteFinder();
                actionNavigationRouteFinderFrag.setArguments(bundle3);
                FragmentTransaction beginTransaction2 = getSupportFragmentManager().beginTransaction();
                beginTransaction2.replace(R.id.actionContainer, actionNavigationRouteFinderFrag);
                beginTransaction2.commit();
            } else {
                Log.e(TAG, "onCreate: Check your key ");
            }
        }
    }


}