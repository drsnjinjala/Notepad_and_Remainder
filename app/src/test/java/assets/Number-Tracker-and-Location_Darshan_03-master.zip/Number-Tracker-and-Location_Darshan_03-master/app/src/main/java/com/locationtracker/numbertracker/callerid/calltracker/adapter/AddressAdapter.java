package com.locationtracker.numbertracker.callerid.calltracker.adapter;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.kwabenaberko.openweathermaplib.BuildConfig;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.MyAddresses;
import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo.NavigateRouteActivity;

import think.outside.the.box.handler.APIManager;

public class AddressAdapter extends ListAdapter<MyAddresses, AddressAdapter.ItemViewHolder> {
    private static final DiffUtil.ItemCallback<MyAddresses> DIFF_CALLBACK = new DiffUtil.ItemCallback<MyAddresses>() {


        public boolean areContentsTheSame(MyAddresses myAddresses, MyAddresses myAddresses2) {
            return false;
        }

        public boolean areItemsTheSame(MyAddresses myAddresses, MyAddresses myAddresses2) {
            return myAddresses.getId() == myAddresses2.getId();
        }
    };
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int i, MyAddresses myAddresses, String str);
    }

    public AddressAdapter() {
        super(DIFF_CALLBACK);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mListener = onItemClickListener;
    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_save_address, viewGroup, false));
    }

    public void onBindViewHolder(ItemViewHolder itemViewHolder, int i) {
        MyAddresses myAddresses = (MyAddresses) getItem(i);
        itemViewHolder.title.setText(myAddresses.getTitle());
        itemViewHolder.address.setText(myAddresses.getAddress());
        itemViewHolder.dateTime.setText(myAddresses.getDateTime());
    }

    /* access modifiers changed from: package-private */
    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView address;
        TextView dateTime;
        ImageView imgDelete;
        LinearLayout layout1;
        LinearLayout layout2;
        LinearLayout layout3;
        LinearLayout layout4;
        TextView title;

        public ItemViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.tv_title);
            this.address = (TextView) view.findViewById(R.id.tv_address);
            this.dateTime = (TextView) view.findViewById(R.id.tv_date_time);
            ImageView imageView = (ImageView) view.findViewById(R.id.img_del);
            this.imgDelete = imageView;
            imageView.setOnClickListener(this);
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.layout1);
            this.layout1 = linearLayout;
            linearLayout.setOnClickListener(this);
            LinearLayout linearLayout2 = (LinearLayout) view.findViewById(R.id.layout2);
            this.layout2 = linearLayout2;
            linearLayout2.setOnClickListener(this);
            LinearLayout linearLayout3 = (LinearLayout) view.findViewById(R.id.layout3);
            this.layout3 = linearLayout3;
            linearLayout3.setOnClickListener(this);
            LinearLayout linearLayout4 = (LinearLayout) view.findViewById(R.id.layout4);
            this.layout4 = linearLayout4;
            linearLayout4.setOnClickListener(this);
        }

        public void onClick(View view) {
            int adapterPosition = getAdapterPosition();
            if (adapterPosition != -1) {
                int id = view.getId();
                if (id != R.id.img_del) {
                    switch (id) {
                        case R.id.layout1:
                            AddressAdapter addressAdapter = AddressAdapter.this;
                            addressAdapter.sharePin(((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getLat() + "," + ((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getLng(), this.layout1.getContext());
                            return;
                        case R.id.layout2:
                            AddressAdapter.this.copyContext(this.layout2.getContext(), ((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getAddress());
                            return;
                        case R.id.layout3:
                            Context context = this.layout3.getContext();
                            Bundle bundle = new Bundle();
                            bundle.putString(Variables.KEY, Variables.KEY_VOICE);
                            bundle.putDouble(Variables.KEY_LAT, ((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getLat());
                            bundle.putDouble(Variables.KEY_LNG, ((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getLng());
                            APIManager.showInter((Activity) context, false, isfail -> {
                                Intent intent = new Intent(context, NavigateRouteActivity.class);
                                intent.putExtras(bundle);
                                context.startActivity(intent);
                            });
                            return;
                        case R.id.layout4:

                            AddressAdapter addressAdapter2 = AddressAdapter.this;
                            String address2 = ((MyAddresses) addressAdapter2.getItem(adapterPosition)).getAddress();
                            addressAdapter2.shareAddress(address2, ((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getLat() + "," + ((MyAddresses) AddressAdapter.this.getItem(adapterPosition)).getLng(), this.layout4.getContext());
                            return;
                        default:
                            return;
                    }
                } else if (AddressAdapter.this.mListener != null) {
                    AddressAdapter.this.mListener.onItemClick(adapterPosition, (MyAddresses) AddressAdapter.this.getItem(adapterPosition), "del");
                }
            }
        }
    }

    private void shareAddress(String str, String str2, Context context) {
        String str3 = "Address:\n" + str + "\n--------------------------------\nClick to navigate:\nhttp://www.google.com/maps?daddr=" + str2 + "\n--------------------------------\n";
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", context.getString(R.string.app_name));
            intent.putExtra("android.intent.extra.TEXT", str3 + ("\nLet me recommend you this application\n\n" + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n"));
            context.startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sharePin(String str, Context context) {
        String str2 = "Click to navigate:\nhttp://www.google.com/maps?daddr=" + str;
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", context.getString(R.string.app_name));
            intent.putExtra("android.intent.extra.TEXT", str2);
            context.startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void copyContext(Context context, String str) {
        try {
            ((ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Address ", str));
            Toast.makeText(context, "Address Copied To Clipboard", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.getMessage();
        }
    }
}
