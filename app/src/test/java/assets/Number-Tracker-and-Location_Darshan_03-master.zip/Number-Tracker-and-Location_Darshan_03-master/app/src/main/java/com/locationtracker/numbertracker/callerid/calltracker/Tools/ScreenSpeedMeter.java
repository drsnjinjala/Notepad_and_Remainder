package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ScreenSpeedMeterBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.CheckGps;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import think.outside.the.box.handler.APIManager;

public class ScreenSpeedMeter extends ParentActivity {

    private ScreenSpeedMeterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ScreenSpeedMeterBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        binding.back.setOnClickListener(v -> onBackPressed());
        APIManager.showSmallNative(binding.nativeContainer);
        APIManager.showBanner(binding.bannerContainer);
        binding.ivDigital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CheckGps.isLocationEnabled(ScreenSpeedMeter.this)) {
                   APIManager.showInter(ScreenSpeedMeter.this, false, isfail -> {
                        startActivity(new Intent(ScreenSpeedMeter.this, ScreenDigitalMeter.class));
                     });
                } else {
                    showGPSDisabledAlertToUser();
                }
            }
        });

        binding.ivSport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CheckGps.isLocationEnabled(ScreenSpeedMeter.this)) {
                     APIManager.showInter(ScreenSpeedMeter.this, false, isfail -> {
                        startActivity(new Intent(ScreenSpeedMeter.this, ScreenSportMeter.class));
                    });
                } else {
                    showGPSDisabledAlertToUser();
                }
            }
        });
    }

    public void showGPSDisabledAlertToUser() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.no_gps)).setCancelable(false).setPositiveButton(getResources().getString(R.string.enable_gps), (dialogInterface, i) -> startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS")));
        builder.setNegativeButton(getResources().getString(R.string.compass_cancel), (dialogInterface, i) -> dialogInterface.cancel());
        AlertDialog create = builder.create();
        builder.setCancelable(false);
        create.show();
    }


}