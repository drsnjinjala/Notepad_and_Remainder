package com.locationtracker.numbertracker.callerid.calltracker.ui.defaults

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Window
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.databinding.DataBindingUtil
import com.locationtracker.numbertracker.callerid.calltracker.R
import com.locationtracker.numbertracker.callerid.calltracker.Tools.ScreenSpeedMeter
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityMainBinding
import com.locationtracker.numbertracker.callerid.calltracker.databinding.DailogPermissonBinding
import com.locationtracker.numbertracker.callerid.calltracker.ui.bank.BankInformationActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.locatoninfo.LocationInfoMainActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.search.ActivitySearchNumber
import com.locationtracker.numbertracker.callerid.calltracker.ui.settings.SettingActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.simcard.SimCardInfoActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.single.*
import com.locationtracker.numbertracker.callerid.calltracker.ui.traffic.TrafficInfoActivity
import com.locationtracker.numbertracker.callerid.calltracker.utils.CheckGps
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.callback.DialogCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.showBanner
import think.outside.the.box.handler.APIManager.showExitDialog
import think.outside.the.box.handler.APIManager.showInter
import think.outside.the.box.handler.APIManager.showNative
import think.outside.the.box.handler.APIManager.showRattingDialog
import think.outside.the.box.ui.BaseActivity

class MainActivity : BaseActivity() {
    private lateinit var binding: ActivityMainBinding
    var dialog: Dialog? = null
    private var overlayPermission = false
    var doubleBackToExitPressedOnce = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setLightTheme(true)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        if (APIManager.isUpdate()) {
            APIManager.showUpdateDialog(this);
        }
        try {
            overlayPermission = !APIManager.getExtraData()?.getString("display_overlay").equals("1")
        } catch (ex: Exception) {
            Log.e("TAG", "onCreate: " + ex.message)
        }
        APIManager.showNative(binding.ads200)
        APIManager.showBanner(binding.ads65)

        initView()
    }

    @SuppressLint("SuspiciousIndentation")
    private fun initView() {
        binding.btnNumberfinder.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, ActivitySearchNumber::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }
        binding.btnLocationInfo.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            if (CheckGps.isLocationEnabled(this@MainActivity)) {
                val intent = Intent(this, LocationInfoMainActivity::class.java)
                showInter(this@MainActivity, false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        startActivity(intent)
                    }
                })
            } else {
                showGPSDisabledAlertToUser()
            }
        }

        binding.btnRechargePlan.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, RechargeActivity::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }

        binding.btnDistanceFinder.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            if (CheckGps.isLocationEnabled(this@MainActivity)) {
                val intent = Intent(this, DistanceFinderActivity::class.java)
                showInter(this@MainActivity, false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        startActivity(intent)
                    }
                })
            } else {
                showGPSDisabledAlertToUser()
            }
        }

        binding.btnGpsInformation.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            if (CheckGps.isLocationEnabled(this@MainActivity)) {
                val intent = Intent(this@MainActivity, GpsInformationActivity::class.java)
                showInter(this@MainActivity, false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        startActivity(intent)
                    }
                })
            } else if (!isFinishing) {
                showGPSDisabledAlertToUser()
            }
        }

        binding.btnSimCardInformation.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, SimCardInfoActivity::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }

        binding.btnBankInformation.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, BankInformationActivity::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }

        binding.btnTrafficArea.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, TrafficInfoActivity::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }

        binding.btnLiveWeather.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            if (CheckGps.isLocationEnabled(this@MainActivity)) {
                val intent = Intent(this, WeatherInformationActivity::class.java)
                showInter(this@MainActivity, false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        startActivity(intent)
                    }
                })
            } else if (!isFinishing) {
                showGPSDisabledAlertToUser()
            }
        }

        binding.btnNearByMe.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            if (CheckGps.isLocationEnabled(this@MainActivity)) {
                showInter(this@MainActivity, false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        startActivity(Intent(applicationContext, NearLocationActivity::class.java))
                    }
                })
            } else if (!isFinishing) {
                showGPSDisabledAlertToUser()
            }
        }

        binding.btnFuelCost.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, FuelCostActivity::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }
        binding.btnSetting.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, ScreenSpeedMeter::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }
        binding.btnTools.setOnClickListener {
            if (!showOver()) {
                showAlertDialogButtonClicked()
                return@setOnClickListener
            }
            val intent = Intent(this, SettingActivity::class.java)
            showInter(this@MainActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    startActivity(intent)
                }
            })
        }
    }

    private fun showGPSDisabledAlertToUser() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(resources.getString(R.string.no_gps)).setCancelable(false)
            .setPositiveButton(
                resources.getString(R.string.enable_gps)
            ) { _: DialogInterface?, i: Int -> startActivity(Intent("android.settings.LOCATION_SOURCE_SETTINGS")) }
        builder.setNegativeButton(resources.getString(R.string.compass_cancel)) { dialogInterface: DialogInterface, i: Int -> dialogInterface.cancel() }
        val create = builder.create()
        builder.setCancelable(false)
        create.show()
    }

    override fun onBackPressed() {
        APIManager.showExitDialog(this);
    }


    private fun showAlertDialogButtonClicked() {
        var bindingDialog = DailogPermissonBinding.inflate(layoutInflater)
        dialog = Dialog(this@MainActivity)
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog?.setContentView(bindingDialog.root)
        bindingDialog.Cmtfal22072207btnOverLay.setOnClickListener {
            val intent1 = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")
            )
            someActivityResultLauncher.launch(intent1)
            Handler(Looper.myLooper()!!).postDelayed({
                val intent = Intent(this@MainActivity, PromptActivity::class.java)
                intent.putExtra("PROMPT_TYPE", 0)
                startActivity(intent)
            }, 100L)
        }
        dialog?.show()
    }

    private var someActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            overlayPermission = true
            dialog?.dismiss()
        }

    private fun showOver(): Boolean {
        return true // overlayPermission || Settings.canDrawOverlays(this@MainActivity)
    }
}