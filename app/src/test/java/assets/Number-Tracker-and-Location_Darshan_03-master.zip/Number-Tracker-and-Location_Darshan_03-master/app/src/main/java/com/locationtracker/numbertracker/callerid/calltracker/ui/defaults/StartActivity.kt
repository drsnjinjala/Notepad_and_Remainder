package com.locationtracker.numbertracker.callerid.calltracker.ui.defaults

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.locationtracker.numbertracker.callerid.calltracker.R
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityStartBinding
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ItemAd65Binding
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ItemAdBinding
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.PromoScreen2
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.PromoScreen3
import com.locationtracker.numbertracker.callerid.calltracker.utils.MaterialRatingApp
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.callback.DialogCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.isUpdate
import think.outside.the.box.handler.APIManager.showInter
import think.outside.the.box.handler.APIManager.showPromoAdDialog
import think.outside.the.box.handler.APIManager.showUpdateDialog

class StartActivity : ParentActivity() {
    private lateinit var binding: ActivityStartBinding
    var doubleBackToExitPressedOnce = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setLightTheme(true)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_start)
      // showNative(binding.adsNative200)
      //  showPromoAdDialog(this, true)
//        if (isUpdate()) {
//            showUpdateDialog(this)
//        }

//        if (APIManager.isHiddenAds()) {
//            for (i in 1..APIManager.getHiddenAdsCount()) {
//                if (i % 2 == 0) {
//                    val child: ItemAd65Binding = ItemAd65Binding.inflate(layoutInflater)
//                   //  APIManager.showBannerForcefully(child.adContainerBanner)
//                    binding.layAds.addView(child.root)
//                } else {
//                    val child: ItemAdBinding = ItemAdBinding.inflate(layoutInflater)
//                    APIManager.showNative(child.adContainer)
//                    binding.layAds.addView(child.root)
//                }
//            }
//        }

        binding.btnStart.setOnClickListener { view: View? ->
          showInter(this@StartActivity, false, object : AdsCallback {
                 override fun onClose(isfail: Boolean) {

                    startActivity(Intent(this@StartActivity, PromoScreen3::class.java))
               }
             })
        }
        binding.btnShare.setOnClickListener { view: View? ->
            val app = getString(R.string.app_name)
            val share = Intent("android.intent.action.SEND")
            share.type = "text/plain"
            share.putExtra(
                "android.intent.extra.TEXT",
                """$app     Open this Link on Play Store https://play.google.com/store/apps/details?id=$packageName""".trimIndent()
            )
            startActivity(Intent.createChooser(share, "Share Application"))
        }
        binding.btnPrivacy.setOnClickListener {
            showInter(object : AdsCallback {
               override fun onClose(isfail: Boolean) {
                    val intent = Intent(this@StartActivity, PromoScreen2::class.java)
                    intent.putExtra("isStart", true)
                    startActivity(intent)
                 }
           })
        }
        binding.btnRate.setOnClickListener { view: View? ->
            val materialRatingApp = MaterialRatingApp(this@StartActivity, object : DialogCallback {
                override fun onFinish() {
                }
            })
            materialRatingApp.showNow(supportFragmentManager, "")
        }
    }

    override fun onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            finishAffinity()
            return
        }
        doubleBackToExitPressedOnce = true
        Toast.makeText(this, "Please Click Back Again To Exit", Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
    }


}