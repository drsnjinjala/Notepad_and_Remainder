package com.locationtracker.numbertracker.callerid.calltracker.ui.defaults

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.locationtracker.numbertracker.callerid.calltracker.R
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityPermissionBinding
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity
import com.locationtracker.numbertracker.callerid.calltracker.utils.PERMISSIONS
import com.locationtracker.numbertracker.callerid.calltracker.utils.hasPermissions
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.showInter


class PermissionActivity : ParentActivity() {
    lateinit var binding: ActivityPermissionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        try {
            val s = APIManager.getExtraData()?.getString("PermissionNativeStatus")
            if (s == "ON") {
                APIManager.showTopNative(binding.nativePermission)
            }
        } catch (e: Exception) {

        }

        binding.swPermission.setOnCheckedChangeListener { _, z ->
            if (z) {
                checkPermissionCamera()
            }
        }
        binding.btnSkip.setOnClickListener {
            goNext()
        }
        binding.btnContinue.setOnClickListener {
            if (hasPermissions(PERMISSIONS)) {
                goNext()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun goNext() {
        showInter(this@PermissionActivity, false, object : AdsCallback {
            override fun onClose(isfail: Boolean) {
                val mainIntent = Intent(this@PermissionActivity, MainActivity::class.java)
                startActivity(mainIntent)
                finish()
            }
        })

    }

    override fun onResume() {
        super.onResume()
        if (hasPermissions(PERMISSIONS)) {
            binding.swPermission.isChecked = true
            binding.animHand.visibility = View.GONE
            binding.swPermission.isEnabled = false
            binding.btnSkip.visibility = View.GONE
            binding.statusPermission.text = getString(R.string.permission_allowed)
            binding.statusPermission.setTextColor(getColor(R.color.blue))
            return
        }
        binding.swPermission.isChecked = false
        binding.statusPermission.text = getString(R.string.permission_is_not_allow)
        binding.statusPermission.setTextColor(getColor(R.color.red))
    }


    private fun checkPermissionCamera() {
        if (!hasPermissions(PERMISSIONS)) {
            storagePermission.launch(PERMISSIONS)
            binding.swPermission.isChecked = false
            binding.statusPermission.text = getString(R.string.permission_is_not_allow)
            binding.statusPermission.setTextColor(getColor(R.color.red))
            return
        }
        binding.swPermission.isChecked = true
        binding.statusPermission.text = getString(R.string.permission_allowed)
        binding.statusPermission.setTextColor(getColor(R.color.blue))
        binding.animHand.visibility = View.GONE
    }


    override fun onBackPressed() {
        finish()
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            if (!hasPermissions(PERMISSIONS)) {
                this.binding.swPermission.isChecked = false
                displayDialogCamera()
                this.binding.statusPermission.text = getString(R.string.permission_is_not_allow)
                this.binding.statusPermission.setTextColor(getColor(R.color.red))
                return@registerForActivityResult
            }
            this.binding.swPermission.isChecked = true
            this.binding.swPermission.isEnabled = false
            this.binding.statusPermission.text = getString(R.string.permission_allowed)
            this.binding.statusPermission.setTextColor(getColor(R.color.blue))
            this.binding.animHand.visibility = View.GONE
            this.binding.btnSkip.visibility = View.GONE
        }

    private fun displayDialogCamera() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(resources.getString(R.string.per_mission_message_camera))
        builder.setTitle(resources.getString(R.string.per_mission_title_camera))
        builder.setCancelable(false)
        builder.setPositiveButton(resources.getString(R.string.permission_go_to_setting)) { _, _ ->
            val intent = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
            intent.data = Uri.parse("package:$packageName")
            startActivityForResult(intent, 0)
        }
        builder.setNegativeButton(resources.getString(R.string.permission_cancel)) { dialogInterface, i ->
            dialogInterface.dismiss()
        }
        builder.create().show()
    }


}