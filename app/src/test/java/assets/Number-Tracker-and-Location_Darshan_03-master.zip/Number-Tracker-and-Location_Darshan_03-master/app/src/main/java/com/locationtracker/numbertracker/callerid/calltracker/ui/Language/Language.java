package com.locationtracker.numbertracker.callerid.calltracker.ui.Language;

public class Language {
    private int img;
    private String key;
    private String name;

    public Language(int img, String name, String key) {
        this.img = img;
        this.key = key;
        this.name = name;
    }

    public int getImg() {
        return img;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setName(String name) {
        this.name = name;
    }
}
