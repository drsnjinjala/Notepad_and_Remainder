package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.locationtracker.numbertracker.callerid.calltracker.R;

public class Speedometer extends View {
    public int a = Color.argb(255, 62, 62, 62);
    public int f2206b = Color.argb(255, 198, 1, 0);
    public float f2207c = 200.0f;
    public int f2208d = Color.argb(255, 198, 1, 0);
    public float f2209e = 31.0f;
    public float f2210f;
    public float f2211g;
    public float f2212h;
    public float f2213i;
    public Paint f2214j;
    public Path k;
    public Paint l;
    public Path m;
    public final RectF n = new RectF();
    public float o;
    public Paint p;
    public Paint q;
    public Paint r;
    public static final int[] aA = {R.attr.sv_backgroundCircleColor, R.attr.sv_cutPadding, R.attr.sv_endDegree, R.attr.sv_indicator, R.attr.sv_indicatorColor, R.attr.sv_indicatorLightColor, R.attr.sv_indicatorWidth, R.attr.sv_markColor, R.attr.sv_markHeight, R.attr.sv_markStyle, R.attr.sv_markWidth, R.attr.sv_marksNumber, R.attr.sv_marksPadding, R.attr.sv_speedometerMode, R.attr.sv_startDegree, R.attr.sv_tickNumber, R.attr.sv_tickPadding, R.attr.sv_tickRotation, R.attr.sv_tickTextFormat, R.attr.sv_withIndicatorLight};

    @SuppressLint("ResourceType")
    public Speedometer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, aA, 0, 0);
        try {
            this.f2213i = obtainStyledAttributes.getFloat(6, 300.0f);
            this.f2212h = obtainStyledAttributes.getFloat(5, BitmapDescriptorFactory.HUE_RED);
            this.f2206b = obtainStyledAttributes.getColor(1, this.f2206b);
            this.a = obtainStyledAttributes.getColor(0, this.a);
            this.f2208d = obtainStyledAttributes.getColor(3, this.f2208d);
            this.f2209e = obtainStyledAttributes.getDimension(4, this.f2209e);
            this.f2207c = obtainStyledAttributes.getDimension(2, this.f2207c);
            obtainStyledAttributes.recycle();
            a();
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    private int getPreferredSize() {
        return 300;
    }

    public final void a() {
        Paint paint = new Paint();
        this.l = paint;
        paint.setStyle(Paint.Style.STROKE);
        Paint paint2 = this.l;
        Context applicationContext = getContext().getApplicationContext();
        paint2.setColor(applicationContext.getColor(R.color.colorAccent));
        this.l.setStrokeWidth(35.0f);
//        this.l.setShadowLayer(5.0f, BitmapDescriptorFactory.HUE_YELLOW, BitmapDescriptorFactory.HUE_YELLOW, this.f2206b);
        this.l.setAntiAlias(true);
        Paint paint3 = new Paint(this.l);
        this.f2214j = paint3;
        paint3.setColor(this.a);
        this.f2214j.setStyle(Paint.Style.FILL_AND_STROKE);
//        this.f2214j.setShadowLayer(BitmapDescriptorFactory.HUE_YELLOW, BitmapDescriptorFactory.HUE_YELLOW, BitmapDescriptorFactory.HUE_YELLOW, this.a);
        Paint paint4 = new Paint(this.f2214j);
        this.r = paint4;
        paint4.setStrokeWidth(2.0f);
        this.r.setTextSize(this.f2209e);
//        this.r.setShadowLayer(5.0f, BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED, -65536);
        this.r.setColor(getContext().getApplicationContext().getColor(think.outside.the.box.R.color.black));
        Paint paint5 = new Paint(this.r);
        this.p = paint5;
        paint5.setStyle(Paint.Style.FILL_AND_STROKE);
//        this.f2214j.setShadowLayer(3.0f, BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED, -1);
        this.p.setTextSize(185.0f);
        this.p.setColor(getContext().getApplicationContext().getColor(think.outside.the.box.R.color.black));
        Paint paint6 = new Paint(this.p);
        this.q = paint6;
        paint6.setStyle(Paint.Style.FILL_AND_STROKE);
        this.q.setTextSize(185.0f);
        this.q.setColor(getContext().getApplicationContext().getColor(think.outside.the.box.R.color.black));
        this.m = new Path();
        this.k = new Path();
    }

    public float getCurrentSpeed() {
        return this.f2212h;
    }

    public void onDraw(Canvas canvas) {
        this.k.reset();
        int i2 = -230;
        for (int i3 = -230; i3 < 0; i3 += 4) {
            this.k.addArc(this.n, (float) i3, 2.0f);
        }
        canvas.drawPath(this.k, this.f2214j);
        this.m.reset();
        while (true) {
            float f2 = (float) i2;
            if (f2 >= ((this.f2212h / this.f2213i) * 230.0f) - 230.0f) {
                break;
            }
            this.m.addArc(this.n, f2, 2.0f);
            i2 += 4;
        }
        canvas.drawPath(this.m, this.l);
        canvas.save();
        canvas.rotate(-230.0f, this.f2210f, this.f2211g);
        Path path = new Path();
        double d2 = (double) this.o;
        Double.isNaN(d2);
        Double.isNaN(d2);
        double d3 = d2 * 3.141592653589793d;
        int i4 = 0;
        while (((float) i4) < this.f2213i) {
            path.addCircle(this.f2210f, this.f2211g, this.o, Path.Direction.CW);
            String format = String.format("%d", Integer.valueOf(i4));
            double d4 = (double) i4;
            Double.isNaN(d4);
            Double.isNaN(d4);
            canvas.drawTextOnPath(format, path, (float) ((d4 * d3) / 240.0d), -30.0f, this.r);
            Double.isNaN(d4);
            Double.isNaN(d4);
            i4 = (int) (d4 + 30.0d);
        }
        canvas.restore();
        Path path2 = new Path();
        String format2 = String.format("%d", Integer.valueOf((int) this.f2212h));
        int length = format2.length();
        float[] fArr = new float[length];
        this.p.getTextWidths(format2, fArr);
        float f3 = BitmapDescriptorFactory.HUE_RED;
        for (int i5 = 0; i5 < length; i5++) {
            double d5 = (double) fArr[i5];
            double d6 = (double) f3;
            Double.isNaN(d6);
            Double.isNaN(d5);
            Double.isNaN(d6);
            Double.isNaN(d5);
            f3 = (float) (d6 + d5);
        }
        float f4 = f3 / 2.0f;
        path2.moveTo(this.f2210f - f4, this.f2211g);
        path2.lineTo(this.f2210f + f4, this.f2211g);
        canvas.drawTextOnPath(format2, path2, BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED, this.p);
    }

    public void onMeasure(int i2, int i3) {
        int mode = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i2);
        if (!(mode == Integer.MIN_VALUE || mode == 1073741824)) {
            size = getPreferredSize();
        }
        int mode2 = MeasureSpec.getMode(i3);
        int size2 = MeasureSpec.getSize(i3);
        if (!(mode2 == Integer.MIN_VALUE || mode2 == 1073741824)) {
            size2 = getPreferredSize();
        }
        int min = Math.min(size, size2);
        float f2 = (float) (min / 2);
        this.f2210f = f2;
        this.f2211g = f2;
        setMeasuredDimension(min, min);
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        if (i2 > i3) {
            this.o = (float) (i3 / 3);
        } else {
            this.o = (float) (i2 / 3);
        }
        RectF rectF = this.n;
        float f2 = this.f2210f;
        float f3 = this.o;
        float f4 = this.f2211g;
        rectF.set(f2 - f3, f4 - f3, f2 + f3, f4 + f3);
    }

    public void setCurrentSpeed(float f2) {
        float f3 = this.f2213i;
        if (f2 > f3) {
            this.f2212h = f3;
        } else if (f2 < BitmapDescriptorFactory.HUE_RED) {
            this.f2212h = BitmapDescriptorFactory.HUE_RED;
        } else {
            this.f2212h = f2;
        }
    }
}