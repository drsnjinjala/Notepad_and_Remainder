package com.locationtracker.numbertracker.callerid.calltracker.ui.settings;

import android.content.Intent;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivitySettingBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import think.outside.the.box.handler.APIManager;

public class SettingActivity extends ParentActivity {

    private ActivitySettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_setting);

        initView();

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        binding.btnBack.setOnClickListener(view -> onBackPressed());
        boolean isAvailable = Nikker.isclickerthistime(this);
//        APIManager.showBanner(binding.adsBanner65, b -> {
//            if ( !b && isAvailable) {
//                Nikker.click(binding.adsBanner65, SettingActivity.this, false);
//            }
//        });
//        APIManager.showNative(binding.adsNative200, b -> {
//            if ( !b && isAvailable) {
//                Nikker.click(binding.adsNative200, SettingActivity.this, true);
//            }
//        });
    }

    private void initView() {
        binding.btnAudioInfo.setOnClickListener(view -> {
           APIManager.showInter(SettingActivity.this, false, isfail -> {
                Intent intent = new Intent(this, AudioInfoActivity.class);
                startActivity(intent);
            });
        });

        binding.btnSystemInfo.setOnClickListener(view -> {
            APIManager.showInter(SettingActivity.this, false, isfail -> {
                Intent intent1 = new Intent(this, SystemInfoActivity.class);
                startActivity(intent1);
             });
        });
    }

}