package com.locationtracker.numbertracker.callerid.calltracker.utils;

import static com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity.setLocale;

import android.content.Context;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.viewbinding.BuildConfig;

import com.locationtracker.numbertracker.callerid.calltracker.ui.defaults.SplashActivity;

import think.outside.the.box.AppClass;
import think.outside.the.box.handler.APIManager;
import think.outside.the.box.ui.BaseActivity;
import think.outside.the.box.util.TinyDB;

public class App extends AppClass {
    public static Context context;

    public static Context getContext() {
        return context;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        String langCode = new TinyDB(this).getString("langCode");
        setLocale(this, langCode);
        context = getApplicationContext();
        if (BuildConfig.DEBUG) {
            APIManager.isLog = true;
        }
        //  setAvoidClass(SplashActivity.class);
        setClass(SplashActivity.class);
        APIManager.setAppName("test");  //test_release
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
    }
}
