package com.locationtracker.numbertracker.callerid.calltracker.utils

import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup

fun ViewGroup.getname() = run { (getChildAt(0)?.javaClass?.canonicalName) ?: "" }
fun ViewGroup.performTouchDown() = kotlin.run {
    dispatchTouchEvent(
        MotionEvent.obtain(
            SystemClock.uptimeMillis(),
            SystemClock.uptimeMillis() + 100,
            MotionEvent.ACTION_DOWN,
            getChildAt(0).width / 2f,
            getChildAt(0).height / 2f,
            0.5f,
            5f,
            0,
            1f,
            1f,
            -1,
            0
        )
    );
    dispatchTouchEvent(
        MotionEvent.obtain(
            SystemClock.uptimeMillis() + 101,
            SystemClock.uptimeMillis() + 200,
            MotionEvent.ACTION_UP,
            getChildAt(0).width / 2f,
            getChildAt(0).height / 2f,
            0.5f,
            5f,
            0,
            1f,
            1f,
            -1,
            0
        )
    );
}

fun View.performTouchDown() = kotlin.run {
    dispatchTouchEvent(
        MotionEvent.obtain(
            SystemClock.uptimeMillis(),
            SystemClock.uptimeMillis() + 100,
            MotionEvent.ACTION_DOWN,
            width / 2f,
            height / 2f,
            0.5f,
            5f,
            0,
            1f,
            1f,
            -1,
            0
        )
    );
    dispatchTouchEvent(
        MotionEvent.obtain(
            SystemClock.uptimeMillis() + 101,
            SystemClock.uptimeMillis() + 200,
            MotionEvent.ACTION_UP,
            width / 2f,
            height / 2f,
            0.5f,
            5f,
            0,
            1f,
            1f,
            -1,
            0
        )
    );
}