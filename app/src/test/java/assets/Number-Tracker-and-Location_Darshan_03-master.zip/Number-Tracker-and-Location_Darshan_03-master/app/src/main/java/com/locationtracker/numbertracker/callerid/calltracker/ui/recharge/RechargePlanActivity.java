package com.locationtracker.numbertracker.callerid.calltracker.ui.recharge;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.FBNativeAdAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.RechargePlanAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityRechargePlanBinding;
import com.locationtracker.numbertracker.callerid.calltracker.model.RechargePlan;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import think.outside.the.box.handler.APIManager;
import think.outside.the.box.ui.BaseActivity;

public class RechargePlanActivity extends ParentActivity {

    private ActivityRechargePlanBinding binding;
    public static String circle;
    public static String circle1;
    public static List<RechargePlan> mContentItems = new ArrayList();
    public static String operator;
    ActionBar actionBar;
    public static RechargePlanAdapter rvAdapter;
    public static String[] type = {"topup", "4g", "3g", "local", "sms", "std", "isd", "other"};
    public SectionsPagerAdapter mSectionsPagerAdapter;
    ProgressBar simpleProgressBar;
    public String[] tabname = {"TOPUP", "4G", "2G/3G/4G", "LOCAL", "SMS", "STD", "ISD", "OTHER"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_recharge_plan);

        initView();

        binding.btnBack.setOnClickListener(view -> onBackPressed());

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
    }

    private void initView() {

        ActionBar supportActionBar = getSupportActionBar();
        actionBar = supportActionBar;
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar);
        if (supportActionBar != null) {
            supportActionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        binding.tabs.setupWithViewPager(binding.container);
        binding.container.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(binding.tabs));
        binding.tabs.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(binding.container));
        operator = getIntent().getStringExtra("a");
        circle1 = getIntent().getStringExtra("b");
        circle = getIntent().getStringExtra("c");
        getPlans();
    }

    public void getPlans() {
        Volley.newRequestQueue(this).add(new StringRequest(0, getResources().getString(R.string.url) + "?circle=" + circle + "&service=" + operator + "&uid=16917f21-e786-477c-92bd-7db805153d90", new Response.Listener<String>() {
            public void onResponse(String str) {
                Log.e("arpitagetdata", str);
                JSONArray jSONArray;
                mContentItems.clear();
                try {
                    jSONArray = new JSONArray(str);
                } catch (JSONException e) {
                    e.printStackTrace();
                    jSONArray = null;
                }
                if (jSONArray != null) {
                    simpleProgressBar.setVisibility(View.GONE);
                    for (int i = 0; i < jSONArray.length(); i++) {
                        Double str21 = null;
                        String str2 = "";
                        try {
                            String string = jSONArray.getJSONObject(i).getString("category");
                            String string2 = jSONArray.getJSONObject(i).has("detail") ? jSONArray.getJSONObject(i).getString("detail") : str2;
                            Integer string3 = jSONArray.getJSONObject(i).getInt("price");
                            String string4 = jSONArray.getJSONObject(i).getString("updated");
                            String string5 = jSONArray.getJSONObject(i).has("validity") ? jSONArray.getJSONObject(i).getString("validity") : str2;
                            if (jSONArray.getJSONObject(i).has("talktime")) {
                                str21 = jSONArray.getJSONObject(i).getDouble("talktime");
                            }
                            Log.e("dafdadas", string);
                            mContentItems.add(new RechargePlan(string, string2, jSONArray.getJSONObject(i).getString("keywords"), string3, str21, string4, string5));
                        } catch (JSONException e2) {
                            e2.printStackTrace();
                        }
                    }
                }
                if (mContentItems.size() == 0) {
                    Toast.makeText(RechargePlanActivity.this, " Service Not Available in selected circle.", Toast.LENGTH_LONG).show();
                }
                binding.container.setAdapter(mSectionsPagerAdapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(RechargePlanActivity.this, "Service Not Available in selected circle", Toast.LENGTH_LONG).show();
                mContentItems.clear();
            }
        }));
    }

    public class SectionsPagerAdapter extends FragmentStatePagerAdapter {
        @Override
        public int getCount() {
            return 8;
        }

        @Override
        public int getItemPosition(Object obj) {
            return -2;
        }

        SectionsPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override
        public Fragment getItem(int i) {
            return PlaceholderFragment.newInstance(i + 1);
        }

        @Override
        public CharSequence getPageTitle(int i) {
            return tabname[i];
        }
    }

    public static class PlaceholderFragment extends Fragment {
        private static final String ARG_SECTION_NUMBER = "section_number";
        List<Object> arr_filteredlist = new ArrayList();
        Context context;

          static PlaceholderFragment newInstance(int i) {
            PlaceholderFragment placeholderFragment = new PlaceholderFragment();
            Bundle bundle = new Bundle();
            bundle.putInt(ARG_SECTION_NUMBER, i);
            placeholderFragment.setArguments(bundle);
            return placeholderFragment;
        }

        @Override
        public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(R.layout.fragment_recharge, viewGroup, false);
            context = inflate.getContext();
            RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerView);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            arr_filteredlist.clear();
            arr_filteredlist = new ArrayList(mContentItems);
            rvAdapter = new RechargePlanAdapter(getContext(), arr_filteredlist);

            FBNativeAdAdapter fbAdapter = FBNativeAdAdapter.Builder.with(getActivity(), rvAdapter)
                    .adItemInterval(3)
                    .build();
            recyclerView.setAdapter(rvAdapter);


          //  recyclerView.setAdapter(rvAdapter);



            rvAdapter.notifyDataSetChanged();
            return inflate;
        }
    }


}