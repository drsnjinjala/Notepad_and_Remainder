package com.locationtracker.numbertracker.callerid.calltracker.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.model.SimModel;
import com.locationtracker.numbertracker.callerid.calltracker.ui.simcard.SimCardDetailActivity;

import java.util.ArrayList;
import java.util.List;

import think.outside.the.box.handler.APIManager;


public class SimCardAdapter extends RecyclerView.Adapter<SimCardAdapter.ViewHolder> {

    public Activity activity;
    List<SimModel> data = new ArrayList();
    private LayoutInflater inflater;

    public SimCardAdapter(Activity activity2, List<SimModel> list) {
        this.activity = activity2;
        this.inflater = LayoutInflater.from(activity2);
        this.data = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_sim_card_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtName.setText(this.data.get(position).getName());
        holder.imgLogo.setImageResource(this.data.get(position).getImage());
        holder.layoutMain.setOnClickListener(view -> {
             APIManager.showInter(activity, false, isfail -> {
                Intent intent = new Intent(activity, SimCardDetailActivity.class);
                intent.putExtra("position", position);
                activity.startActivity(intent);
           });
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView imgLogo;
        public final ConstraintLayout layoutMain;
        public final TextView txtName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            layoutMain = itemView.findViewById(R.id.main_layout);
            imgLogo = itemView.findViewById(R.id.imgLogo);
            txtName = itemView.findViewById(R.id.textViewName);
        }
    }
}
