package com.locationtracker.numbertracker.callerid.calltracker.DataBase;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.model.LatLng;
import com.locationtracker.numbertracker.callerid.calltracker.R;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapUtility {
    public static String ADDRESS = "address";
    public static String LATITUDE = "lat";
    public static String LONGITUDE = "long";
    private static final String TAG = "mapUtility";
    public static String apiKey = "";
    public static Location currentLocation;
    public static LatLng defaultLocation;
    public static Dialog popupWindow;

    public static boolean isNetworkAvailable(Context context) {
        NetworkInfo networkInfo;
        try {
            networkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        } catch (Exception unused) {
            networkInfo = null;
        }
        return networkInfo != null && networkInfo.isConnected();
    }

    public static void showProgress(Context context) {
        try {
            if (!((Activity) context).isFinishing()) {
                View inflate = LayoutInflater.from(context).inflate(R.layout.dialog_loading, (ViewGroup) null);
                @SuppressLint("ResourceType") Dialog dialog = new Dialog(context, 16973839);
                popupWindow = dialog;
                dialog.requestWindowFeature(1);
                popupWindow.setContentView(inflate);
                popupWindow.setCancelable(false);
                if (!((Activity) context).isFinishing()) {
                    popupWindow.show();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hideProgress() {
        try {
            Dialog dialog = popupWindow;
            if (dialog != null && dialog.isShowing()) {
                popupWindow.dismiss();
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    public static void getAddressFromLatLng(final Context context, final double d, final double d2, final TextView textView, final boolean z) {
        if (z) {
            showProgress(context);
        }
        final String[] strArr = {""};
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        newSingleThreadExecutor.execute(new Runnable() {


            public void run() {
                try {
                    List<Address> fromLocation = new Geocoder(context).getFromLocation(d, d2, 1);
                    if (fromLocation != null) {
                        Address address = fromLocation.get(0);
                        StringBuilder sb = new StringBuilder("");
                        for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i));
                            sb.append("\n");
                        }
                        strArr[0] = sb.toString();
                        Log.w(MapUtility.TAG, sb.toString());
                    } else {
                        Log.d(MapUtility.TAG, "No Address returned!");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(MapUtility.TAG, " Exception Cannot get Address! " + e.getMessage());
                }
                handler.post(new Runnable() {


                    public void run() {
                        if (z) {
                            MapUtility.hideProgress();
                        }
                        if (!strArr[0].equals(null)) {
                            textView.setText(strArr[0]);
                            return;
                        }
                        textView.setText(d + "," + d2);
                    }
                });
            }
        });
    }

    public static boolean checkAndRequestPermissions(Context context, Activity activity) {
        int checkSelfPermission = ContextCompat.checkSelfPermission(context, "android.permission.ACCESS_FINE_LOCATION");
        int checkSelfPermission2 = ContextCompat.checkSelfPermission(context, "android.permission.ACCESS_COARSE_LOCATION");
        ArrayList arrayList = new ArrayList();
        if (checkSelfPermission != 0) {
            arrayList.add("android.permission.ACCESS_FINE_LOCATION");
        }
        if (checkSelfPermission2 != 0) {
            arrayList.add("android.permission.ACCESS_COARSE_LOCATION");
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        Variables.checkPermission(activity);
        return false;
    }
}
