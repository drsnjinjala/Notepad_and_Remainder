package com.locationtracker.numbertracker.callerid.calltracker.ui.single;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.kwabenaberko.openweathermaplib.constant.Units;
import com.kwabenaberko.openweathermaplib.implementation.OpenWeatherMapHelper;
import com.kwabenaberko.openweathermaplib.implementation.callback.CurrentWeatherCallback;
import com.kwabenaberko.openweathermaplib.model.currentweather.CurrentWeather;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityWeatherInformationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.CheckGps;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import think.outside.the.box.handler.APIManager;

public class WeatherInformationActivity extends ParentActivity {

    private ActivityWeatherInformationBinding binding;
    LocationManager locationManager;
    OpenWeatherMapHelper openWeatherMapHelper;
    double latitude = 0.0;
    double longitude = 0.0;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_weather_information);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        binding.btnBack.setOnClickListener(view -> onBackPressed());


        progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(getResources().getColor(R.color.colorText));
        progressDialog.show();

        binding.addressText.setSelected(true);
        binding.addressText.setSingleLine(true);
        binding.addressText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        openWeatherMapHelper = new OpenWeatherMapHelper(getString(R.string.OPEN_WEATHER_MAP_API_KEY));
        openWeatherMapHelper.setUnits(Units.IMPERIAL);
        openWeatherMapHelper.setLanguage("en");
        @SuppressLint("SimpleDateFormat") String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        @SuppressLint("SimpleDateFormat") String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        binding.dateText.setText(date);
        binding.timeText.setText(time);
        if (CheckGps.isNetworkAvailable(WeatherInformationActivity.this)) {
            if (checkPermission()) {
                locationManager.requestLocationUpdates("network", 1000, 10.0f, new Listener());
                locationManager.requestLocationUpdates("gps", 1000, 10.0f, new Listener());
            } else {
                requestPermission();
            }
        } else {
            progressDialog.dismiss();
            Toast.makeText(WeatherInformationActivity.this, getResources().getString(R.string.no_internet_body), Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(WeatherInformationActivity.this, ACCESS_FINE_LOCATION);
        int result1 = ContextCompat.checkSelfPermission(WeatherInformationActivity.this, ACCESS_COARSE_LOCATION);
        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(WeatherInformationActivity.this, new String[]{ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION}, 45);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 45) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                locationManager.requestLocationUpdates("network", 1000, 10.0f, new Listener());
                locationManager.requestLocationUpdates("gps", 1000, 10.0f, new Listener());
            } else {
                Toast.makeText(WeatherInformationActivity.this, "permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public class Listener implements LocationListener {

        @Override
        public void onLocationChanged(@NonNull Location location) {
            latitude = location.getLatitude();
            longitude = location.getLongitude();
            openWeatherMapHelper.getCurrentWeatherByGeoCoordinates(latitude, longitude, new CurrentWeatherCallback() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onSuccess(CurrentWeather currentWeather) {
                    if (currentWeather.getSys() != null) {
                        binding.addressText.setText(currentWeather.getName() + " " + currentWeather.getSys().getCountry());
                    }
                    String tempc = new DecimalFormat("#.##").format(((currentWeather.getMain().getTemp() - 32.0) * 5.0 / 9.0)) + " °C";
                    String tempf = new DecimalFormat("#.##").format(currentWeather.getMain().getTemp()) + " °F";
                    binding.temperatureCelsiusText.setText(tempc);
                    binding.temperatureFahrenheitText.setText(tempf);
                    String icon = (currentWeather.getWeather().get(0)).getIcon();
                    StringBuilder sb = new StringBuilder();
                    sb.append("https://openweathermap.org/img/w/");
                    sb.append(icon);
                    sb.append(".png");
                    if (!isFinishing())
                        Glide.with(WeatherInformationActivity.this).load(sb.toString()).into(binding.weatherIcon);
                    binding.windText.setText(currentWeather.getWind().getSpeed() + " miles/hour");
                    binding.humidityText.setText(currentWeather.getMain().getHumidity() + " %");
                    binding.pressureText.setText(currentWeather.getMain().getPressure() + " hPa");
                    binding.cloudinessText.setText(currentWeather.getClouds().getAll() + " %");
                    if (Build.VERSION.SDK_INT >= 26) {
                        binding.sunriseText.setText(formatTime(Instant.ofEpochSecond(currentWeather.getSys().getSunrise())));
                        binding.sunsetText.setText(formatTime(Instant.ofEpochSecond(currentWeather.getSys().getSunset())));
                    }
                    progressDialog.dismiss();
                    Log.e("currentWeather", currentWeather.getName() + currentWeather.getWeather());
                }

                @Override
                public void onFailure(Throwable throwable) {

                }
            });
        }

        @Override
        public void onProviderEnabled(@NonNull String provider) {

        }

        @Override
        public void onProviderDisabled(@NonNull String provider) {

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }
    }

    public String formatTime(Instant instant) {
        String timeFormateStr = "";
        if (Build.VERSION.SDK_INT >= 26) {
            timeFormateStr = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH).withZone(ZoneId.of("Asia/Kathmandu")).format(instant);
        }
        return timeFormateStr;
    }


}