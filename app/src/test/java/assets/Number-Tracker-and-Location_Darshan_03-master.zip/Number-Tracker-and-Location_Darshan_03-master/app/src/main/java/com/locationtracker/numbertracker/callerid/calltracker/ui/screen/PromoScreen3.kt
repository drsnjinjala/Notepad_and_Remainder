package com.locationtracker.numbertracker.callerid.calltracker.ui.screen

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityPromoScreen3Binding
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ItemAd65Binding
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ItemAdBinding
import com.locationtracker.numbertracker.callerid.calltracker.ui.defaults.MainActivity
import com.locationtracker.numbertracker.callerid.calltracker.ui.defaults.PermissionActivity
import com.locationtracker.numbertracker.callerid.calltracker.utils.CheckGps
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker
import com.locationtracker.numbertracker.callerid.calltracker.utils.PERMISSIONS
import com.locationtracker.numbertracker.callerid.calltracker.utils.hasPermissions
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.showInter
import think.outside.the.box.ui.BaseActivity


class PromoScreen3 : BaseActivity() {
    private lateinit var binding: ActivityPromoScreen3Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setLightTheme(true)
        binding = ActivityPromoScreen3Binding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        if (intent.getBooleanExtra("isStart", false)) {
            binding.btnNext.visibility = View.GONE;
        }

//        val isavailable = Nikker.isclickerthistime(this)
//        APIManager.showNative(binding.adsBanner65, object : AdsCallback {
//            override fun onClose(isfail: Boolean) {
//                if (!isfail && isavailable) {
//                    Nikker.click(binding.adsBanner65, this@PromoScreen3, true)
//                }
//            }
//        })
//        if (APIManager.isHiddenAds()) {
//            for (i in 1..APIManager.getHiddenAdsCount()) {
//                if (i % 2 == 0) {
//                    val child: ItemAd65Binding = ItemAd65Binding.inflate(layoutInflater)
//                    APIManager.showBannerForcefully(child.adContainerBanner)
//                    binding.layAds?.addView(child.root)
//                } else {
//                    val child: ItemAdBinding = ItemAdBinding.inflate(layoutInflater)
//                    APIManager.showNative(child.adContainer)
//                    binding.layAds?.addView(child.root)
//                }
//            }
//        }

        binding.btnNext.setOnClickListener {
            showInter(this@PromoScreen3, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    if (isAppRunning()) {
                        if (!hasPermissions(PERMISSIONS)) {
                            startActivity(Intent(this@PromoScreen3, PermissionActivity::class.java))
                        } else {
                            startActivity(Intent(this@PromoScreen3, MainActivity::class.java))
                        }
                    }
                }
            })
        }
    }

    override fun onBackPressed() {
        showInter(this@PromoScreen3, true, object : AdsCallback {
            override fun onClose(isfail: Boolean) {
                finish()
            }
        })
    }

    fun isAppRunning(): Boolean {
        var appFound = false
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val recentTasks = activityManager.getRunningTasks(Int.MAX_VALUE)
        for (i in recentTasks.indices) {
            if (recentTasks[i].baseActivity!!.packageName == packageName) {
                appFound = true
                break
            }
        }
        return appFound
    }
}
