package com.locationtracker.numbertracker.callerid.calltracker.ui.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.locationtracker.numbertracker.callerid.calltracker.DataBase.Variables;
import com.locationtracker.numbertracker.callerid.calltracker.R;

import java.util.Objects;

import think.outside.the.box.handler.APIManager;

public class FragmentNavigationVoice extends Fragment {
    private static final String TAG = "ActionNavigationFrag";

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        final double d;
        final double d2;
        View inflate = layoutInflater.inflate(R.layout.fragment_navigation, viewGroup, false);
        Bundle arguments = getArguments();
        if (arguments != null) {
            double d3 = arguments.getDouble(Variables.KEY_LAT);
            d = arguments.getDouble(Variables.KEY_LNG);
            d2 = d3;
        } else {
            Log.d(TAG, "onCreateView: destroying fragment");
            Toast.makeText(getContext(), "Something Went Wrong", Toast.LENGTH_SHORT).show();
            d2 = 0.0d;
            d = 0.0d;
        }
        inflate.findViewById(R.id.btn_navigation).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (d2 != 0.0 && d != 0.0) {
                   APIManager.showInter(getActivity(), false, isfail -> {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("google.navigation:q=" + d2 + "," + d + "&mode=d"));
                        intent.setPackage("com.google.android.apps.maps");
                        startActivity(intent);
                        FragmentActivity activity = getActivity();
                        Objects.requireNonNull(activity);
                        activity.finish();
                    });
                }
            }
        });
        return inflate;
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
    }
}
