package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.view.animation.RotateAnimation;


public class CompassHandler implements CompassSensorListener.a {
    public final ScreenSatelliteCompass a;

    public class Handler implements Runnable {
        public final float a;

        public Handler(float f2) {
            this.a = f2;
        }

        public void run() {
            ScreenSatelliteCompass standardCompassActivity_inviteloop = CompassHandler.this.a;
            float f2 = this.a;
            RotateAnimation rotateAnimation = new RotateAnimation(-standardCompassActivity_inviteloop.r, -f2, 1, 0.5f, 1, 0.5f);
            standardCompassActivity_inviteloop.r = f2;
            rotateAnimation.setDuration(500);
            rotateAnimation.setRepeatCount(0);
            rotateAnimation.setFillAfter(true);
            standardCompassActivity_inviteloop.compassBinding.compassImage/*.findViewById(R.id.compassImage)*/.startAnimation(rotateAnimation);
        }
    }

    public CompassHandler(ScreenSatelliteCompass standardCompassActivity_inviteloop) {
        this.a = standardCompassActivity_inviteloop;
    }

    @Override
    public void a(float f2) {
        this.a.runOnUiThread(new Handler(f2));
    }
}