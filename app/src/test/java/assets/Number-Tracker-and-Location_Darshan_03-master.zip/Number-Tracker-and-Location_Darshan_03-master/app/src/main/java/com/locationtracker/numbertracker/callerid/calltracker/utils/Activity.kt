package com.locationtracker.numbertracker.callerid.calltracker.utils

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.core.app.ActivityCompat

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
fun isTIRAMISUPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

val PERMISSIONS = arrayOf(
    Manifest.permission.ACCESS_COARSE_LOCATION,
    Manifest.permission.ACCESS_FINE_LOCATION,
    Manifest.permission.CALL_PHONE,
)

fun Activity.hasPermissions(permissions: Array<String>): Boolean =
    permissions.all {
        ActivityCompat.checkSelfPermission(
            applicationContext,
            it
        ) == PackageManager.PERMISSION_GRANTED
    }