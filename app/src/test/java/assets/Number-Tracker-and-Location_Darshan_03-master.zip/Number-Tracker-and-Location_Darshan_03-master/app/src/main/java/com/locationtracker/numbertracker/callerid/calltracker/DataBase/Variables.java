package com.locationtracker.numbertracker.callerid.calltracker.DataBase;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Variables {
    public static final String HCTR = "HCTR";
    public static final String KEY = "key";
    public static final String KEY_ADDRESS_FINDER = "address_finder";
    public static final String KEY_APP_PERMISSIONS = "app_permissions";
    public static final String KEY_ISD = "isd";
    public static final String KEY_LAT = "latitude";
    public static final String KEY_LAT_DES = "latitude_des";
    public static final String KEY_LAT_ORG = "latitude_org";
    public static final String KEY_LNG = "longitude";
    public static final String KEY_LNG_DES = "longitude_des";
    public static final String KEY_LNG_ORG = "longitude_org";
    public static final String KEY_NAVIGATION = "navigation";
    public static final String KEY_ROUTE_FINDER = "route_finder";
    public static final String KEY_SAVED_LOC = "saved_loc";
    public static final String KEY_SHARE_LOC = "share_loc";
    public static final String KEY_STD = "std";
    public static final String KEY_TRAVEL_GUIDE_MAIN = "travel_guide_main";
    public static final String KEY_TRAVEL_GUIDE_SEC = "travel_guide_sec";
    public static final String KEY_VOICE = "voice";
    public static final int REQUEST_CODE_AUTOCOMPLETE = 123;
    public static final String STYLE_DEFAULT = "style_default";
    public static final String STYLE_NIGHT = "style_night";
    public static final String STYLE_SATELLITE = "style_satellite";
    public static final String STYLE_TRAFFIC = "style_traffic";
    private static final String TAG = "Variables";
    public static final String YOUR_PLACEMENT_ID = "YOUR_PLACEMENT_ID";
    public static final String back_interstitial_status = "back_interstitial_status";
    public static final String banner_am_id = "banner_am_id";
    public static final String banner_status = "banner_status";
    public static final String billing_status = "billing_status";
    public static final String dashboard_native_status = "dashboard_native_status";
    public static final String exit_interstitial_status = "exit_interstitial_status";
    public static final String exit_native_status = "exit_native_status";
    public static final String first_login = "first_login";
    public static final String front_interstitial_isd = "front_interstitial_isd";
    public static final String front_interstitial_live_earth_map = "front_interstitial_live_earth_map";
    public static final String front_interstitial_route_finder = "front_interstitial_route_finder";
    public static final String front_interstitial_saved_locations = "front_interstitial_saved_locations";
    public static final String front_interstitial_share_location = "front_interstitial_share_location";
    public static final String front_interstitial_std = "front_interstitial_std";
    public static final String front_interstitial_voice_navigation = "front_interstitial_voice_navigation";
    public static final String inner_native_status = "inner_native_status";
    public static final String interstitial_am_id = "interstitial_am_id";
    public static Location mLocation = null;
    public static final String native_am_id = "native_am_id";
    public static final String native_ctr = "native_ctr";
    public static final String off = "off";
    public static final String on = "on";
    public static final String pref_name = "liveearthmap_streetview_gpsnavigation";
    public static final String pref_theme_dark = "pref_theme";
    public static final String premium_interstitial_status = "premium_interstitial_status";
    public static final String splash_interstitial_status = "splash_interstitial_status";
    public static final String splash_native_status = "splash_native_status";
    public static boolean themeFlag = true;

    public static void showToast(Context context, String str) {
        try {
            Toast makeText = Toast.makeText(context, str, Toast.LENGTH_SHORT);
            makeText.setGravity(81, 0, 0);
            makeText.show();
        } catch (Exception unused) {
        }
    }

    public static void checkPermission(Activity activity) {
    }

    public static void getAddressFromLatLng(final Context context, final double d, final double d2, final TextView textView) {
        final String[] strArr = {""};
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        newSingleThreadExecutor.execute(new Runnable() {


            public void run() {
                try {
                    List<Address> fromLocation = new Geocoder(context).getFromLocation(d, d2, 1);
                    if (fromLocation != null) {
                        Address address = fromLocation.get(0);
                        StringBuilder sb = new StringBuilder("");
                        for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i));
                            sb.append("\n");
                        }
                        strArr[0] = sb.toString();
                        Log.w(Variables.TAG, sb.toString());
                    } else {
                        Log.d(Variables.TAG, "No Address returned!");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(Variables.TAG, " Exception Cannot get Address! " + e.getMessage());
                }
                handler.post(new Runnable() {


                    public void run() {
                        if (!strArr[0].equals(null)) {
                            textView.setText(strArr[0]);
                            return;
                        }
                        textView.setText(d + "," + d2);
                    }
                });
            }
        });
    }

    public static void buildAlertMessageNoGps(final Context context, final Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                context.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
            }
        }).setNegativeButton("No", (dialogInterface, i) -> {
            dialogInterface.cancel();
            activity.finish();
        });
        builder.create().show();
    }

    public static String getDurationString(int i) {
        int i2 = i / 3600;
        int i3 = i % 60;
        return twoDigitString(i2) + " h, " + twoDigitString((i % 3600) / 60) + " min ";
    }

    public static String twoDigitString(int i) {
        if (i == 0) {
            return "0";
        }
        if (i / 10 != 0) {
            return String.valueOf(i);
        }
        return "0" + i;
    }

    public static String convertMeterToKilometer(double d) {
        return String.valueOf(BigDecimal.valueOf(d / 1000.0d).setScale(2, RoundingMode.HALF_UP).doubleValue());
    }
}
