package com.locationtracker.numbertracker.callerid.calltracker.ui.single;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityNearLocationBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import think.outside.the.box.callback.AdsCallback;
import think.outside.the.box.handler.APIManager;

public class NearLocationActivity extends ParentActivity {

    private ActivityNearLocationBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_near_location);
        initView();
        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);

        binding.btnBack.setOnClickListener(view -> onBackPressed());

    }

    private void initView() {
        binding.ivHospital.setOnClickListener(view -> setdata("Hospital"));
        binding.ivCafe.setOnClickListener(view -> setdata("Hotel"));
        binding.ivCarWash.setOnClickListener(view -> setdata("Car wash"));
        binding.ivGasStation.setOnClickListener(view -> setdata("Gas Station"));
        binding.ivBusStop.setOnClickListener(view -> setdata("Bus Stop"));
        binding.ivCinema.setOnClickListener(view -> setdata("Cinema"));
        binding.ivSchool.setOnClickListener(view -> setdata("School"));
        binding.ivLibrary.setOnClickListener(view -> setdata("Library"));
        binding.ivDental.setOnClickListener(view -> setdata("Dental"));
    }

    public void setdata(String data) {
        try {
           APIManager.showInter(NearLocationActivity.this, false, isfail -> {
                startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://maps.google.co.in/maps?q=" + data)));
             });
        } catch (Exception e) {
            Toast.makeText(this, "Google Map App Not Found", Toast.LENGTH_SHORT).show();
        }
    }


}