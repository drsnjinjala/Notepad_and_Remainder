package com.locationtracker.numbertracker.callerid.calltracker.ui.traffic;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityTrafficInfoBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.CheckGps;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import think.outside.the.box.handler.APIManager;

public class TrafficInfoActivity extends ParentActivity {

    private ActivityTrafficInfoBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_traffic_info);

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);

        binding.btnBack.setOnClickListener(view -> onBackPressed());

        binding.btnShowMap.setOnClickListener(view -> {
            if (CheckGps.isLocationEnabled(TrafficInfoActivity.this)) {
               APIManager.showInter(TrafficInfoActivity.this, false, isfail -> {
                    Intent intent = new Intent(TrafficInfoActivity.this, TrafficMapActivity.class);
                    startActivity(intent);
                });
            } else if (!isFinishing()) {
                showGPSDisabledAlertToUser();
            }
        });
    }

    public void showGPSDisabledAlertToUser() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.no_gps)).setCancelable(false).setPositiveButton(getResources().getString(R.string.enable_gps), (dialogInterface, i) -> startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS")));
        builder.setNegativeButton(getResources().getString(R.string.compass_cancel), (dialogInterface, i) -> dialogInterface.cancel());
        AlertDialog create = builder.create();
        builder.setCancelable(false);
        create.show();
    }


}