package com.locationtracker.numbertracker.callerid.calltracker.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.ui.bank.BankDetailsActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Store;

import java.io.ByteArrayOutputStream;

import think.outside.the.box.handler.APIManager;


public class BankListAdapter extends RecyclerView.Adapter<BankListAdapter.ViewHolder> {

    private final String[] bankCare;
    private final String[] bankInquiry;
    private final Activity context;
    private final Integer[] imgId;
    private final String[] itemName;
    private LayoutInflater inflater;
    private Intent intent;

    public BankListAdapter(Activity activity, String[] itemName, Integer[] imgId, String[] bankInquiry, String[] bankCare) {
        this.context = activity;
        this.itemName = itemName;
        this.imgId = imgId;
        this.bankInquiry = bankInquiry;
        this.bankCare = bankCare;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_bank_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.txtName.setText(itemName[position]);
        holder.imgLogo.setImageResource(imgId[position]);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Bitmap decodeResource = BitmapFactory.decodeResource(context.getResources(), imgId[position]);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                decodeResource.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                final byte[] byteArray = byteArrayOutputStream.toByteArray();


                Store.bank_inquiry = bankInquiry[position];
                Store.bank_care = bankCare[position];

                intent = new Intent(context, BankDetailsActivity.class);
                APIManager.showInter(context, false, isfail -> {
                    intent.putExtra("bank_name", itemName[position]);
                    intent.putExtra("bank_img", byteArray);
                    context.startActivity(intent);
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemName.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView imgLogo;
        public final TextView txtName;
        public final ConstraintLayout layout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgLogo = itemView.findViewById(R.id.imgBankIcon);
            txtName = itemView.findViewById(R.id.txt_bank_text);
            layout = itemView.findViewById(R.id.main_layout_bank);

        }
    }
}
