package com.locationtracker.numbertracker.callerid.calltracker.ui.single;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Cap;
import com.google.android.gms.maps.model.Dash;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PatternItem;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.RoundCap;
import com.google.android.gms.tasks.OnSuccessListener;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityDistanceFinderBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.recharge.RechargeActivity;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.Nikker;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import think.outside.the.box.handler.APIManager;

public class DistanceFinderActivity extends ParentActivity implements OnMapReadyCallback {

    private ActivityDistanceFinderBinding binding;
    private Bitmap bm, endBitmap;
    private LatLng cameraPos = new LatLng(0.0d, 0.0d);
    private FusedLocationProviderClient client;
    private int color;
    private double distance = 0.0d;
    private Polyline dynamicPl = null;
    private PolylineOptions dynamicPlO;
    private final Cap endCap = new RoundCap();
    private Marker endMarker = null;
    private boolean isCanceled = false;
    private boolean isNewRoute = true;
    private boolean isPolyDrawn = false;
    private GoogleMap mMap;
    private int mapType = 1;
    private final List<PatternItem> pattern = Arrays.asList(new Dash(15.0f), new Gap(15.0f));
    private PolylineOptions plOptions;
    private Polyline polyline = null;
    private String routeName = "";
    private Polyline savePoly = null;
    private Map<String, List<LatLng>> savedRoutes = new HashMap();
    private SharedPreferences sharedPreferences;
    private final Cap startCap = new RoundCap();
    private Marker startMarker = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_distance_finder);
        setHideNavigation(true);
        setLightTheme(true);

        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);

        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        initView();


    }

    private void initView() {
        this.color = ContextCompat.getColor(this, R.color.colorAccent);
        this.plOptions = new PolylineOptions().jointType(2).endCap(this.endCap).startCap(this.startCap).color(this.color).pattern(this.pattern);
        this.dynamicPlO = new PolylineOptions().jointType(2).endCap(this.endCap).startCap(this.startCap).color(this.color).pattern(this.pattern);
        this.bm = BitmapFactory.decodeResource(getResources(), R.drawable.ic_start_route);
        this.endBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_end_route);
        this.sharedPreferences = getPreferences(0);
        Iterator<? extends Map.Entry<String, ?>> it = this.sharedPreferences.getAll().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, ?> next = it.next();
            Set<String> set = (Set) next.getValue();
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < set.size(); i++) {
                arrayList.add(null);
            }
            for (String str : set) {
                String[] split = str.split(",");
                arrayList.set(Integer.parseInt(split[0]), new LatLng(Double.parseDouble(split[1]), Double.parseDouble(split[2])));
            }
            this.savedRoutes.put(next.getKey(), arrayList);
            it.remove();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        this.client = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mMap.getUiSettings().setCompassEnabled(false);
        this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1);
        } else {
            showMyLocation();
            getLocation();
        }
        this.mMap.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {

            List<LatLng> pos;

            @Override
            public void onCameraMove() {

                cameraPos = mMap.getCameraPosition().target;
                if (dynamicPl != null) {
                    dynamicPlO = new PolylineOptions().jointType(2).endCap(endCap).startCap(startCap).color(color).pattern(pattern);
                    dynamicPl.remove();
                }
                if (polyline != null && !isCanceled) {
                    this.pos = polyline.getPoints();
                    PolylineOptions polylineOptions = dynamicPlO;
                    List<LatLng> list = this.pos;
                    polylineOptions.add(list.get(list.size() - 1)).add(cameraPos);

                    dynamicPl = mMap.addPolyline(dynamicPlO);
                }
            }
        });
        binding.putMarkerButton.setOnClickListener(new View.OnClickListener() {

            Location from = new Location("");
            List<LatLng> pos;
            Location to = new Location("");

            public void onClick(View view) {
                String str;
                if (polyline != null) {
                    polyline.remove();
                }
                if (dynamicPl != null) {
                    dynamicPl.remove();
                }
                if (endMarker != null) {
                    endMarker.remove();
                    endMarker = null;
                }
                isCanceled = false;
                plOptions.add(cameraPos);

                polyline = mMap.addPolyline(plOptions);
                if (startMarker == null) {
                    startMarker = mMap.addMarker(new MarkerOptions().position(cameraPos).icon(BitmapDescriptorFactory.fromBitmap(bm)).anchor(0.5f, 0.5f));
                }
                this.pos = polyline.getPoints();
                if (this.pos.size() > 1) {
                    Location location = this.from;
                    List<LatLng> list = this.pos;
                    location.setLatitude(list.get(list.size() - 2).latitude);
                    Location location2 = this.from;
                    List<LatLng> list2 = this.pos;
                    location2.setLongitude(list2.get(list2.size() - 2).longitude);
                    this.to.setLatitude(cameraPos.latitude);
                    this.to.setLongitude(cameraPos.longitude);
                    distance += (double) this.from.distanceTo(this.to);
                    DecimalFormat decimalFormat = new DecimalFormat("#.##");
                    if (distance > 1000.0d) {
                        str = "" + decimalFormat.format(distance / 1000.0d) + "km";
                    } else {
                        str = "" + decimalFormat.format(distance) + "m";
                    }
                    binding.distText.setText(str);
                    binding.endRoute.setVisibility(View.VISIBLE);
                    binding.endRoute.setClickable(true);
                    isPolyDrawn = true;
                }
                binding.redoButton.setVisibility(View.VISIBLE);
                binding.redoButton.setClickable(true);
                if (isNewRoute) {
                    isNewRoute = false;
                }
            }
        });
        binding.endRoute.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                List<LatLng> points = polyline.getPoints();
                endMarker = mMap.addMarker(new MarkerOptions().position(points.get(points.size() - 1)).icon(BitmapDescriptorFactory.fromBitmap(endBitmap)).anchor(0.5f, 0.5f));
                isCanceled = true;

                savePoly = polyline;
                if (dynamicPl != null) {
                    dynamicPl.remove();
                }
                binding.endRoute.setVisibility(View.GONE);
                binding.endRoute.setClickable(false);
            }
        });
        binding.maptypeButton.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {
                if (mapType == 1) {
                    mapType = 4;
                    mMap.setMapType(mapType);
                    return;
                }
                mapType = 1;
                mMap.setMapType(mapType);
            }
        });
        binding.redoButton.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {
                if (polyline == null) {

                    polyline = savePoly;
                }
                List<LatLng> points = polyline.getPoints();
                Location location = new Location("");
                Location location2 = new Location("");
                if (points.size() < 2) {
                    newRoute();
                    return;
                }
                int i = 0;
                isCanceled = false;
                if (endMarker != null) {
                    endMarker.remove();
                    endMarker = null;
                }
                if (points.size() < 3) {
                    isPolyDrawn = false;
                    binding.endRoute.setVisibility(View.GONE);
                    binding.endRoute.setClickable(false);
                } else {
                    binding.endRoute.setVisibility(View.VISIBLE);
                    binding.endRoute.setClickable(true);
                }
                if (dynamicPl != null) {
                    dynamicPl.remove();
                }
                polyline.remove();
                plOptions = new PolylineOptions().jointType(2).endCap(endCap).startCap(startCap).color(color).pattern(pattern);
                dynamicPlO = new PolylineOptions().jointType(2).endCap(endCap).startCap(startCap).color(color).pattern(pattern);
                dynamicPlO.add(points.get(points.size() - 2)).add(cameraPos);
                for (int i2 = 0; i2 < points.size() - 1; i2++) {
                    plOptions.add(points.get(i2));
                }

                polyline = mMap.addPolyline(plOptions);
                dynamicPl = mMap.addPolyline(dynamicPlO);
                List<LatLng> points2 = polyline.getPoints();
                distance = 0.0d;
                while (i < points2.size() - 1) {
                    location.setLatitude(points2.get(i).latitude);
                    location.setLongitude(points2.get(i).longitude);
                    i++;
                    location2.setLatitude(points2.get(i).latitude);
                    location2.setLongitude(points2.get(i).longitude);
                    distance += (double) location.distanceTo(location2);
                }
                DecimalFormat decimalFormat = new DecimalFormat("#.##");
                binding.distText.setText(distance > 1000.0d ? "" + decimalFormat.format(distance / 1000.0d) + "km" : "" + decimalFormat.format(distance) + "m");
            }
        });
        binding.menuButton.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {

                showPopup(binding.menuButton);
            }
        });
    }

    public void showPopup(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.inflate(R.menu.menu);
        SubMenu subMenu = popupMenu.getMenu().getItem(0).getSubMenu();
        SubMenu subMenu2 = popupMenu.getMenu().getItem(1).getSubMenu();
        Iterator<Map.Entry<String, List<LatLng>>> it = this.savedRoutes.entrySet().iterator();
        if (!it.hasNext()) {
            subMenu.add(R.string.no_saved_route).setEnabled(false);
            subMenu2.add(R.string.no_saved_routes).setEnabled(false);
        }
        int i = 0;
        while (it.hasNext()) {
            Map.Entry<String, List<LatLng>> next = it.next();
            subMenu.add(10, 0, i, next.getKey());
            subMenu2.add(11, 0, i, next.getKey());
            i++;
        }
        popupMenu.setOnMenuItemClickListener(menuItem -> {
            switch (menuItem.getItemId()) {
                case R.id.new_route_item /*{ENCODED_INT: 2131230887}*/:
                    newRoute();
                    return true;
                case R.id.remove_route_item /*{ENCODED_INT: 2131230908}*/:
                    break;
                case R.id.save_route_item /*{ENCODED_INT: 2131230916}*/:
                    if (!isPolyDrawn) {
                        Toast makeText = Toast.makeText(DistanceFinderActivity.this, R.string.there_no_route_to_saved, Toast.LENGTH_SHORT);
                        makeText.setGravity(81, 0, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
                        makeText.show();
                        break;
                    } else {
                        saveRoute();
                        break;
                    }
                case R.id.saved_routes_item /*{ENCODED_INT: 2131230918}*/:
                    return true;
                default:
                    int groupId = menuItem.getGroupId();
                    if (groupId == 10) {
                        loadRoute(menuItem);
                    } else if (groupId == 11) {
                        removeSavedRoute(menuItem);
                    }
                    return true;
            }
            return true;
        });
        popupMenu.show();
    }

    public void loadRoute(MenuItem menuItem) {
        Location location = new Location("");
        Location location2 = new Location("");
        String charSequence = menuItem.getTitle().toString();
        if (this.savedRoutes.containsKey(charSequence)) {
            newRoute();
            List<LatLng> list = this.savedRoutes.get(charSequence);
            for (LatLng latLng : list) {
                this.plOptions.add(latLng);
            }
            this.startMarker = this.mMap.addMarker(new MarkerOptions().position(list.get(0)).icon(BitmapDescriptorFactory.fromBitmap(this.bm)).anchor(0.5f, 0.5f));
            this.endMarker = this.mMap.addMarker(new MarkerOptions().position(list.get(list.size() - 1)).icon(BitmapDescriptorFactory.fromBitmap(this.endBitmap)).anchor(0.5f, 0.5f));
            this.mMap.moveCamera(CameraUpdateFactory.newLatLng(list.get(list.size() - 1)));
            this.cameraPos = this.mMap.getCameraPosition().target;
            this.polyline = this.mMap.addPolyline(this.plOptions);
            this.isPolyDrawn = true;
            binding.redoButton.setVisibility(View.VISIBLE);
            binding.redoButton.setClickable(true);
            int i = 0;
            while (i < list.size() - 1) {
                location.setLatitude(list.get(i).latitude);
                location.setLongitude(list.get(i).longitude);
                i++;
                location2.setLatitude(list.get(i).latitude);
                location2.setLongitude(list.get(i).longitude);
                this.distance += (double) location.distanceTo(location2);
            }
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            binding.distText.setText(this.distance > 1000.0d ? "" + decimalFormat.format(this.distance / 1000.0d) + "km" : "" + decimalFormat.format(this.distance) + "m");
            this.isNewRoute = false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (strArr.length <= 0 || iArr[0] != 0) {
            Toast makeText = Toast.makeText(this, "Your GPS location is not allowed", Toast.LENGTH_LONG);
            makeText.setGravity(81, 0, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            makeText.show();
            return;
        }
        showMyLocation();
        getLocation();
    }

    private void showMyLocation() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            this.mMap.setMyLocationEnabled(true);
        }
    }

    private void getLocation() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            this.client.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {


                public void onSuccess(Location location) {
                    if (location != null) {
                        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                        cameraPos = latLng;
                        mMap.moveCamera(CameraUpdateFactory.zoomTo(13.0f));
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                    }
                }
            });
        }
    }

    private void saveRoute() {
        AlertDialog.Builder title = new AlertDialog.Builder(this).setTitle("Route name: ");
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(80, 0, 80, 0);
        final EditText editText = new EditText(this);
        linearLayout.addView(editText, layoutParams);
        title.setView(linearLayout);
        title.setPositiveButton("Save", (dialogInterface, i) -> {
            routeName = editText.getText().toString();
            if (!savedRoutes.containsKey(routeName)) {
                Polyline addPolyline = mMap.addPolyline(plOptions);
                savePoly = addPolyline;
                addPolyline.remove();
                List<LatLng> points = savePoly.getPoints();
                HashSet hashSet = new HashSet();
                Double.valueOf(0.0d);
                Double.valueOf(0.0d);
                for (int i2 = 0; i2 < points.size(); i2++) {
                    Double valueOf = Double.valueOf(points.get(i2).latitude);
                    Double valueOf2 = Double.valueOf(points.get(i2).longitude);
                    hashSet.add(i2 + "," + valueOf + "," + valueOf2);
                }
                sharedPreferences.edit().putStringSet(routeName, hashSet).apply();
                savedRoutes.put(routeName, points);
                Toast makeText = Toast.makeText(DistanceFinderActivity.this, "Saved", Toast.LENGTH_SHORT);
                makeText.setGravity(81, 0, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
                makeText.show();
                return;
            }
            Toast makeText2 = Toast.makeText(DistanceFinderActivity.this, "The route name already exists", Toast.LENGTH_SHORT);
            makeText2.setGravity(81, 0, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            makeText2.show();
        });
        title.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {


            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        title.show();
    }

    private void newRoute() {
        this.startMarker = null;
        this.endMarker = null;
        this.polyline = null;
        this.isPolyDrawn = false;
        this.isCanceled = true;
        this.plOptions = new PolylineOptions().jointType(2).endCap(this.endCap).startCap(this.startCap).color(this.color).pattern(this.pattern);
        this.dynamicPlO = new PolylineOptions().jointType(2).endCap(this.endCap).startCap(this.startCap).color(this.color).pattern(this.pattern);
        this.mMap.clear();
        binding.endRoute.setVisibility(View.GONE);
        binding.endRoute.setClickable(false);
        binding.redoButton.setVisibility(View.GONE);
        binding.redoButton.setClickable(false);
        this.isNewRoute = true;
        this.distance = 0.0d;
        binding.distText.setText("" + this.distance + "m");
    }

    private void removeSavedRoute(MenuItem menuItem) {
        final String charSequence = menuItem.getTitle().toString();
        if (this.savedRoutes.containsKey(charSequence)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            AlertDialog.Builder title = builder.setTitle(charSequence + " Route" + " Delete ?");
            title.setPositiveButton("Delete", (dialogInterface, i) -> {
                sharedPreferences.edit().remove(charSequence).apply();
                savedRoutes.remove(charSequence);

                Toast makeText = Toast.makeText(DistanceFinderActivity.this, charSequence + " Route was deleted", Toast.LENGTH_SHORT);
                makeText.setGravity(81, 0, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
                makeText.show();
            });
            title.setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.cancel());
            title.show();
        }
    }


}