package com.locationtracker.numbertracker.callerid.calltracker.ui.traffic;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityTrafficMapBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;
import com.locationtracker.numbertracker.callerid.calltracker.utils.TrafficGpsUtils;

import java.util.Calendar;
import java.util.GregorianCalendar;

import think.outside.the.box.handler.APIManager;

public class TrafficMapActivity extends ParentActivity implements OnMapReadyCallback {

    private ActivityTrafficMapBinding binding;
    private TrafficGpsUtils gpsTracker;
    private GoogleMap TrafficMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        setHideNavigation(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_traffic_map);
        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        gpsTracker = new TrafficGpsUtils(this);
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        TrafficMap = googleMap;
        LatLng latLng = new LatLng(gpsTracker.getLatitude(), gpsTracker.getLongitude());
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        TrafficMap.setMyLocationEnabled(true);
        TrafficMap.getUiSettings().setMapToolbarEnabled(false);
        TrafficMap.setTrafficEnabled(true);
        TrafficMap.addMarker(new MarkerOptions().position(latLng).title(getString(R.string.currentLoc)));
        TrafficMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
    }

    public void startAlert() {
        Calendar cur_cal = new GregorianCalendar();
        cur_cal.setTimeInMillis(System.currentTimeMillis());
        Calendar cal = new GregorianCalendar();
        cal.add(Calendar.DAY_OF_YEAR, cur_cal.get(Calendar.DAY_OF_YEAR));
        cal.set(Calendar.HOUR_OF_DAY, 8);
        cal.set(Calendar.MINUTE, 05);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.DATE, 0);
        cal.set(Calendar.MONTH, 0);

        Log.e("timeset", String.valueOf(cal.getTimeInMillis()));
        long startUpTime = cal.getTimeInMillis();
        boolean isRepeat = true;

    }

}