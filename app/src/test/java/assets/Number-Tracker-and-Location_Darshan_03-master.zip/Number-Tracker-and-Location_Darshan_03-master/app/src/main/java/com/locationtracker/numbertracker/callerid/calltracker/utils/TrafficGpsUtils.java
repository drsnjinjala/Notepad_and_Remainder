package com.locationtracker.numbertracker.callerid.calltracker.utils;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import androidx.core.app.ActivityCompat;

public class TrafficGpsUtils implements LocationListener {
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
    private static final long MIN_TIME_BW_UPDATES = 60000;
    boolean canGetLocation = false;
    boolean isGPSEnabled = false;
    boolean isNetworkEnabled = false;
    double latitude;
    Location location = null;
    protected LocationManager locationManager;
    double longitude;
    private final Context mContext;
    private Location m_Location;
    private float accuracy;

    public void onLocationChanged(Location location2) {
    }

    public void onProviderDisabled(String str) {
    }

    public void onProviderEnabled(String str) {
    }

    public void onStatusChanged(String str, int i, Bundle bundle) {
    }

    public TrafficGpsUtils(Context context) {
        this.mContext = context;
        this.m_Location = getLocation();
    }

    public Location getLocation() {
        String str = "network";
        String str2 = "gps";
        try {
            LocationManager locationManager2 = (LocationManager) this.mContext.getSystemService(Context.LOCATION_SERVICE);
            this.locationManager = locationManager2;
            this.isGPSEnabled = locationManager2.isProviderEnabled(str2);
            boolean isProviderEnabled = this.locationManager.isProviderEnabled(str);
            this.isNetworkEnabled = isProviderEnabled;
            if (!this.isGPSEnabled && !isProviderEnabled) {
                return this.location;
            }
            this.canGetLocation = true;
            if (this.isNetworkEnabled) {
                if (ActivityCompat.checkSelfPermission(this.mContext, "android.permission.ACCESS_FINE_LOCATION") != 0) {
                    ActivityCompat.checkSelfPermission(this.mContext, "android.permission.ACCESS_COARSE_LOCATION");
                }
                this.locationManager.requestLocationUpdates("network", MIN_TIME_BW_UPDATES, 10.0f, this);
                Log.d("Network", "Network Enabled");
                if (this.locationManager != null) {
                    Location lastKnownLocation = this.locationManager.getLastKnownLocation(str);
                    this.location = lastKnownLocation;
                    if (lastKnownLocation != null) {
                        this.latitude = lastKnownLocation.getLatitude();
                        this.longitude = this.location.getLongitude();
                    }
                }
            }
            if (this.isGPSEnabled && this.location == null) {
                this.locationManager.requestLocationUpdates("gps", MIN_TIME_BW_UPDATES, 10.0f, this);
                Log.d("GPS", "GPS Enabled");
                if (this.locationManager != null) {
                    Location lastKnownLocation2 = this.locationManager.getLastKnownLocation(str2);
                    this.location = lastKnownLocation2;
                    if (lastKnownLocation2 != null) {
                        this.latitude = lastKnownLocation2.getLatitude();
                        this.longitude = this.location.getLongitude();
                    }
                }
            }
            return this.location;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return location;
    }

    public void stopUsingGPS() {
        LocationManager locationManager2 = this.locationManager;
        if (locationManager2 != null) {
            locationManager2.removeUpdates(this);
        }
    }

    public double getLatitude() {
        Location location2 = this.location;
        if (location2 != null) {
            this.latitude = location2.getLatitude();
        }
        return this.latitude;
    }

    public double getLongitude() {
        Location location2 = this.location;
        if (location2 != null) {
            this.longitude = location2.getLongitude();
        }
        return this.longitude;
    }

    public float getAccuracy() {
        Location location2 = this.location;
        if (location2 != null) {
            this.accuracy = location2.getAccuracy();
        }
        return this.accuracy;
    }

    public boolean canGetLocation() {
        return this.canGetLocation;
    }
}