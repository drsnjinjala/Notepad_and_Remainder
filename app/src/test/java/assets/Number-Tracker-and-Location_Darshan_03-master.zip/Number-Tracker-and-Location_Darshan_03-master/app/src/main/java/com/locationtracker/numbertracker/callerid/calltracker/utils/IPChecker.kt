package com.locationtracker.numbertracker.callerid.calltracker.utils

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.*
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import think.outside.the.box.handler.APIManager.getExtraData

object IPChecker {
    fun getClient(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://wtfismyip.com/")
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
    }

    @JvmStatic
    fun checker(ipcallback: IPCallback) {
        if (getExtraData()!=null && getExtraData()?.has("countrylist") == true){
            val response = getExtraData()?.getString("countrylist")?.split(",".toRegex())?.toList()
            if (response.isNullOrEmpty()){
                ipcallback.ipCallback(false, null)
                return
            }
        }else{
            ipcallback.ipCallback(false, null)
            return
        }
        getClient().create(IPInterface::class.java).getDetails()
            .enqueue(object : Callback<IPResponse> {
                override fun onResponse(call: Call<IPResponse>, response: Response<IPResponse>) {
                    if (response.isSuccessful && response.body() != null && response.body()?.yourFuckingCountryCode != null) {
                        ipcallback.ipCallback(true, response.body()?.yourFuckingCountryCode)
                    } else {
                        ipcallback.ipCallback(false, null)
                    }
                }

                override fun onFailure(call: Call<IPResponse>, t: Throwable) {
                    ipcallback.ipCallback(false, null)
                }
            })
    }

    interface IPInterface {
        @GET("json")
        fun getDetails(): Call<IPResponse>
    }

}

interface IPCallback {
    fun ipCallback(issuccess: Boolean, countrycode: String?)
}

@JsonClass(generateAdapter = true)
data class IPResponse(
    @Json(name="YourFuckingTorExit")
    val yourFuckingTorExit: Boolean? = null,

    @Json(name="YourFuckingCountry")
    val yourFuckingCountry: String? = null,

    @Json(name="YourFuckingCountryCode")
    val yourFuckingCountryCode: String? = null,

    @Json(name="YourFuckingISP")
    val yourFuckingISP: String? = null,

    @Json(name="YourFuckingLocation")
    val yourFuckingLocation: String? = null,

    @Json(name="YourFuckingHostname")
    val yourFuckingHostname: String? = null,

    @Json(name="YourFuckingIPAddress")
    val yourFuckingIPAddress: String? = null,

    @Json(name="YourFuckingCity")
    val yourFuckingCity: String? = null
)
