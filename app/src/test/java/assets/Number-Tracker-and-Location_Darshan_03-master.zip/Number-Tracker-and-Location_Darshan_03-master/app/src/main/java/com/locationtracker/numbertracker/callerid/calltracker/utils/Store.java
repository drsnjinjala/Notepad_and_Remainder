package com.locationtracker.numbertracker.callerid.calltracker.utils;

public class Store {
    public static String bank_care;
    public static String bank_inquiry;
}
