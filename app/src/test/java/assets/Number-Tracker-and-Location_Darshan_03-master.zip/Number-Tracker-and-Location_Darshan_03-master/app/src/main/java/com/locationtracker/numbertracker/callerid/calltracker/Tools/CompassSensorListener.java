package com.locationtracker.numbertracker.callerid.calltracker.Tools;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;


public class CompassSensorListener implements SensorEventListener {
    public float[] a = new float[9];
    public float[] f4974b = new float[9];
    public Sensor sensor;
    public a f4976d;
    public float[] f4977e = new float[3];
    public float[] f4978f = new float[3];
    public Sensor sensor2;
    public SensorManager manager;
    public interface a {
        void a(float f2);
    }

    public CompassSensorListener(Context context) {
        SensorManager sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        this.manager = sensorManager;
        this.sensor = sensorManager.getDefaultSensor(1);
        this.sensor2 = this.manager.getDefaultSensor(2);
    }

    public void a() {
        this.manager.registerListener(this, this.sensor, 1);
        this.manager.registerListener(this, this.sensor2, 1);
    }

    public void onAccuracyChanged(Sensor sensor, int i2) {
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        synchronized (this) {
            if (sensorEvent.sensor.getType() == 1) {
                float[] fArr = this.f4978f;
                float[] fArr2 = sensorEvent.values;
                fArr[0] = (fArr2[0] * 0.029999971f) + (fArr[0] * 0.97f);
                fArr[1] = (fArr2[1] * 0.029999971f) + (fArr[1] * 0.97f);
                fArr[2] = (fArr2[2] * 0.029999971f) + (fArr[2] * 0.97f);
            }
            if (sensorEvent.sensor.getType() == 2) {
                float[] fArr3 = this.f4977e;
                float[] fArr4 = sensorEvent.values;
                fArr3[0] = (fArr4[0] * 0.029999971f) + (fArr3[0] * 0.97f);
                fArr3[1] = (fArr4[1] * 0.029999971f) + (fArr3[1] * 0.97f);
                fArr3[2] = (fArr4[2] * 0.029999971f) + (fArr3[2] * 0.97f);
            }
            if (SensorManager.getRotationMatrix(this.f4974b, this.a, this.f4978f, this.f4977e)) {
                float[] fArr5 = new float[3];
                SensorManager.getOrientation(this.f4974b, fArr5);
                float degrees = ((((float) Math.toDegrees((double) fArr5[0])) + BitmapDescriptorFactory.HUE_RED) + 360.0f) % 360.0f;
                a aVar = this.f4976d;
                if (aVar != null) {
                    aVar.a(degrees);
                }
            }
        }
    }
}