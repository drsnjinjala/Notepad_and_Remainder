package com.locationtracker.numbertracker.callerid.calltracker.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.ui.simcard.SimCardInfoActivity;


public class SimDetailAdapter extends RecyclerView.Adapter<SimDetailAdapter.ViewHolder> {

    private Activity activity;
    String[] make = new String[8];
    private LayoutInflater inflater;

    public SimDetailAdapter(Activity activity2, String[] strArr) {
        this.activity = activity2;
        this.inflater = LayoutInflater.from(activity2);
        this.make = strArr;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_sim_details_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtTitle.setText(SimCardInfoActivity.arr[position]);
        holder.txtdesc.setText(this.make[position]);
    }

    @Override
    public int getItemCount() {
        return make.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final TextView txtTitle;
        public final TextView txtdesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.txtTitle = itemView.findViewById(R.id.txtTitle);
            this.txtdesc = itemView.findViewById(R.id.txtdesc);
        }
    }
}
