package com.locationtracker.numbertracker.callerid.calltracker.DataBase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface MyAddressesDao {
    @Delete
    void delete(MyAddresses myAddresses);

    @Query("DELETE FROM MyAddresses")
    void deleteAll();

    @Query("SELECT * FROM MyAddresses")
    LiveData<List<MyAddresses>> getAllNotes();

    @Insert
    void insert(MyAddresses myAddresses);

    @Update
    void update(MyAddresses myAddresses);
}
