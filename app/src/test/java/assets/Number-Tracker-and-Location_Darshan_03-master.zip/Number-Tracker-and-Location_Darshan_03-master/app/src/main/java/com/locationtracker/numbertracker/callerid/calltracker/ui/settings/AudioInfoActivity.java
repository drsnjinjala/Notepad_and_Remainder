package com.locationtracker.numbertracker.callerid.calltracker.ui.settings;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;

import androidx.annotation.Nullable;
import androidx.core.view.PointerIconCompat;
import androidx.databinding.DataBindingUtil;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivityAudioInfoBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import think.outside.the.box.handler.APIManager;

public class AudioInfoActivity extends ParentActivity {

    private ActivityAudioInfoBinding binding;
    private boolean mIsVibrateWhenRinging;
    private SharedPreferences.Editor ed;
    private int vibrate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_audio_info);


        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        binding.btnBack.setOnClickListener(view -> onBackPressed());

        initView();
    }

    private void initView() {

        ed = getSharedPreferences("vibrate_when_ringing", 0).edit();
        vibrate = Settings.System.getInt(getApplicationContext().getContentResolver(), "vibrate_when_ringing", 0);
        int i = vibrate;
        if (i == 0) {
            binding.checkVibrate.setChecked(false);
        } else if (i == 1) {
            binding.checkVibrate.setChecked(isVibrateWhenRinging());
        }

        binding.checkVibrate.setOnCheckedChangeListener(new vibrateCall());
        binding.btnRingtone.setOnClickListener(new ringtoneButton());
        binding.btnNotification.setOnClickListener(new notificationButton());
        binding.btnAlarm.setOnClickListener(new alarmButton());
    }

    private boolean isVibrateWhenRinging() {
        try {
            mIsVibrateWhenRinging = Settings.System.getInt(getContentResolver(), "vibrate_when_ringing") == 1;
            binding.checkVibrate.setChecked(true);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        return mIsVibrateWhenRinging;
    }

    class vibrateCall implements CompoundButton.OnCheckedChangeListener {
        vibrateCall() {
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            ed.putBoolean("vibrate_when_ringing", z);
            ed.commit();
            try {
                if (Settings.System.canWrite(AudioInfoActivity.this)) {
                mIsVibrateWhenRinging = isVibrateWhenRinging();
                    Settings.System.putInt(getContentResolver()
                            , "vibrate_when_ringing", mIsVibrateWhenRinging ? 0 : 1);
                    binding.checkVibrate.setChecked(isVibrateWhenRinging());
                } else {
                    binding.checkVibrate.setChecked(false);
                    startActivity(requestWriteSettingsIntent());
                }
            } catch (Exception e) {
                Log.d("error", "onCheckedChanged: " + e.getMessage());
            }
        }
    }

    private Intent requestWriteSettingsIntent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return intent;
        }
        return null;
    }


    class ringtoneButton implements View.OnClickListener {
        ringtoneButton() {
        }

        public void onClick(View view) {
            binding.btnRingtone.setEnabled(false);
            Uri actualDefaultRingtoneUri = RingtoneManager.getActualDefaultRingtoneUri(AudioInfoActivity.this, 1);
            Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
            intent.putExtra("android.intent.extra.ringtone.TYPE", 1);
            intent.putExtra("android.intent.extra.ringtone.TITLE", "Select Ringtone");
            intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", actualDefaultRingtoneUri);
            intent.putExtra("android.intent.extra.ringtone.SHOW_SILENT", true);
            intent.putExtra("android.intent.extra.ringtone.SHOW_DEFAULT", false);
            startActivityForResult(intent, 1001);
        }
    }

    class notificationButton implements View.OnClickListener {
        notificationButton() {
        }

        public void onClick(View view) {
            binding.btnNotification.setEnabled(false);
            Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
            intent.putExtra("android.intent.extra.ringtone.TYPE", 2);
            intent.putExtra("android.intent.extra.ringtone.TITLE", "Select Notification Tone");
            intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", RingtoneManager.getActualDefaultRingtoneUri(AudioInfoActivity.this, 2));
            startActivityForResult(intent, 1002);
        }
    }

    class alarmButton implements View.OnClickListener {
        alarmButton() {
        }

        public void onClick(View view) {
            binding.btnAlarm.setEnabled(false);
            Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
            intent.putExtra("android.intent.extra.ringtone.TYPE", 4);
            intent.putExtra("android.intent.extra.ringtone.TITLE", "Select Alarm Tone");
            intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", RingtoneManager.getActualDefaultRingtoneUri(AudioInfoActivity.this, 4));
            startActivityForResult(intent, PointerIconCompat.TYPE_HELP);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        binding.btnRingtone.setEnabled(true);
        binding.btnNotification.setEnabled(true);
        binding.btnAlarm.setEnabled(true);
    }


}