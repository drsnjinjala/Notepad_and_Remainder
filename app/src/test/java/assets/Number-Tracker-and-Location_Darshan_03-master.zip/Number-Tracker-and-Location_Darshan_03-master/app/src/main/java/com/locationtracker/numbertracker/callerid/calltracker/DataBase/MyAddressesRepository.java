package com.locationtracker.numbertracker.callerid.calltracker.DataBase;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class MyAddressesRepository {
    private LiveData<List<MyAddresses>> allItems;
    private MyAddressesDao myAddressesDao;

    public MyAddressesRepository(Application application) {
        MyAddressesDao myAddressesDao2 = AppDatabase.getInstance(application).myAddressesDao();
        this.myAddressesDao = myAddressesDao2;
        this.allItems = myAddressesDao2.getAllNotes();
    }

    public void insert(MyAddresses myAddresses) {
        new InsertNoteAsyncTask(this.myAddressesDao).execute(myAddresses);
    }

    public void update(MyAddresses myAddresses) {
        new UpdateItemAsyncTask(this.myAddressesDao).execute(myAddresses);
    }

    public void delete(MyAddresses myAddresses) {
        new DeleteNoteAsyncTask(this.myAddressesDao).execute(myAddresses);
    }

    public void deleteAllNotes() {
        new DeleteAllNotesAsyncTask(this.myAddressesDao).execute(new Void[0]);
    }

    public LiveData<List<MyAddresses>> getAllNotes() {
        return this.allItems;
    }

    private static class InsertNoteAsyncTask extends AsyncTask<MyAddresses, Void, Void> {
        private MyAddressesDao noteDao;

        private InsertNoteAsyncTask(MyAddressesDao myAddressesDao) {
            this.noteDao = myAddressesDao;
        }

        
        public Void doInBackground(MyAddresses... myAddressesArr) {
            this.noteDao.insert(myAddressesArr[0]);
            return null;
        }
    }

    private static class UpdateItemAsyncTask extends AsyncTask<MyAddresses, Void, Void> {
        private MyAddressesDao noteDao;

        private UpdateItemAsyncTask(MyAddressesDao myAddressesDao) {
            this.noteDao = myAddressesDao;
        }

        
        public Void doInBackground(MyAddresses... myAddressesArr) {
            this.noteDao.update(myAddressesArr[0]);
            return null;
        }
    }

    private static class DeleteNoteAsyncTask extends AsyncTask<MyAddresses, Void, Void> {
        private MyAddressesDao noteDao;

        private DeleteNoteAsyncTask(MyAddressesDao myAddressesDao) {
            this.noteDao = myAddressesDao;
        }

        
        public Void doInBackground(MyAddresses... myAddressesArr) {
            this.noteDao.delete(myAddressesArr[0]);
            return null;
        }
    }

    private static class DeleteAllNotesAsyncTask extends AsyncTask<Void, Void, Void> {
        private MyAddressesDao noteDao;

        private DeleteAllNotesAsyncTask(MyAddressesDao myAddressesDao) {
            this.noteDao = myAddressesDao;
        }

        
        public Void doInBackground(Void... voidArr) {
            this.noteDao.deleteAll();
            return null;
        }
    }
}
