package com.locationtracker.numbertracker.callerid.calltracker.ui.defaults;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.locationtracker.numbertracker.callerid.calltracker.R;

import think.outside.the.box.ui.BaseActivity;

public class PromptActivity extends BaseActivity {

    public int a;
    private TextView tvPromptTitle;
    private TextView tvPromptMsg;

    @Override
    public void onBackPressed() {
        if (this.a != 2) {
            super.onBackPressed();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        TextView textView;
        int i;
        setLightTheme(true);
        super.onCreate(bundle);
        setContentView(R.layout.activity_prompt);
        getWindow().setLayout(-1, -2);
        initView();
        int intExtra = getIntent().getIntExtra("PROMPT_TYPE", -1);
        this.a = intExtra;
        if (intExtra == 0) {

            textView = this.tvPromptMsg;
            i = R.string.app_name;
        } else if (intExtra == 1) {
            this.tvPromptTitle.setText(R.string.prompt_permission_notification_title);
            textView = this.tvPromptMsg;
            i = R.string.prompt_permission_notification_msg;
        } else if (intExtra != 2) {
            finish();
            return;
        } else {
            this.tvPromptTitle.setText(R.string.prompt_permission_disturb_title);
            textView = this.tvPromptMsg;
            i = R.string.prompt_permission_disturb_msg;
        }
        textView.setText(i);

    }

    private void initView() {
        tvPromptTitle = (TextView) findViewById(R.id.tv_prompt_title);
        tvPromptMsg = (TextView) findViewById(R.id.tv_prompt_msg);
    }
}