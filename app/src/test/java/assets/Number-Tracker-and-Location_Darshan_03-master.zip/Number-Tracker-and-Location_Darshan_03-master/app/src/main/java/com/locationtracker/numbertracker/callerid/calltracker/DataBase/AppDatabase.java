package com.locationtracker.numbertracker.callerid.calltracker.DataBase;

import android.content.Context;
import android.os.AsyncTask;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {MyAddresses.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static final String DATABASE_NAME = "LiveEarthMap";
    private static final String TAG = "AppDatabase";
    private static AppDatabase instance;
    private static Callback roomCallback = new Callback() {
        

        @Override 
        public void onCreate(SupportSQLiteDatabase supportSQLiteDatabase) {
            super.onCreate(supportSQLiteDatabase);
            new PopulateDbAsyncTask(instance).execute(new Void[0]);
        }
    };

    public abstract MyAddressesDao myAddressesDao();

    public static synchronized AppDatabase getInstance(Context context) {
        AppDatabase appDatabase;
        synchronized (AppDatabase.class) {
            if (instance == null) {
                instance = (AppDatabase) Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, DATABASE_NAME).fallbackToDestructiveMigration().addCallback(roomCallback).build();
            }
            appDatabase = instance;
        }
        return appDatabase;
    }

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        private MyAddressesDao myAddressesDao;

        public Void doInBackground(Void... voidArr) {
            return null;
        }

        private PopulateDbAsyncTask(AppDatabase appDatabase) {
            this.myAddressesDao = appDatabase.myAddressesDao();
        }
    }
}
