package com.moderntoolsapp.mobilenumbertracker.Fuel

import org.jsoup.nodes.Document


object Extion {
    fun extract(doc: Document): HashMap<String, List<CityPrice>> {
        var main = doc.getElementsByClass("sixteen columns row").last()
        var statemap = hashMapOf<String, List<CityPrice>>()
        var currentstate=""
        main?.children()?.forEach {
            if (it.`is`("h2")){
                currentstate=it.text()
            }else{
                var list= mutableListOf<CityPrice>()
                it.select("div.SF").forEach { it1 ->
                    var cityname= it1.select("a").text()
                    var arrowstring= it1.select("span.ArrowFall").text()
                    var price= it1.select("div.txtC").text()
                    list.add(CityPrice(cityname,arrowstring,price))
                }
                statemap.put(currentstate,list);
            }
        }
        return statemap
    }
}

data class CityPrice(var name:String,var arrow:String,var price:String)