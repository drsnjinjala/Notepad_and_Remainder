package com.locationtracker.numbertracker.callerid.calltracker.ui.simcard;

import android.content.Intent;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;

import com.locationtracker.numbertracker.callerid.calltracker.R;
import com.locationtracker.numbertracker.callerid.calltracker.adapter.SimDetailAdapter;
import com.locationtracker.numbertracker.callerid.calltracker.databinding.ActivitySimCardDetailBinding;
import com.locationtracker.numbertracker.callerid.calltracker.ui.screen.ParentActivity;

import think.outside.the.box.handler.APIManager;

public class SimCardDetailActivity extends ParentActivity {

    private ActivitySimCardDetailBinding binding;
    String[] data = new String[8];
    public int position;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_sim_card_detail);

        initView();
        APIManager.showSmallNative(binding.ads130);
        APIManager.showBanner(binding.ads65);
        binding.btnBack.setOnClickListener(view -> onBackPressed());
    }

    private void initView() {

        this.position = getIntent().getExtras().getInt("position");

        binding.txtCompany.setText(SimCardInfoActivity.dataModels.get(this.position).getName());
        binding.rcDetailList.setLayoutManager(new GridLayoutManager(this, 1));
        this.data = SimCardInfoActivity.dataModels.get(this.position).getDatamodels1().getTitles();
        binding.rcDetailList.setAdapter(new SimDetailAdapter(this, this.data));

        binding.btnGetCall.setOnClickListener(view -> {
            if (position == 0) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 1) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 2) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 3) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 4) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 5) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 6) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 7) {
                intent.putExtra("position", position);
                startActivity(intent);
            } else if (position == 8) {
                intent.putExtra("position", position);
                startActivity(intent);
            }
        });
    }


}