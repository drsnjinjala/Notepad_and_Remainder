package uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


@SuppressLint("RecyclerView")
public class StatusImageAdapter extends RecyclerView.Adapter<StatusImageAdapter.ViewHolder> {
    int selectedItemPosition = 0;

    public interface Callback {
        void OnItemClick(int position, ArrayList list);
    }

    Context context;
    private ArrayList rootImage;

    private OnItemClickListener clickListener;

    public StatusImageAdapter(Context context,  OnItemClickListener clickListener) {
        this.context = context;
        this.clickListener = clickListener;
        rootImage = new ArrayList();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.photo_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        //  Glide.with(context).load("https://toppng.com/uploads/preview/camel-11521379925q8wqizjrzp.png").centerCrop().placeholder(R.color.black).into(holder.imageItem);
        Glide.with(context).load(rootImage.get(position)).centerCrop().placeholder(R.color.black).into(holder.imageItem);

        if (rootImage.get(position).toString().endsWith(".mp4")) {
            holder.imageView.setVisibility(View.VISIBLE);
        } else {
            holder.imageView.setVisibility(View.GONE);
        }
        holder.imageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickListener.onItemClick(position, rootImage.get(position).toString());
                selectedItemPosition = position;
                notifyDataSetChanged();
            }
        });
        if (selectedItemPosition == position)
            holder.cardView.setCardBackgroundColor(Color.parseColor("#8FC34C"));
        else
            holder.cardView.setCardBackgroundColor(Color.parseColor("#00ffffff"));
    }


    @Override
    public int getItemCount() {
        return rootImage.size();
    }

    public void UpData(ArrayList Allitem) {
        rootImage.clear();
        this.rootImage = Allitem;
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int po, String path);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ShapeableImageView imageItem;
        ImageView imageView;
        CardView cardView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageItem = (ShapeableImageView) itemView.findViewById(R.id.myimage_item);
            imageView = itemView.findViewById(R.id.myplayerimage);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}
