package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.WpChat;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;


import java.util.ArrayList;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.ChatDetailsAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.DB.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.DB.NotificationModel;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityChatDetailBinding;

public class ChatDetailActivity extends AppCompatActivity {

    ArrayList<NotificationModel> arrayList;
    DatabaseHelper helper;
    ChatDetailsAdapter adapter;
    ActivityChatDetailBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        helper = DatabaseHelper.getInstance(this);
        arrayList = new ArrayList<>();

        arrayList = (ArrayList<NotificationModel>) helper.notificationDao().getAll();

        String name = getIntent().getStringExtra("Name");

        binding.tvTitle.setText(name);
        ArrayList<NotificationModel> uniqueList = new ArrayList<NotificationModel>();

        for (int i = 0; i < arrayList.size(); i++) {
            if (name.equals(arrayList.get(i).getTitle())) {
                uniqueList.add(arrayList.get(i));
            }
        }


        adapter = new ChatDetailsAdapter(uniqueList, this);
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.scrollToPosition(uniqueList.size() - 1);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(false);
        binding.recyclerView.setLayoutManager(linearLayoutManager);
        binding.recyclerView.setAdapter(adapter);


        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}