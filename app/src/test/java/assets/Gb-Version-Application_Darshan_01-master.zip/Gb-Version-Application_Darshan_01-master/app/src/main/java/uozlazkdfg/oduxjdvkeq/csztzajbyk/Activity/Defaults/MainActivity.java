package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults;

import static com.otaliastudios.cameraview.CameraView.PERMISSION_REQUEST_CODE;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import java.io.File;
import java.util.ArrayList;

import think.outside.the.box.handler.APIManager;
import think.outside.the.box.vpn.VpnConnection;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.ViewPagerAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.HomeFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.PhotosFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.SutasSaverFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.VideoFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityMainBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.GetFile;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.helper.PreferenceManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.ActivityKt;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class MainActivity extends BaseActivity {
    ActivityMainBinding binding;
    public static DocumentFile[] documentFiles;
    public static ArrayList<DocumentFile> rootDocumentVideo = new ArrayList();
    public String root;
    boolean doubleBackToExitPressedOnce = false;
    GetFile getFile;
    String WHATSAPP = "/WhatsApp/Media/.Statuses/";
    String WHATSAPPBu = "/WhatsApp Business/Media/.Statuses/";
    String ref;
    boolean isRun = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Utility.transparentStatusBar(this);
        setLightTheme(true);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        PreferenceManager.init(this);
        addTabs(binding.viewpager);
        setView();

        if (APIManager.isUpdate()) {
            APIManager.showUpdateDialog(this);
        }
        APIManager.showBanner(binding.adContainerBanner);
    }

    private void setView() {
        binding.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    binding.icDowWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.green));
                    binding.icHomeWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.balck_white));
//                    binding.icChatWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.balck_white));

                    binding.View1.setVisibility(View.VISIBLE);
                    binding.View2.setVisibility(View.GONE);
//                    binding.View3.setVisibility(View.GONE);
                    if (checkPermission()) {
                        if (isAppInstalled(MainActivity.this, "com.whatsapp")) {
                            getStatuswhatsapp();
                        } else {
                            Toast.makeText(MainActivity.this, "whatsapp Not Installed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                                    Manifest.permission.READ_MEDIA_VIDEO,
                                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                        } else {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                        }

                    }


                } else if (position == 1) {

                    binding.icDowWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.balck_white));
                    binding.icHomeWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.green));
//                    binding.icChatWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.balck_white));

                    binding.View1.setVisibility(View.GONE);
                    binding.View2.setVisibility(View.VISIBLE);
//                    binding.View3.setVisibility(View.GONE);

                } else {
                    String notificationListenerString = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
                    String packageName = getPackageName();
                    boolean isNotificationListenerEnabled = (notificationListenerString != null && notificationListenerString.contains(packageName));

                    if (!isNotificationListenerEnabled) {

                        Intent requestIntent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                        startActivity(requestIntent);
                    }

                    binding.icDowWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.balck_white));
                    binding.icHomeWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.balck_white));
//                    binding.icChatWhite.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.green));

                    binding.View1.setVisibility(View.GONE);
                    binding.View2.setVisibility(View.GONE);
//                    binding.View3.setVisibility(View.VISIBLE);

                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        binding.viewpager.setCurrentItem(1);
//        binding.ChateBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                binding.viewpager.setCurrentItem(2);
//            }
//        });
        binding.dowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (PreferenceManager.getInstance().getString("document_uri").isEmpty()){
                    if (checkPermission()) {
                        if (isAppInstalled(MainActivity.this, "com.whatsapp")) {
                            getStatuswhatsapp();
                        } else {
                            Toast.makeText(MainActivity.this, "whatsapp Not Installed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                                    Manifest.permission.READ_MEDIA_VIDEO,
                                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                        } else {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                        }

                    }
                }else {
                    binding.viewpager.setCurrentItem(0);
                }
            }
        });
        binding.HomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.viewpager.setCurrentItem(1);
            }
        });
    }

    ViewPagerAdapter adapter;

    private void addTabs(ViewPager viewpager) {
        adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new SutasSaverFragment(), "SaveFragment");
        adapter.addFrag(new HomeFragment(), "HomeFragment");
//        adapter.addFrag(new DeletedChatFragment(), "HomeFragment");

        viewpager.setAdapter(adapter);
        binding.viewpager.setOffscreenPageLimit(3);
    }

    @Override
    public void onBackPressed() {
        APIManager.showExitDialog(this);
//        if (binding.viewpager.getCurrentItem() == 0 || binding.viewpager.getCurrentItem() == 2) {
//            binding.viewpager.setCurrentItem(1);
//        } else {
//            if (doubleBackToExitPressedOnce) {
//                finishAffinity();
//                return;
//            }
//            this.doubleBackToExitPressedOnce = true;
//            Toast.makeText(this, "Please Click Back Again To Exit", Toast.LENGTH_SHORT).show();
//            new Handler(Looper.getMainLooper()).postDelayed(() -> doubleBackToExitPressedOnce = false, 2000);
//        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        VideoFragment.stopVideoPlaye();
    }

    @Override
    protected void onDestroy() {
        VpnConnection.stopVpn();
        super.onDestroy();
    }

    private void getStatuswhatsapp() {
        getFile = new GetFile();
        root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + getResources().getString(R.string.app_name) + "/Whatsapp");
        if (!file.mkdirs()) {
            file.mkdirs();
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q && new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp" + File.separator + "Media" + File.separator + ".Statuses").isDirectory()) {
            if (PreferenceManager.getInstance().getBoolean("isPermissionGranted", false)) {
//                DocumentFile fromTreeUri = DocumentFile.fromTreeUri(MainActivity.this, Uri.parse(PreferenceManager.getInstance().getString("document_uri")));
//                documentFiles = fromTreeUri.listFiles();
             /*   for (DocumentFile documentFile : documentFiles) {
                    if (documentFile.getName().endsWith(".jpg") || documentFile.getName().endsWith(".jpeg") || documentFile.getName().endsWith(".png")) {
                        rootImage.add(documentFile.getUri());
                        rootDocumentImage.add(documentFile);
                        Log.e(TAG, "onActivityResult: " + rootImage);

                    } else if (documentFile.getName().endsWith(".mp4") || documentFile.getName().endsWith(".mkv") || documentFile.getName().endsWith(".gif")) {
                        rootVideo.add(documentFile.getUri());
                        rootDocumentVideo.add(documentFile);
                    }
                }*/
                goNext();
            } else {
                ref = "WhatsappStatus";
                if (isRun) {
                    openWhatsappDirectory();
                    isRun = true;
                }
                binding.viewpager.setCurrentItem(1);
            }
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q && new File(Environment.getExternalStorageDirectory() + File.separator + "whatsapp/media" + File.separator + ".Statuses").isDirectory()) {
            getFile.StutsaImage(root + WHATSAPP);
            getFile.StutsaVideo(root + WHATSAPP);
            getFile.StutsaDownload(root + "/" + getResources().getString(R.string.app_name) + "/Whatsapp");

            goNext();
        }
    }

    private void goNext() {
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void openWhatsappDirectory() {
        String path = Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp" + File.separator + "Media" + File.separator + ".Statuses";

        File file = new File(path);
        String startDir = null;

        if (file.exists()) {
            startDir = "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses";
        }
        StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        Intent intent = sm.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString().replace("/root/", "/document/");
        uri = Uri.parse(scheme + "%3A" + startDir);
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        try {
//            someActivityResultLauncher.launch(intent);
            startActivityForResult(intent, 66);
        } catch (ActivityNotFoundException ignored) {

        }
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            for (Fragment fragment : adapter.mFragmentList) {
                                if (fragment instanceof PhotosFragment) {
                                    ((PhotosFragment) fragment).reload();
                                }
                            }
                        }
                    },1000);
//                    addTabs(binding.viewpager);
//                    binding.viewpager.setCurrentItem(1);
                }
            });

    private boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    @SuppressLint("WrongConstant")
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                if (uri.getPath().endsWith(".Statuses")) {
                    int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    }
                    if (ref.equals("WhatsappStatus")) {
                        PreferenceManager.getInstance().putString("document_uri", uri.toString());
                        PreferenceManager.getInstance().putBoolean("isPermissionGranted", true);
                    } else if (ref.equals("BusinessWhatsappStatus")) {
                        PreferenceManager.getInstance().putString("document_uri1", uri.toString());
                        PreferenceManager.getInstance().putBoolean("isPermissionGranted1", true);
                    }

                    if (Build.VERSION.SDK_INT >= 29) {
                        // uri is the path which we've saved in our shared pref

                        if (ref.equals("WhatsappStatus")) {
                            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(MainActivity.this, Uri.parse(PreferenceManager.getInstance().getString("document_uri")));
                            documentFiles = fromTreeUri.listFiles();
                        } else if (ref.equals("BusinessWhatsappStatus")) {
                            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(MainActivity.this, Uri.parse(PreferenceManager.getInstance().getString("document_uri1")));
                            documentFiles = fromTreeUri.listFiles();
                        }
                     /*   for (DocumentFile documentFile : documentFiles) {
                            if (documentFile.getName().endsWith(".jpg") || documentFile.getName().endsWith(".png") || documentFile.getName().endsWith(".jpeg")) {
                                rootImage.add(documentFile.getUri());
                                rootDocumentImage.add(documentFile);
                            } else if (documentFile.getName().endsWith(".mp4") || documentFile.getName().endsWith(".mkv") || documentFile.getName().endsWith(".gif")) {
                                rootVideo.add(documentFile.getUri());
                                rootDocumentVideo.add(documentFile);
                            }
                        }*/
                        goNext();
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        } else binding.viewpager.setCurrentItem(1);
    }

    private boolean checkPermission() {
        return ActivityKt.hasPermissions(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("value", "Permission Granted, Now you can use local drive .");
                    if (isAppInstalled(MainActivity.this, "com.whatsapp")) {
                        getStatuswhatsapp();


                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                                    Manifest.permission.READ_MEDIA_VIDEO,
                                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                        } else {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                        }
                    }
                } else {
                    Log.e("value", "Permission Denied, You cannot use local drive .");
                }
                break;
        }
    }
}