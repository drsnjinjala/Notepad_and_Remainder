package uozlazkdfg.oduxjdvkeq.csztzajbyk.utils

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.nativead.NativeAd
import think.outside.the.box.handler.APIManager
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.AdLayoutBannerBinding


fun viewNativeMediumTopButton(context: Context, viewGroup: ViewGroup, ad: NativeAd) {
    viewGroup.removeAllViews()
    val layoutInflater: LayoutInflater = LayoutInflater.from(context)
    val binding = AdLayoutBannerBinding.inflate(layoutInflater)
    populateAppInstallAdViewMediaMediumTopButton(ad, binding)
    viewGroup.removeAllViews()
    viewGroup.addView(binding.root)
}

fun populateAppInstallAdViewMediaMediumTopButton(
    unifiedNativeAd: NativeAd?,
    adUnified200Binding: AdLayoutBannerBinding
) {
    adUnified200Binding.unified.headlineView = adUnified200Binding.adTitleTextview
    adUnified200Binding.unified.bodyView = adUnified200Binding.adDescribeTextview
    adUnified200Binding.unified.callToActionView = adUnified200Binding.adActionButton
    adUnified200Binding.unified.iconView = adUnified200Binding.adIconImageview
    (adUnified200Binding.unified.headlineView as TextView?)?.text = unifiedNativeAd?.headline

    adUnified200Binding.adActionButton.backgroundTintList =
        ColorStateList.valueOf(Color.parseColor(APIManager.getButtonColor()))
    adUnified200Binding.adActionButton.setTextColor(Color.parseColor(APIManager.getButtonTextColor()))

    if (unifiedNativeAd?.body == null) {
        adUnified200Binding.unified.bodyView?.visibility = View.INVISIBLE
    } else {
        adUnified200Binding.unified.bodyView?.visibility = View.VISIBLE
        (adUnified200Binding.unified.bodyView as TextView?)?.text = unifiedNativeAd.body
    }
    if (unifiedNativeAd?.callToAction == null) {
        adUnified200Binding.unified.callToActionView?.visibility = View.INVISIBLE
    } else {
        adUnified200Binding.unified.callToActionView?.visibility = View.VISIBLE
        (adUnified200Binding.unified.callToActionView as TextView?)?.text =
            unifiedNativeAd.callToAction
    }
    if (unifiedNativeAd?.icon == null) {
        adUnified200Binding.unified.iconView?.visibility = View.GONE
    } else {
        (adUnified200Binding.unified.iconView as ImageView?)?.setImageDrawable(unifiedNativeAd.icon?.drawable)
        adUnified200Binding.unified.iconView?.visibility = View.VISIBLE
    }
    try {
        if (unifiedNativeAd != null) {
            adUnified200Binding.unified.setNativeAd(unifiedNativeAd)
        }
    } catch (e2: Exception) {
        e2.printStackTrace()
    }
}

