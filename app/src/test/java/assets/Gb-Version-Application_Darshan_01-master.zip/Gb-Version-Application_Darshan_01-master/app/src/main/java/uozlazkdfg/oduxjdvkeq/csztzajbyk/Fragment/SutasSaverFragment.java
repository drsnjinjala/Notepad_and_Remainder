package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.DocumentsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.nativead.NativeAd;

import java.io.File;
import java.util.ArrayList;

import l.b;
import think.outside.the.box.callback.AdsCallback;
import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.StatusDownloadActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.ViewPagerAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.FragmentStutasSaverBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.AdmobCBannerKt;


public class SutasSaverFragment extends Fragment {
    FragmentStutasSaverBinding binding;
    public static DocumentFile[] documentFiles;

    public static ArrayList<DocumentFile> rootDocumentVideo = new ArrayList();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentStutasSaverBinding.inflate(inflater, container, false);
        View view = binding.getRoot();


        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        goNext();
    }


    private void SetData() {
        binding.btnPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.viewpager1.setCurrentItem(0);

            }
        });

        binding.ivDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                APIManager.showInter(requireActivity(), false, isfail -> {
                    // write your code
                    startActivity(new Intent(requireActivity(), StatusDownloadActivity.class));
                });

//                File file=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile()+File.separator+ getActivity().getResources().getString(R.string.app_name) + "/Whatsapp/");
//                Uri uri =FileProvider.getUriForFile(getActivity(), getActivity().getPackageName()+".provider", file);
////                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
////                startActivity(Intent.createChooser(intent, "Open folder"));
//                Intent intent = new Intent(Intent.ACTION_VIEW);
////                intent.setDataAndType(uri, "resource/folder");
////                intent.setDataAndType(uri, "*/*");
//                intent.putExtra("android.provider.extra.INITIAL_URI", uri);
//                intent.setType(DocumentsContract.Document.MIME_TYPE_DIR);
////                intent.setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR);
//                intent.addFlags( Intent.FLAG_GRANT_READ_URI_PERMISSION );
//                intent.addFlags( Intent.FLAG_ACTIVITY_NEW_TASK ) ;
//                startActivity(intent);

//                if (intent.resolveActivityInfo(getContext().getPackageManager(), 0) != null)
//                {
//                    startActivity(intent);
//                }
//                else
//                {
//                    Toast.makeText(getActivity().getApplicationContext(), "Sorry", Toast.LENGTH_SHORT).show();
//                    // if you reach this place, it means there is no any file
//                    // explorer app installed on your device
//                }
            }
        });

        binding.videoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.viewpager1.setCurrentItem(1);
            }
        });

        binding.viewpager1.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    binding.btnPhoto.setBackgroundResource(R.drawable.walck_bg);
                    binding.videoBtn.setBackgroundResource(R.drawable.gry_backround);

//                    binding.tvphoto.setTextColor(getContext().getColor(R.color.gnt_white));
//                    binding.tvvideo.setTextColor(getContext().getColor(R.color.colorText));
                } else {
                    binding.btnPhoto.setBackgroundResource(R.drawable.gry_backround);
                    binding.videoBtn.setBackgroundResource(R.drawable.walck_bg);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        APIManager.getNativeObjects(new b() {
            @Override
            public void a(@Nullable NativeAd nativeAd) {
                if (nativeAd != null) {
                    AdmobCBannerKt.viewNativeMediumTopButton(requireContext(), binding.adContainerSmallNative, nativeAd);
                }
            }

            @Override
            public void a(boolean b) {
                ViewGroup.LayoutParams layoutParams = binding.adContainerSmallNative.getLayoutParams();
                layoutParams.height = 0;
                binding.adContainerSmallNative.setLayoutParams(layoutParams);
            }
        });
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();


    }

    @Override
    public void setMenuVisibility(boolean menuVisible) {
        super.setMenuVisibility(menuVisible);

        if (!menuVisible) {
            VideoFragment.stopVideoPlaye();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
//        binding.viewpager1.setCurrentItem(0);
    }

    private void addTabs(ViewPager viewpager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFrag(new PhotosFragment(), "PhotoFragment");
        adapter.addFrag(new VideoFragment(), "VideoFragment");

        viewpager.setAdapter(adapter);
    }


    private void goNext() {
        addTabs(binding.viewpager1);
        SetData();

    }


}