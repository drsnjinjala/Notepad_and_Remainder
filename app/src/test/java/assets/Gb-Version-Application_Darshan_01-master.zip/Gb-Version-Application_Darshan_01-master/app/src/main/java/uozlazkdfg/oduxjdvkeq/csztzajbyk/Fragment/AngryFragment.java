package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.AngryRecycerAdaptersGallery;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class AngryFragment extends Fragment {
    private String[] angryAscii = {"(≖︿≖ )", "(ง ͠° ͟ل͜ ͡°)ง", "ಠ_ಠ", "( ͠°Д°͠ )", "ლ(ಠ益ಠლ)", "(>ლ)", "(ง'-̀'́)ง", "(ノಠ益ಠ)ノ彡┻━┻", "(╯°□°）╯︵( .o.)", "(╯°□°）╯︵ /( ‿⌓‿ )\\", "(╯°□°）╯︵ ┻━┻", "┻━┻ ︵ヽ(`Д´)ﾉ︵ ┻━┻", "(┛◉Д◉)┛彡┻━┻ ", "(¬_¬)", "ಠoಠ", "ᕙ(⇀‸↼‶)ᕗ", "ᕦ(ò_óˇ)ᕤ", "¯\\_(ʘ_ʘ)_/¯", "( ͡°_ʖ ͡°)", "( ° ͜ʖ͡°)╭∩╮", "( ͡°Ĺ̯ ͡° )", "( ͠° ͟ʖ °͠ )", "¯\\_( ͠° ͟ʖ °͠ )_/¯", "( ͡°⊖ ͡°)", "ರ_ರ", "(>人<)", "ಠ╭╮ಠ", "(◣_◢)", "(⋋▂⋌)", "〴⋋_⋌〵", "(╹◡╹)凸", "ლ(͠°◞౪◟°͠ლ)", "╭∩╮(︶︿︶)╭∩╮", "(ㆆ_ㆆ)"};

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.angry_fragment, viewGroup, false);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.list);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        recyclerView.setHasFixedSize(true);
        AngryRecycerAdaptersGallery adapter = new AngryRecycerAdaptersGallery(getActivity(), this.angryAscii);
        recyclerView.setAdapter(adapter);
        return inflate;
    }

    public static AngryFragment newInstance() {
        return new AngryFragment();
    }

}
