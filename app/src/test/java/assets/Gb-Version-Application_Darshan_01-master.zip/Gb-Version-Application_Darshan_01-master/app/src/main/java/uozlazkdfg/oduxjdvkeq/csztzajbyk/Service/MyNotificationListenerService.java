package uozlazkdfg.oduxjdvkeq.csztzajbyk.Service;

import android.content.Context;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

public class MyNotificationListenerService extends NotificationListenerService {
    private String TAG = this.getClass().getSimpleName();
    Context context;
    public String mPreviousNotificationKey;
    static MyListener myListener;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn.getPackageName().equals("com.whatsapp")) {
            Log.i("~~~", "********** onNotificationPosted");
            //    Log.i(TAG, "ID :" + sbn.getId() + " \t " + sbn.getNotification().tickerText + " \t " + sbn.getPackageName());
            //   if (!sbn.getNotification().tickerText.toString().isEmpty()) {
            myListener.setValue(sbn, "Posted");
            //   }
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Log.i("~~~", "********** onNotificationRemoved");
        // Log.d(TAG, "ID :" + sbn.getId() + " \t " + sbn.getNotification().tickerText + " \t " + sbn.getPackageName());

        if (sbn.getPackageName().equals("com.whatsapp")) {
            // if (sbn.getNotification().tickerText.toString().equals("null")) {
            //  myListener.setValue(sbn,"Removed");
            // }
        }
    }

    public void setListener(MyListener myListener) {
        MyNotificationListenerService.myListener = myListener;
    }
}