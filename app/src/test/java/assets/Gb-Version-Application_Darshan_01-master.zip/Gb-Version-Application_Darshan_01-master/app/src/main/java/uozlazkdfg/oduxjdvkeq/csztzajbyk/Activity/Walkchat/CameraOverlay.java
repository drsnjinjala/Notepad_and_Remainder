package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Walkchat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import java.io.IOException;

public class CameraOverlay extends TextureView implements TextureView.SurfaceTextureListener {
    static CameraOverlay objCamOverlay;
    static WindowManager windowManager;
    Camera camera;

    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
    }

    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
    }

    public CameraOverlay(Context context) {
        super(context);
        setSurfaceTextureListener(this);
    }

    @SuppressLint("WrongConstant")
    public static View methOverlayCheck(Context context) {
        if (objCamOverlay == null) {
            objCamOverlay = new CameraOverlay(context);
        }
        if (windowManager == null) {
            windowManager = (WindowManager) context.getSystemService("window");
        }
        return objCamOverlay;
    }

    public static void methWinManager() {
        CameraOverlay cameraOverlay = objCamOverlay;
        if (cameraOverlay != null) {
            windowManager.removeView(cameraOverlay);
        }
    }

    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
        if (this.camera == null) {
            this.camera = Camera.open();
        }
        Camera camera2 = this.camera;
        if (camera2 != null) {
            Camera.Parameters parameters = camera2.getParameters();
            Camera.Size preferredPreviewSizeForVideo = parameters.getPreferredPreviewSizeForVideo();
            parameters.setPreviewSize(preferredPreviewSizeForVideo.width, preferredPreviewSizeForVideo.height);
            int i3 = 0;
            int[] iArr = parameters.getSupportedPreviewFpsRange().get(0);
            parameters.setPreviewFpsRange(iArr[0], iArr[1]);
            this.camera.setParameters(parameters);
            Matrix matrix = new Matrix();
            int rotation = windowManager.getDefaultDisplay().getRotation();
            int i4 = preferredPreviewSizeForVideo.width;
            int i5 = preferredPreviewSizeForVideo.height;
            if (rotation == 0) {
                i3 = 90;
                i4 = preferredPreviewSizeForVideo.height;
                i5 = preferredPreviewSizeForVideo.width;
            } else if (rotation == 1) {
                i4 = preferredPreviewSizeForVideo.width;
                i5 = preferredPreviewSizeForVideo.height;
            } else if (rotation == 2) {
                i3 = 270;
                i4 = preferredPreviewSizeForVideo.height;
                i5 = preferredPreviewSizeForVideo.width;
            } else if (rotation == 3) {
                i3 = 180;
                i4 = preferredPreviewSizeForVideo.width;
                i5 = preferredPreviewSizeForVideo.height;
            }
            this.camera.setDisplayOrientation(i3);
            setLayoutParams(new FrameLayout.LayoutParams(i4, i5, 17));
            setTransform(matrix);
            try {
                this.camera.setPreviewTexture(surfaceTexture);
                this.camera.startPreview();
            } catch (IOException unused) {
                this.camera.release();
                this.camera = null;
            }
        }
    }

    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        Camera camera2 = this.camera;
        if (camera2 == null) {
            return true;
        }
        camera2.stopPreview();
        this.camera.release();
        this.camera = null;
        return true;
    }
}
