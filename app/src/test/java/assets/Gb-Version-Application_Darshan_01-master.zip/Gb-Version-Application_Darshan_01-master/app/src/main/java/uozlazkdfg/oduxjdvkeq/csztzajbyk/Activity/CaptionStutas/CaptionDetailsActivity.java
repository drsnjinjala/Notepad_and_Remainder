package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.CaptionStutas;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.CaptionDetailsListAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class CaptionDetailsActivity extends BaseActivity {

    RelativeLayout bannerAds;
    RelativeLayout back;
    String[] items;
    ListView listViews;
    String name;
    int position;
    private RelativeLayout toolbar;
    private MaterialTextView toolbarName;
    private RelativeLayout relList;
    private ListView simpleListView;
    private RelativeLayout adBanner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caption);
        this.name = getIntent().getStringExtra("image");
        toolbarName = findViewById(R.id.toolbar_name);
        toolbarName.setText("" + name);
        int intExtra = getIntent().getIntExtra("P", 0);
        this.position = intExtra;
        if (intExtra == 0) {
            this.items = getResources().getStringArray(R.array.s_best);
        } else if (intExtra == 1) {
            this.items = getResources().getStringArray(R.array.s_clever);
        } else if (intExtra == 2) {
            this.items = getResources().getStringArray(R.array.s_cool);
        } else if (intExtra == 3) {
            this.items = getResources().getStringArray(R.array.s_cute);
        } else if (intExtra == 4) {
            this.items = getResources().getStringArray(R.array.s_fitness);
        } else if (intExtra == 5) {
            this.items = getResources().getStringArray(R.array.s_funny);
        } else if (intExtra == 6) {
            this.items = getResources().getStringArray(R.array.s_life);
        } else if (intExtra == 7) {
            this.items = getResources().getStringArray(R.array.s_love);
        } else if (intExtra == 8) {
            this.items = getResources().getStringArray(R.array.s_motivation);
        } else if (intExtra == 9) {
            this.items = getResources().getStringArray(R.array.s_sad);
        } else if (intExtra == 10) {
            this.items = getResources().getStringArray(R.array.s_savage);
        } else if (intExtra == 11) {
            this.items = getResources().getStringArray(R.array.s_selfie);
        } else if (intExtra == 12) {
            this.items = getResources().getStringArray(R.array.s_song);
        }
        initView();

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.simpleListView);
        CaptionDetailsListAdapter adapter = new CaptionDetailsListAdapter(this, this.items);

        recyclerView.setAdapter(adapter);

        APIManager.showNative(findViewById(R.id.adContainer_native));
        APIManager.showBanner(findViewById(R.id.adContainer_banner));
    }

    private void initView() {
        toolbar = findViewById(R.id.toolbar);
        relList = findViewById(R.id.rel_List);
        adBanner = findViewById(R.id.ad_banner);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {

        Utility.GotoBack(this);

    }
}