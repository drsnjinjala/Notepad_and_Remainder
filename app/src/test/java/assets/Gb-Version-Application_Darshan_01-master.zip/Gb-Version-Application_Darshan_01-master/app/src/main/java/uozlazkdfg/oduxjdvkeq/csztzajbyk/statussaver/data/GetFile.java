package uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data;

import static android.content.ContentValues.TAG;

import android.util.Log;

import java.io.File;
import java.util.ArrayList;

public class GetFile {
    // public  static ArrayList rootImage = new ArrayList();
    public static ArrayList rootVideo = new ArrayList();
    public static ArrayList rootDownload = new ArrayList();

    public void StutsaImage(String getpath) {
        File filePass = new File(getpath);
        File[] fileCheck = filePass.listFiles();

        if (fileCheck != null) {
            for (int i = 0; i < fileCheck.length; i++) {
                if (fileCheck[i].getAbsolutePath().endsWith(".jpg")
                        || fileCheck[i].getAbsolutePath().endsWith(".jpeg") || fileCheck[i].getAbsolutePath().endsWith(".png")) {
                    //   rootImage.add(fileCheck[i].getAbsolutePath());

                }
            }
        }
    }

    public void StutsaVideo(String getpath) {
        File filePass = new File(getpath);
        File[] fileCheck = filePass.listFiles();

        if (fileCheck != null) {
            for (int i = 0; i < fileCheck.length; i++) {
                if (fileCheck[i].getAbsolutePath().endsWith(".mp4")
                        || fileCheck[i].getAbsolutePath().endsWith(".gif") || fileCheck[i].getAbsolutePath().endsWith(".mkv")) {
                    rootVideo.add(fileCheck[i].getAbsolutePath());
                }
            }
        }
    }

    public void StutsaDownload(String getpath) {
        File filePass = new File(getpath);
        File[] fileCheck = filePass.listFiles();
        if (fileCheck != null) {
            for (int i = 0; i < fileCheck.length; i++) {
                if (fileCheck[i].getAbsolutePath().endsWith(".mp4") ||
                        fileCheck[i].getAbsolutePath().endsWith(".gif") ||
                        fileCheck[i].getAbsolutePath().endsWith(".mkv") ||
                        fileCheck[i].getAbsolutePath().endsWith(".jpg") ||
                        fileCheck[i].getAbsolutePath().endsWith(".jpeg") ||
                        fileCheck[i].getAbsolutePath().endsWith(".png")) {
                    rootDownload.add(fileCheck[i].getAbsolutePath());
                }
            }
        }
    }
}
