package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.PopupWindow;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper.EmojiconEditText;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper.EmojiconGridView;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper.EmojiconsPopup;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

public class EmojIconActions implements View.OnFocusChangeListener {
    /* access modifiers changed from: private */
    public int KeyBoardIcon = R.drawable.ic_action_keyboard;
    /* access modifiers changed from: private */
    public int SmileyIcons = R.drawable.smiley;
    /* access modifiers changed from: private */
    public Context context;
    /* access modifiers changed from: private */
    public ImageView emojiButton;
    /* access modifiers changed from: private */
    public EmojiconEditText emojiconEditText;
    /* access modifiers changed from: private */
    public List<EmojiconEditText> emojiconEditTextList = new ArrayList();
    /* access modifiers changed from: private */
    public KeyboardListener keyboardListener;
    /* access modifiers changed from: private */
    public EmojiconsPopup popup;
    private View rootView;
    private boolean useSystemEmoji = false;

    public interface KeyboardListener {
        void onKeyboardClose();

        void onKeyboardOpen();
    }

    public EmojIconActions(Context context2, View view, EmojiconEditText emojiconEditText2, ImageView imageView) {
        this.emojiButton = imageView;
        this.context = context2;
        this.rootView = view;
        addEmojiconEditTextList(emojiconEditText2);
        this.popup = new EmojiconsPopup(view, context2, this.useSystemEmoji);
    }

    public void addEmojiconEditTextList(EmojiconEditText... emojiconEditTextArr) {
        Collections.addAll(this.emojiconEditTextList, emojiconEditTextArr);
        for (EmojiconEditText onFocusChangeListener : emojiconEditTextArr) {
            onFocusChangeListener.setOnFocusChangeListener(this);
        }
    }

    public EmojIconActions(Context context2, View view, EmojiconEditText emojiconEditText2, ImageView imageView, String str, String str2, String str3) {
        addEmojiconEditTextList(emojiconEditText2);
        this.emojiButton = imageView;
        Context context3 = context2;
        this.context = context3;
        View view2 = view;
        this.rootView = view2;
        this.popup = new EmojiconsPopup(view2, context3, this.useSystemEmoji, str, str2, str3);
    }

    public void setIconsIds(int i, int i2) {
        this.KeyBoardIcon = i;
        this.SmileyIcons = i2;
    }

    public void setUseSystemEmoji(boolean z) {
        this.useSystemEmoji = z;
        for (EmojiconEditText useSystemDefault : this.emojiconEditTextList) {
            useSystemDefault.setUseSystemDefault(z);
        }
        refresh();
    }

    private void refresh() {
        this.popup.updateUseSystemDefault(this.useSystemEmoji);
    }

    public void ShowEmojIcon() {
        if (this.emojiconEditText == null) {
            this.emojiconEditText = this.emojiconEditTextList.get(0);
        }
        this.popup.setSizeForSoftKeyboard();
        this.popup.setOnDismissListener(new PopupWindow.OnDismissListener() {
            public void onDismiss() {
                EmojIconActions emojIconActions = EmojIconActions.this;
                emojIconActions.changeEmojiKeyboardIcon(emojIconActions.emojiButton, EmojIconActions.this.SmileyIcons);
            }
        });
        this.popup.setOnSoftKeyboardOpenCloseListener(new EmojiconsPopup.OnSoftKeyboardOpenCloseListener() {
            public void onKeyboardOpen(int i) {
                if (EmojIconActions.this.keyboardListener != null) {
                    EmojIconActions.this.keyboardListener.onKeyboardOpen();
                }
            }

            public void onKeyboardClose() {
                if (EmojIconActions.this.keyboardListener != null) {
                    EmojIconActions.this.keyboardListener.onKeyboardClose();
                }
                if (EmojIconActions.this.popup.isShowing()) {
                    EmojIconActions.this.popup.dismiss();
                }
            }
        });
        this.popup.setOnEmojiconClickedListener(new EmojiconGridView.OnEmojiconClickedListener() {
            public void onEmojiconClicked(Emojicon emojicon) {
                if (emojicon != null) {
                    int selectionStart = EmojIconActions.this.emojiconEditText.getSelectionStart();
                    int selectionEnd = EmojIconActions.this.emojiconEditText.getSelectionEnd();
                    if (selectionStart < 0) {
                        EmojIconActions.this.emojiconEditText.append(emojicon.getEmoji());
                    } else {
                        EmojIconActions.this.emojiconEditText.getText().replace(Math.min(selectionStart, selectionEnd), Math.max(selectionStart, selectionEnd), emojicon.getEmoji(), 0, emojicon.getEmoji().length());
                    }
                }
            }
        });
        this.popup.setOnEmojiconBackspaceClickedListener(new EmojiconsPopup.OnEmojiconBackspaceClickedListener() {
            public void onEmojiconBackspaceClicked(View view) {
                EmojIconActions.this.emojiconEditText.dispatchKeyEvent(new KeyEvent(0, 0, 0, 67, 0, 0, 0, 0, 6));
            }
        });
        showForEditText();
    }

    private void showForEditText() {
        this.emojiButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                if (EmojIconActions.this.emojiconEditText == null) {
                    EmojIconActions emojIconActions = EmojIconActions.this;
                    EmojiconEditText unused = emojIconActions.emojiconEditText = (EmojiconEditText) emojIconActions.emojiconEditTextList.get(0);
                }
                if (EmojIconActions.this.popup.isShowing()) {
                    EmojIconActions.this.popup.dismiss();
                } else if (EmojIconActions.this.popup.isKeyBoardOpen().booleanValue()) {
                    EmojIconActions.this.popup.showAtBottom();
                    EmojIconActions emojIconActions2 = EmojIconActions.this;
                    emojIconActions2.changeEmojiKeyboardIcon(emojIconActions2.emojiButton, EmojIconActions.this.KeyBoardIcon);
                } else {
                    EmojIconActions.this.emojiconEditText.setFocusableInTouchMode(true);
                    EmojIconActions.this.emojiconEditText.requestFocus();
                    ((InputMethodManager) EmojIconActions.this.context.getSystemService("input_method")).showSoftInput(EmojIconActions.this.emojiconEditText, 1);
                    EmojIconActions.this.popup.showAtBottomPending();
                    EmojIconActions emojIconActions3 = EmojIconActions.this;
                    emojIconActions3.changeEmojiKeyboardIcon(emojIconActions3.emojiButton, EmojIconActions.this.KeyBoardIcon);
                }
            }
        });
    }

    public void closeEmojIcon() {
        EmojiconsPopup emojiconsPopup = this.popup;
        if (emojiconsPopup != null && emojiconsPopup.isShowing()) {
            this.popup.dismiss();
        }
    }

    /* access modifiers changed from: private */
    public void changeEmojiKeyboardIcon(ImageView imageView, int i) {
        imageView.setImageResource(i);
    }

    public void onFocusChange(View view, boolean z) {
        if (z && (view instanceof EmojiconEditText)) {
            this.emojiconEditText = (EmojiconEditText) view;
        }
    }

    public void setKeyboardListener(KeyboardListener keyboardListener2) {
        this.keyboardListener = keyboardListener2;
    }
}
