package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.content.Context;
import android.widget.GridView;


import java.util.List;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class EmojiconRecentsGridView extends EmojiconGridView implements EmojiconRecents {
    EmojiAdapter mAdapter;
    private boolean mUseSystemDefault = false;

    public EmojiconRecentsGridView(Context context, Emojicon[] emojiconArr, EmojiconRecents emojiconRecents, EmojiconsPopup emojiconsPopup, boolean z) {
        super(context, emojiconArr, emojiconRecents, emojiconsPopup, z);
        this.mUseSystemDefault = z;
        EmojiAdapter emojiAdapter = new EmojiAdapter(this.rootView.getContext(), (List<Emojicon>) EmojiconRecentsManager.getInstance(this.rootView.getContext()), this.mUseSystemDefault);
        this.mAdapter = emojiAdapter;
        emojiAdapter.setEmojiClickListener(new OnEmojiconClickedListener() {
            public void onEmojiconClicked(Emojicon emojicon) {
                if (EmojiconRecentsGridView.this.mEmojiconPopup.onEmojiconClickedListener != null) {
                    EmojiconRecentsGridView.this.mEmojiconPopup.onEmojiconClickedListener.onEmojiconClicked(emojicon);
                }
            }
        });
        ((GridView) this.rootView.findViewById(R.id.Emoji_GridView)).setAdapter(this.mAdapter);
        EmojiAdapter emojiAdapter2 = this.mAdapter;
        if (emojiAdapter2 != null) {
            emojiAdapter2.notifyDataSetChanged();
        }
    }

    public void addRecentEmoji(Context context, Emojicon emojicon) {
        EmojiconRecentsManager.getInstance(context).push(emojicon);
        EmojiAdapter emojiAdapter = this.mAdapter;
        if (emojiAdapter != null) {
            emojiAdapter.notifyDataSetChanged();
        }
    }
}
