package uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.helper;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    private static final String PREF_NAME = "smart_files";
    private static PreferenceManager mManager;
    private static SharedPreferences mShare;

    public PreferenceManager() {

    }

    public static void init(Context context) {
        mManager = new PreferenceManager();
        mShare = context.getApplicationContext().getSharedPreferences(PREF_NAME, 0);
    }

    public static PreferenceManager getInstance() {
        return mManager;
    }

    public void putBoolean(String key, boolean value) {
        mShare.edit().putBoolean(key, value).apply();
    }

    public void putInt(String key, int value) {
        mShare.edit().putInt(key, value).apply();
    }

    public void putLong(String key, long value) {
        mShare.edit().putLong(key, value).apply();
    }

    public boolean getBoolean(String key, boolean b) {
        return mShare.getBoolean(key, b);
    }

    public int getInt(String key, int value) {
        return mShare.getInt(key, value);
    }

    public long getLong(String key) {
        return mShare.getLong(key, 0);
    }

    public void putString(String key, String value) {
        mShare.edit().putString(key, value).apply();
    }

    public String getString(String key) {
        return mShare.getString(key, "");
    }
}