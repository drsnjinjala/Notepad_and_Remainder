package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityPermissionBinding
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.PERMISSIONS
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.hasPermissions


class PermissionActivity : BaseActivity() {
    lateinit var binding: ActivityPermissionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        transparentStatusBar()
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        APIManager.showTopNative(binding.nativePermission);
        binding.swPermission.setOnCheckedChangeListener { _, z ->
            if (z) {
                checkPermissionCamera()
            }
        }
        binding.btnSkip.setOnClickListener {
            goNext()
        }
        binding.btnContinue.setOnClickListener {
            if (hasPermissions(PERMISSIONS)) {
                goNext()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun goNext() {
//        val notificationListenerString =
//            Settings.Secure.getString(this.contentResolver, "enabled_notification_listeners")
//        if (notificationListenerString == null || !notificationListenerString.contains(packageName)) {
//            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
//        } else {
            APIManager.showInter(this@PermissionActivity, false, object : AdsCallback {
                override fun onClose(isfail: Boolean) {
                    val mainIntent = Intent(this@PermissionActivity, MainActivity::class.java)
                    startActivity(mainIntent)
                    finish()
                }
            })
//        }
    }

    override fun onResume() {
        super.onResume()
        if (hasPermissions(PERMISSIONS)) {
            binding.swPermission.isChecked = true
            binding.animHand.visibility = View.GONE
            binding.swPermission.isEnabled = false
            binding.btnSkip.visibility = View.GONE
            binding.statusPermission.text = getString(R.string.permission_allowed)
            binding.statusPermission.setTextColor(getColor(R.color.colorAccent))
            return
        }
        binding.swPermission.isChecked = false
        binding.statusPermission.text = getString(R.string.permission_is_not_allow)
        binding.statusPermission.setTextColor(getColor(R.color.red))
    }


    private fun checkPermissionCamera() {
        if (!hasPermissions(PERMISSIONS)) {
            storagePermission.launch(PERMISSIONS)
            binding.swPermission.isChecked = false
            binding.statusPermission.text = getString(R.string.permission_is_not_allow)
            binding.statusPermission.setTextColor(getColor(R.color.red))
            return
        }
//        val notificationListenerString =
//            Settings.Secure.getString(this.contentResolver, "enabled_notification_listeners")
//        if (notificationListenerString == null || !notificationListenerString.contains(packageName)) {
//            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
//        }
        binding.swPermission.isChecked = true
        binding.statusPermission.text = getString(R.string.permission_allowed)
        binding.statusPermission.setTextColor(getColor(R.color.colorAccent))
        binding.animHand.visibility = View.GONE
    }

    override fun onBackPressed() {
        finish()
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            if (!hasPermissions(PERMISSIONS)) {
                this.binding.swPermission.isChecked = false
                displayDialogCamera()
                this.binding.statusPermission.text = getString(R.string.permission_is_not_allow)
                this.binding.statusPermission.setTextColor(getColor(R.color.red))
                return@registerForActivityResult
            }
            this.binding.swPermission.isChecked = true
            this.binding.swPermission.isEnabled = false
            this.binding.statusPermission.text = getString(R.string.permission_allowed)
            this.binding.statusPermission.setTextColor(getColor(R.color.colorAccent))
            this.binding.animHand.visibility = View.GONE
            this.binding.btnSkip.visibility = View.GONE
        }

    private fun displayDialogCamera() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(resources.getString(R.string.per_mission_message_camera))
        builder.setTitle(resources.getString(R.string.per_mission_title_camera))
        builder.setCancelable(false)
        builder.setPositiveButton(resources.getString(R.string.permission_go_to_setting)) { _, _ ->
            val intent = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
            intent.data = Uri.parse("package:$packageName")
            startActivityForResult(intent, 0)
        }
        builder.setNegativeButton(resources.getString(R.string.permission_cancel)) { dialogInterface, i ->
            dialogInterface.dismiss()
        }
        builder.create().show()
    }

    fun transparentStatusBar() {
        val window = window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
        }
        window.statusBarColor = Color.TRANSPARENT
    }
}