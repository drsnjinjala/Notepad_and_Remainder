package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowInsetsControllerCompat;


import com.google.android.material.imageview.ShapeableImageView;
import com.yalantis.ucrop.UCrop;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity; 
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.FakeChatActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.ChatsFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class EditChatUserProfile extends BaseActivity implements View.OnClickListener {
    public final int CODE_IMG_GALLARY = 1;
    public final String SAMPLE_CROPED_IMG_NAME = "SampleCropImg";
    RelativeLayout bannerAds;
    ChatsFragment chatsFragment = new ChatsFragment();
    RelativeLayout backmenu;
    byte[] blob;
    byte[] bmyimage;
    DatabaseHelper databaseHelper;
    TextView delete_Profile;
    String isonline;
    String istyping;
    Switch online;
    Uri selectedImageUri;
    String status;
    Switch typing;
    TextView update_Profile;
    String user;
    int user_id;
    EditText user_name;
    LinearLayout user_profilepic;
    ShapeableImageView user_profilepic1;
    EditText user_status;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.edit_chat_user_profile);

     //    setLightTheme(true);
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);

        this.databaseHelper = new DatabaseHelper(this);
        this.user_id = getIntent().getExtras().getInt("USER_ID");
        this.user_name = findViewById(R.id.user_name);
        this.user_status = findViewById(R.id.user_status);
        bannerAds = findViewById(R.id.ad_banner);

        this.user_profilepic = findViewById(R.id.user_profilepic);
        this.user_profilepic1 = findViewById(R.id.user_profilepic1);
        this.online = findViewById(R.id.user_onlile);
        this.typing = findViewById(R.id.user_typing);
        this.update_Profile = findViewById(R.id.edit_userProfile);
        this.delete_Profile = findViewById(R.id.delete_userProfile);
        GetCurrentUserDetails();
        this.update_Profile.setOnClickListener(this);
        this.delete_Profile.setOnClickListener(this);
        this.user_profilepic.setOnClickListener(this);
    }

    @SuppressLint("Range")
    private void GetCurrentUserDetails() {
        DatabaseHelper databaseHelper2 = this.databaseHelper;
        Cursor userHistory = databaseHelper2.getUserHistory(this.user_id + "");
        Log.d("Total Colounmn", userHistory.getCount() + "");
        userHistory.moveToFirst();
        for (int i = 0; i < userHistory.getCount(); i++) {
            this.user = userHistory.getString(userHistory.getColumnIndex("uname"));
            this.status = userHistory.getString(userHistory.getColumnIndex("ustatus"));
            this.isonline = userHistory.getString(userHistory.getColumnIndex("uonline"));
            this.istyping = userHistory.getString(userHistory.getColumnIndex("utyping"));
            this.blob = userHistory.getBlob(userHistory.getColumnIndex("uprofile"));
        }
        EditText editText = this.user_name;
        editText.setText(this.user + "");
        EditText editText2 = this.user_status;
        editText2.setText(this.status + "");
        this.online.setChecked(this.isonline.equals("online"));
        this.typing.setChecked(this.istyping.equals("typing"));
        this.user_profilepic1.setImageBitmap(getImagefromdatabase(this.blob));
    }

    private Bitmap getImagefromdatabase(byte[] bArr) {
        return BitmapFactory.decodeByteArray(bArr, 0, bArr.length);
    }

    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backmenu:
                onBackPressed();

                return;
            case R.id.delete_userProfile:
                this.databaseHelper.DeleteUserProfile(this.user_id);
                startActivity(new Intent(this, FakeChatActivity.class));

                finish();

                return;
            case R.id.edit_userProfile:
                String obj = this.user_name.getText().toString();
                String obj2 = this.user_status.getText().toString();
                String str = this.online.isChecked() ? "online" : "offline";
                String str2 = this.typing.isChecked() ? "typing" : "nottyping";
                if (this.bmyimage == null) {
                    Bitmap bitmap = ((BitmapDrawable) this.user_profilepic1.getDrawable()).getBitmap();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream);
                    this.bmyimage = byteArrayOutputStream.toByteArray();
                }
                this.databaseHelper.getUserDetailsUpdate(this.user_id, obj, obj2, str, str2, this.bmyimage);
                Toast.makeText(this, "Profile Updated...", 0).show();

                finish();

                return;
            case R.id.user_profilepic:
                startActivityForResult(new Intent()
                        .setAction(Intent.ACTION_GET_CONTENT)
                        .setType("image/*"), CODE_IMG_GALLARY);
                return;
            default:
                return;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CODE_IMG_GALLARY && resultCode == RESULT_OK) {
            Uri imageuri = data.getData();
            if (imageuri != null) {
                startCrop(imageuri);
            }
        } else if (requestCode == UCrop.REQUEST_CROP && resultCode == RESULT_OK) {
            Uri ImageUriResultCrop = UCrop.getOutput(data);

            if (ImageUriResultCrop != null) {
                this.user_profilepic1.setImageURI(ImageUriResultCrop);
                this.bmyimage = saveImageInDB(ImageUriResultCrop);
            }
        }
    }

    public void startCrop(Uri uri) {
        String destinationalFileNAme = SAMPLE_CROPED_IMG_NAME;

        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), destinationalFileNAme)));
        uCrop.withAspectRatio(1, 1);
        uCrop.withMaxResultSize(450, 450);
        uCrop.start(EditChatUserProfile.this);
    }

//    private void onSelectFromGalleryResult(Intent intent) {
//        try {
//            Uri data = intent.getData();
//            this.selectedImageUri = data;
//            this.user_profilepic.setImageURI(data);
//            this.bmyimage = saveImageInDB(this.selectedImageUri);
//            getPath(this.selectedImageUri);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    private byte[] saveImageInDB(Uri uri) {
        try {
            return getBytes(getContentResolver().openInputStream(uri));
        } catch (IOException e) {
            Log.e("Hello1", "<saveImageInDB> Error : " + e.getLocalizedMessage());
            return null;
        }
    }

    private byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
    }

    private String getPath(Uri uri) {
        Cursor managedQuery = managedQuery(uri, new String[]{"_data"}, null, null, null);
        int columnIndexOrThrow = managedQuery.getColumnIndexOrThrow("_data");
        managedQuery.moveToFirst();
        return managedQuery.getString(columnIndexOrThrow);
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}
