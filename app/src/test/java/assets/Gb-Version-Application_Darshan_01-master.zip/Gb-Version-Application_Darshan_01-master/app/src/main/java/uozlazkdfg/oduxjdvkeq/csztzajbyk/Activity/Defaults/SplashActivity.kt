package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.callback.SplashCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.getVPNStatus
import think.outside.the.box.handler.APIManager.initializeSplash
import think.outside.the.box.handler.APIManager.showSplashAD
import think.outside.the.box.vpn.VpnConnection
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.ComingSoonActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Theme.LanguageActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R

class SplashActivity : BaseActivity() {
    var vpnConnection: VpnConnection? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_splash)
        vpnConnection = VpnConnection(this)
        initializeSplash(this, object : SplashCallback {
            override fun onSuccess() {
                val s = try {
                    APIManager.getExtraData()?.getString("AppStatus") ?: "ON"
                } catch (ex: Exception) {
                    "ON"
                }
                if (s == "OFF") {
                    Handler(Looper.getMainLooper()).postDelayed({
                        val intent = Intent(this@SplashActivity, ComingSoonActivity::class.java)
                        startActivity(intent)
                        finish()
                    }, 2000)
                    return
                }

                if (getVPNStatus()) {
                    vpnConnection!!.connectVpnListener { goNext() }
                } else {
                    goNext()
                }
            }
        }, true)
    }

    private fun goNext() {
        showSplashAD(this@SplashActivity, object : AdsCallback {
            override fun onClose(b: Boolean) {
                val i =  Intent(this@SplashActivity, MainActivity::class.java);
//                val i = Intent(this@SplashActivity, LanguageActivity::class.java)
                startActivity(i)
                finish()
            }
        })
    }
}