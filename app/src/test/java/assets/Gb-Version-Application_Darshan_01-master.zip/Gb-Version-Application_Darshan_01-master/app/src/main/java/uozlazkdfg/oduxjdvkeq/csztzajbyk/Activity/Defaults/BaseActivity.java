package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import java.util.Locale;

import think.outside.the.box.util.TinyDB;

public class BaseActivity extends AppCompatActivity {
    public boolean hideNavigation = true;
    public boolean hideStatusBar = false;
    public boolean isLightTheme = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightTheme(true);
        String langCode = new TinyDB(this).getString("langCode");
        setLocale(this, langCode);
    }


    @Override
    public void onBackPressed() {
        finish();
    }

    public static void setLocale(Context activity, String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Resources resources = activity.getResources();
        Configuration config = resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            if (this.hideNavigation) {
                if (this.isLightTheme) {
                    this.getWindow().getDecorView().setSystemUiVisibility(12290);
                } else {
                    this.getWindow().getDecorView().setSystemUiVisibility(4098);
                }
            }

            if (this.hideStatusBar) {
                View decorView = this.getWindow().getDecorView();
                decorView.setSystemUiVisibility(5638);
            }
        }
    }

    public void setLightTheme(boolean lightTheme) {
        if (new TinyDB(this).getInt("theme", 1) == 1) {
            this.isLightTheme = true;
        } else {
            this.isLightTheme = false;
        }
    }

    public void setHideStatusBar(boolean hideStatusBar) {
        this.hideStatusBar = hideStatusBar;
    }

    public void setHideNavigation(boolean hideNavigation) {
        this.hideNavigation = hideNavigation;
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    public void themeToggleMode() {
        if (new TinyDB(this).getInt("theme", 1) == 1) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
    }
}