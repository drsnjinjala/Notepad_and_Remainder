package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.TextView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


@SuppressLint("AppCompatCustomView")
public class EmojiconTextView extends TextView {
    private int mEmojiconAlignment;
    private int mEmojiconSize;
    private int mEmojiconTextSize;
    private int mTextLength = -1;
    private int mTextStart = 0;
    private boolean mUseSystemDefault = false;

    public EmojiconTextView(Context context) {
        super(context);
        init((AttributeSet) null);
    }

    public EmojiconTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet);
    }

    public EmojiconTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(attributeSet);
    }

    private void init(AttributeSet attributeSet) {
        this.mEmojiconTextSize = (int) getTextSize();
        if (attributeSet == null) {
            this.mEmojiconSize = (int) getTextSize();
        } else {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.Emojicon);
            obtainStyledAttributes.recycle();
        }
        setText(getText());
    }

    public void setText(CharSequence charSequence, BufferType bufferType) {
        if (!TextUtils.isEmpty(charSequence)) {
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(charSequence);
            EmojiconHandler.addEmojis(getContext(), spannableStringBuilder, this.mEmojiconSize, this.mEmojiconAlignment, this.mEmojiconTextSize, this.mTextStart, this.mTextLength, this.mUseSystemDefault);
            charSequence = spannableStringBuilder;
        }
        super.setText(charSequence, bufferType);
    }

    public void setEmojiconSize(int i) {
        this.mEmojiconSize = i;
        super.setText(getText());
    }

    public void setUseSystemDefault(boolean z) {
        this.mUseSystemDefault = z;
    }
}
