package uozlazkdfg.oduxjdvkeq.csztzajbyk.Service;

import android.service.notification.StatusBarNotification;

public interface MyListener {
    void setValue (StatusBarNotification sbn,String s) ;

}
