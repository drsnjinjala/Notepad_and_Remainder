package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity; 
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.ChatAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.UserAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.d;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper.EmojiconEditText;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class UserChatActivity extends BaseActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private static final String TAG = "USER Activity";
    public static Bitmap callImages;
    public static ListView chatlist;
    public static String tokenname;
    ImageView videocalling;
    LinearLayout Attach;
    ImageView Call;
    LinearLayout More;
    LinearLayout attach;
    LinearLayout backmenu;
    ImageView background;
    Bitmap bitmap;
    LinearLayout camera;
    RelativeLayout chatbackground;
    ArrayList<String> chatid = new ArrayList<>();
    DatabaseHelper databaseHelper;
    EmojIconActions emojIcon;
    String imagepath;
    ArrayList<String> imagepathList = new ArrayList<>();
    ArrayList<String> ismessagetype = new ArrayList<>();
    String istext;
    EmojiconEditText message;
    ArrayList<String> messageArray = new ArrayList<>();
    RelativeLayout messageLayout;
    ImageView more_chat;
    ArrayList<String> msgstatuslist = new ArrayList<>();
    ArrayList<String> msgtime = new ArrayList<>();
    TextView name;
    String online;
    byte[] profile;
    ImageView receive;
    RelativeLayout recordlayout;
    ImageView send;
    String sender;
    ArrayList<String> senderUser = new ArrayList<>();
    String typing;
    Uri uri;
    ImageView user_icon;
    int user_id;
    LinearLayout userdetails;
    String username;
    TextView visibilitystatus;
    URL serveruri;

    private class btnMessageListner implements TextWatcher {
        public void afterTextChanged(Editable editable) {
        }

        private btnMessageListner() {
        }

        @SuppressLint("WrongConstant")
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            if (i3 > 0) {
                UserChatActivity.this.ViewLayout();
                return;
            }
            UserChatActivity.this.messageLayout.setVisibility(4);
            UserChatActivity.this.recordlayout.setVisibility(0);
            UserChatActivity.this.camera.setVisibility(0);
            UserChatActivity.this.attach.setVisibility(0);
        }

        @SuppressLint("WrongConstant")
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            UserChatActivity.this.messageLayout.setVisibility(4);
            UserChatActivity.this.recordlayout.setVisibility(0);
            UserChatActivity.this.camera.setVisibility(0);
            UserChatActivity.this.attach.setVisibility(0);
        }
    }

    private class btnEmojiIconListner implements EmojIconActions.KeyboardListener {
        private btnEmojiIconListner() {
        }

        public void onKeyboardOpen() {
            Log.e(UserChatActivity.TAG, "Keyboard opened!");
        }

        public void onKeyboardClose() {
            Log.e(UserChatActivity.TAG, "Keyboard closed");
        }
    }

    private class btnCallListner implements View.OnClickListener {
        private btnCallListner() {
        }

        public void onClick(View view) {
            UserChatActivity userChat = UserChatActivity.this;
            UserChatActivity.callImages = userChat.getImagefromdatabase(userChat.profile);
            Intent intent = new Intent(UserChatActivity.this, CallsActivity.class);
            intent.putExtra("NAME", UserChatActivity.this.username);
            intent.putExtra("ID", 2);

            UserChatActivity.this.startActivity(intent);

        }
    }

    private class btnMoreListner implements View.OnClickListener {
        public void onClick(View view) {
        }

        private btnMoreListner() {
        }
    }

    private class btnAttachListner implements View.OnClickListener {
        public void onClick(View view) {
        }

        private btnAttachListner() {
        }
    }

    @SuppressLint("WrongConstant")
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setStatusBarGradiant(this);
        //     setLightTheme(true);
        setContentView((int) R.layout.activity_user_chat);

//        setLightTheme(true);

        this.message = (EmojiconEditText) findViewById(R.id.message);
        this.imagepath = tokenname;
        this.databaseHelper = new DatabaseHelper(this);

        if (getIntent().getExtras() != null) {
            this.username = getIntent().getExtras().getString("USER_NAME");
            this.online = getIntent().getExtras().getString("USER_ONLINE");
            this.typing = getIntent().getExtras().getString("USER_TYPING");
        }
        this.Call = (ImageView) findViewById(R.id.imCall);
        this.recordlayout = (RelativeLayout) findViewById(R.id.recordLayout);
        this.messageLayout = (RelativeLayout) findViewById(R.id.messageLayout);
        TextView textView = (TextView) findViewById(R.id.username);
        this.name = textView;
        textView.setText(this.username + "");
        textView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        textView.setSelected(true);
        try {
            this.user_id = getIntent().getExtras().getInt("USER_ID");
            this.profile = UserAdapter.userdetails.get(getIntent().getExtras().getInt("USER_PROFILE")).getBytes();
        } catch (Exception exception) {

        }
        ImageView imageView = (ImageView) findViewById(R.id.user_icon);
        this.user_icon = imageView;
        byte[] bArr = this.profile;
        if (bArr != null) {
            imageView.setImageBitmap(getImagefromdatabase(bArr));
        }
        this.visibilitystatus = (TextView) findViewById(R.id.visibilitystatus);
        if (this.online.equals("online")) {
            this.visibilitystatus.setText(getResources().getString(R.string.online));
        }
        if (this.typing.equals("typing")) {
            this.visibilitystatus.setText(getResources().getString(R.string.typings));
        }
        this.videocalling = (ImageView) findViewById(R.id.videocalling);
        this.More = (LinearLayout) findViewById(R.id.more);
        this.Attach = (LinearLayout) findViewById(R.id.attach);
        this.camera = (LinearLayout) findViewById(R.id.camera);
        this.attach = (LinearLayout) findViewById(R.id.attach);
        this.send = (ImageView) findViewById(R.id.send);
        this.receive = (ImageView) findViewById(R.id.receive);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.backmenu);
        this.background = findViewById(R.id.background);
        this.backmenu = linearLayout;
        linearLayout.setOnClickListener(this);
        this.recordlayout.setOnClickListener(this);
        chatlist = (ListView) findViewById(R.id.chatlist);
        this.chatbackground = (RelativeLayout) findViewById(R.id.chatbackground);
        if (this.imagepath != null) {
            try {
                this.bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), FileProvider.getUriForFile(this, "android.arch.core.provider", new File(this.imagepath)));
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.chatbackground.setBackgroundDrawable(new BitmapDrawable(this.bitmap));
        }
        this.userdetails = (LinearLayout) findViewById(R.id.userdetails);
        this.more_chat = (ImageView) findViewById(R.id.background);
        this.send.setOnClickListener(this);
        this.receive.setOnClickListener(this);
        this.camera.setOnClickListener(this);
        this.more_chat.setOnClickListener(this);
        this.userdetails.setOnClickListener(this);
        chatlist.setOnItemClickListener(this);
        this.messageLayout.setVisibility(4);
        DisplayChat();
        this.message.addTextChangedListener(new btnMessageListner());
        this.chatbackground = (RelativeLayout) findViewById(R.id.chatbackground);
        EmojiconEditText emojiconEditText = (EmojiconEditText) findViewById(R.id.message);
        this.message = emojiconEditText;
        EmojIconActions emojIconActions = new EmojIconActions(this, this.chatbackground, emojiconEditText, (ImageView) findViewById(R.id.emoji_btn));
        this.emojIcon = emojIconActions;
        emojIconActions.ShowEmojIcon();
        this.emojIcon.setIconsIds(R.drawable.ic_action_keyboard, R.drawable.smiley);
        this.emojIcon.setKeyboardListener(new btnEmojiIconListner());
        this.Call.setOnClickListener(new btnCallListner());
        this.More.setOnClickListener(new btnMoreListner());
        this.Attach.setOnClickListener(new btnAttachListner());
        this.background.setOnClickListener(new setMenuBar());


        this.videocalling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserChatActivity userChat = UserChatActivity.this;
                UserChatActivity.callImages = userChat.getImagefromdatabase(userChat.profile);
                Intent intent = new Intent(getApplicationContext(), VideoScreenShow.class);
                intent.putExtra("profile", UserChatActivity.this.username);
                intent.putExtra("ID", 2);
                intent.putExtra("image", "" + userChat.getImagefromdatabase(userChat.profile));
                startActivity(intent);
            }
        });
    }

    /* access modifiers changed from: private */
    public Bitmap getImagefromdatabase(byte[] bArr) {
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, bArr.length);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        decodeByteArray.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
    }

    private void DisplayChat() {
        DatabaseHelper databaseHelper2 = this.databaseHelper;
        Cursor userChatHistory = databaseHelper2.getUserChatHistory(this.user_id + "");
        Log.d("Total Colounmn", userChatHistory.getCount() + "");
        userChatHistory.moveToFirst();
        for (int i = 0; i < userChatHistory.getCount(); i++) {
            @SuppressLint("Range") int i2 = userChatHistory.getInt(userChatHistory.getColumnIndex("chatid"));
            @SuppressLint("Range") String string = userChatHistory.getString(userChatHistory.getColumnIndex("sender"));
            @SuppressLint("Range") String string2 = userChatHistory.getString(userChatHistory.getColumnIndex("ismsg"));
            @SuppressLint("Range") String string3 = userChatHistory.getString(userChatHistory.getColumnIndex(NotificationCompat.CATEGORY_MESSAGE));
            @SuppressLint("Range") String string4 = userChatHistory.getString(userChatHistory.getColumnIndex(d.fl));
            @SuppressLint("Range") String string5 = userChatHistory.getString(userChatHistory.getColumnIndex("msgstatus"));
            @SuppressLint("Range") String string6 = userChatHistory.getString(userChatHistory.getColumnIndex("imagepath"));
            this.messageArray.add(string3);
            this.senderUser.add(string);
            this.msgtime.add(string4);
            this.msgstatuslist.add(string5);
            ArrayList<String> arrayList = this.chatid;
            arrayList.add(i2 + "");
            this.ismessagetype.add(string2);
            this.imagepathList.add(string6);
            userChatHistory.moveToNext();
            Log.i(TAG, "DisplayChat: " + this.chatid);
            chatlist.setAdapter(new ChatAdapter(this, this.messageArray, this.senderUser, this.msgtime, this.msgstatuslist, this.ismessagetype, this.imagepathList));
        }

    }

    /* access modifiers changed from: private */
    @SuppressLint("WrongConstant")
    public void ViewLayout() {
        this.messageLayout.setVisibility(0);
        this.recordlayout.setVisibility(4);
        this.camera.setVisibility(4);
        this.attach.setVisibility(4);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backmenu /*2131296437*/:
                onBackPressed();

                return;
            case R.id.camera /*2131296467*/:
                OpenDialog();
                return;
            case R.id.receive /*2131296929*/:
                this.sender = "no";
                this.istext = "yes";
                this.imagepath = " ";
                SaveChatUser(this.user_id, "no", "yes", " ");
                return;
            case R.id.recordLayout /*2131296934*/:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Under Construction.");
                builder.setItems(new CharSequence[]{"We are still working on this option"}, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                builder.show();
                return;
            case R.id.send /*2131296995*/:
                this.sender = "yes";
                this.istext = "yes";
                this.imagepath = " ";
                SaveChatUser(this.user_id, "yes", "yes", " ");
                return;
            case R.id.userdetails /*2131297194*/:
                Intent intent = new Intent(this, EditChatUserProfile.class);
                intent.putExtra("USER_ID", this.user_id);
                startActivity(intent);
                finish();
                return;
            default:
                return;
        }
    }

    private void OpenDialog() {
        final CharSequence[] charSequenceArr = {"Me", "My Friend"};
        AlertDialog.Builder title = new AlertDialog.Builder(this).setTitle("Who?");
        title.setItems(charSequenceArr, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                if (charSequenceArr[i].equals("Me")) {
                    UserChatActivity.this.sender = "yes";
                    UserChatActivity.this.SelectImageFromgallery();
                } else if (charSequenceArr[i].equals("My Friend")) {
                    UserChatActivity.this.sender = "no";
                    UserChatActivity.this.SelectImageFromgallery();
                }
            }
        });
        title.show();
    }

    /* access modifiers changed from: private */
    public void SelectImageFromgallery() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, 101);
//        startActivityForResult(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 101);
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && i == 101) {
            onSelectFromGalleryResult(intent);
        }
    }

    private void onSelectFromGalleryResult(Intent intent) {
        try {
            Uri data = intent.getData();
            this.uri = data;
            this.istext = "no";
            String uri2 = data.toString();
            this.imagepath = uri2;
            SaveChatUser(this.user_id, this.sender, this.istext, uri2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("Range")
    private void SaveChatUser(int i, String str, String str2, String str3) {

        int i2 = i;
        String format = new SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime());
        Log.d("CURRENT TIME", format);
        String obj = this.message.getText().toString();
        DatabaseHelper databaseHelper2 = this.databaseHelper;
        databaseHelper2.saveUserChat(i2 + "", str, str2, obj, format, "read", str3);
        DatabaseHelper databaseHelper3 = this.databaseHelper;
        Cursor userChatHistory = databaseHelper3.getUserChatHistory(i2 + "");
        int count = userChatHistory.getCount();
        Log.d("Total Colounmn", count + "");
        userChatHistory.moveToFirst();
        for (int i3 = 0; i3 < userChatHistory.getCount(); i3++) {
            ArrayList<String> arrayList = this.chatid;
            arrayList.add(userChatHistory.getInt(userChatHistory.getColumnIndex("chatid")) + "");
        }
        chatlist.smoothScrollToPosition(count);
        this.message.setText("");
        this.messageArray.add(obj);
        this.senderUser.add(str);
        this.msgtime.add(format);
        this.msgstatuslist.add("read");
        this.ismessagetype.add(str2);
        this.imagepathList.add(str3);
        ChatAdapter chatAdapter = new ChatAdapter(this, this.messageArray, this.senderUser, this.msgtime, this.msgstatuslist, this.ismessagetype, this.imagepathList);
        chatlist.setAdapter(chatAdapter);
        chatlist.setSelection(chatlist.getAdapter().getCount() - 1);
        chatAdapter.getCount();


    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
//        Intent intent = new Intent(this, EditMessageActivity.class);
//        intent.putExtra("MESSAGE", this.messageArray.get(i));
//        intent.putExtra("SENDER", this.senderUser.get(i));
//        intent.putExtra("STATUS", this.msgstatuslist.get(i));
//        intent.putExtra("CHATID", this.chatid.get(i));
//        intent.putExtra("POSITION", this.user_id);
//        intent.putExtra("USER_NAME", this.username);
//        intent.putExtra("USER_ONLINE", this.online);
//        intent.putExtra("USER_TYPING", this.typing);
//        intent.putExtra("USER_PROFILE", this.profile);
//        startActivity(intent);
//        finish();
//        overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_to_left);
    }

    private class setMenuBar implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            PopupMenu popup = new PopupMenu(UserChatActivity.this, background);
            popup.getMenuInflater().inflate(R.menu.menu_main, popup.getMenu());

            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {

                    if (menuItem.getItemId() == R.id.menu_share) {
                        Intent intent = new Intent();
                        intent.setAction("android.intent.action.SEND");
                        intent.putExtra("android.intent.extra.TEXT", "GB WHATS TOOL : https://play.google.com/store/apps/details?id=gbwhats.apktool.free");
                        intent.setType("text/plain");
                        startActivity(intent);
                    } else if (menuItem.getItemId() == R.id.menu_rate) {
                        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=gbwhats.apktool.free")));
                    } else if (menuItem.getItemId() == R.id.menu_policy) {
                        Intent intent2 = new Intent();
                        intent2.setAction("android.intent.action.VIEW");
                        intent2.addCategory("android.intent.category.BROWSABLE");
                        intent2.setData(Uri.parse("https://sites.google.com/view/fo7privacypolicy"));
                        startActivity(intent2);
                    }
                    return true;
                }
            });
            popup.show();
        }
    }

    public static void setStatusBarGradiant(Activity activity) {
        Window window = activity.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        //   window.setStatusBarColor(ContextCompat.getColor(activity, R.color.my_statusbar_color));
        window.setStatusBarColor(ContextCompat.getColor(activity, R.color.background_sky)); //
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}