package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Directchat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityChatDirectBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class DirectChatActivity extends BaseActivity {

    ActivityChatDirectBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
//        Utility.transparentStatusBar(this);
        binding = ActivityChatDirectBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        APIManager.showNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);
        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        binding.sendToWhatsapp.setOnClickListener(view -> {
            click();
        });
    }

    private void click() {
        if (binding.inputText.getText().toString().equals("")) {
            Toast.makeText(DirectChatActivity.this, "Please Enter number", Toast.LENGTH_SHORT).show();
        } else if (binding.msg.getText().toString().equals("")) {
            Toast.makeText(DirectChatActivity.this, "Please Enter Message", Toast.LENGTH_SHORT).show();
        } else {
            String sms = binding.msg.getText().toString();
            String toNumber = "91" + binding.inputText.getText().toString(); // contains spaces.
            toNumber = toNumber.replace("+", "").replace(" ", "");

            Intent sendIntent = new Intent("android.intent.action.MAIN");
            sendIntent.putExtra("jid", toNumber + "@s.whatsapp.net");
            sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.setPackage("com.whatsapp");
            sendIntent.setType("text/plain");
            try {
                startActivity(sendIntent);
            } catch (Exception unused) {
                Toast.makeText(DirectChatActivity.this, "WhatsApp is not Install!!", Toast.LENGTH_SHORT).show();
//                startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.whatsapp")));
            }
        }
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}