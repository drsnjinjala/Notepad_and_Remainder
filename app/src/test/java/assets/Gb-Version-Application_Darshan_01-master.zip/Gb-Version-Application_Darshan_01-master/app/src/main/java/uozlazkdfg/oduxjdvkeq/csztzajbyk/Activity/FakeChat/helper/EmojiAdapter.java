package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;


import java.util.List;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


class EmojiAdapter extends ArrayAdapter<Emojicon> {
    EmojiconGridView.OnEmojiconClickedListener emojiClickListener;
    private boolean mUseSystemDefault = false;

    public EmojiAdapter(Context context, List<Emojicon> list, boolean z) {
        super(context, R.layout.emojicon_item, list);
        this.mUseSystemDefault = z;
    }

    public EmojiAdapter(Context context, Emojicon[] emojiconArr, boolean z) {
        super(context, R.layout.emojicon_item, emojiconArr);
        this.mUseSystemDefault = z;
    }

    public void setEmojiClickListener(EmojiconGridView.OnEmojiconClickedListener onEmojiconClickedListener) {
        this.emojiClickListener = onEmojiconClickedListener;
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = View.inflate(getContext(), R.layout.emojicon_item, (ViewGroup) null);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.icon = (EmojiconTextView) view.findViewById(R.id.emojicon_icon);
            viewHolder.icon.setUseSystemDefault(this.mUseSystemDefault);
            view.setTag(viewHolder);
        }
        ViewHolder viewHolder2 = (ViewHolder) view.getTag();
        viewHolder2.icon.setText(((Emojicon) getItem(i)).getEmoji());
        viewHolder2.icon.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EmojiAdapter.this.emojiClickListener.onEmojiconClicked((Emojicon) EmojiAdapter.this.getItem(i));
            }
        });
        return view;
    }

    class ViewHolder {
        EmojiconTextView icon;

        ViewHolder() {
        }
    }
}
