package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager.showInter
import think.outside.the.box.handler.APIManager.showNative
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.AsciiFace.AsciiFaceActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Directchat.DirectChatActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.FakeChatActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.TextEmoji.TexttoEmojiActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.TextRepeater.TextRepeaterActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Walkchat.WalkChatActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.CaptionStatusActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.FragmentHomeBinding
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.PERMISSIONS
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.hasPermissions
import java.io.IOException

class HomeFragment : Fragment(), View.OnClickListener {
    var binding: FragmentHomeBinding? = null
    var SELECT_PICTURE = 100
    var PERMISSION_REQUEST_CODE = 202
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view: View = binding!!.root
        binding!!.TextEmojiButton.setOnClickListener(this)
        binding!!.ascifaceButton.setOnClickListener(this)
        binding!!.DirectmessageButton.setOnClickListener(this)
        binding!!.CreatdpButton.setOnClickListener(this)
        binding!!.FacechateButton.setOnClickListener(this)
        binding!!.WalkChatButton.setOnClickListener(this)
        binding!!.TextrrepeaterButton.setOnClickListener(this)
        binding!!.CaptionStutasButton.setOnClickListener(this)
        showNative(binding!!.adContainerNative, object : AdsCallback {
            override fun onClose(b: Boolean) {
                binding!!.imageViewTop.visibility = View.INVISIBLE
            }
        })
        return view
    }

    @SuppressLint("NonConstantResourceId")
    override fun onClick(view: View) {
        when (view.id) {
            R.id.TextEmojiButton -> if (checkPermission()) {
                Utility.GotoNext(activity, TexttoEmojiActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }

            R.id.ascifaceButton -> if (checkPermission()) {
                Utility.GotoNext(activity, AsciiFaceActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }

            R.id.DirectmessageButton -> if (checkPermission()) {
                Utility.GotoNext(activity, DirectChatActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }

            R.id.CreatdpButton -> if (checkPermission()) {
                showInter(requireActivity(), false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        val intent =
                            Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                        startActivityForResult(intent, SELECT_PICTURE)
                    }
                })
            } else {
                requestPermission() // Code for permission
            }

            R.id.FacechateButton -> if (checkPermission()) {
                Utility.GotoNext(activity, FakeChatActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }

            R.id.WalkChatButton -> if (checkPermission()) {
                Utility.GotoNext(activity, WalkChatActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }

            R.id.TextrrepeaterButton -> if (checkPermission()) {
                Utility.GotoNext(activity, TextRepeaterActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }

            R.id.CaptionStutasButton -> if (checkPermission()) {
                Utility.GotoNext(activity, CaptionStatusActivity::class.java)
            } else {
                requestPermission() // Code for permission
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                val selectedImageUri = Uri.parse("file://" + data!!.data)
                if (null != selectedImageUri) {
                    val imageUri = data.data
                    try {
                        val intent = Intent(Intent.ACTION_ATTACH_DATA)
                        intent.setDataAndType(imageUri, "image/jpg")
                        intent.putExtra("mimeType", "image/jpg")
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(Intent.createChooser(intent, "Set As"))
                        val bitmap = MediaStore.Images.Media.getBitmap(
                            activity?.contentResolver, data.data
                        )
                        //   setProfilePicture(bitmap);
                    } catch (e: IOException) {
                        throw RuntimeException(e)
                    }
                    //setWhatsAppProfilePicture(data.getData());
                }
            }
        }
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        }

    private fun checkPermission(): Boolean {
        return requireActivity().hasPermissions(PERMISSIONS)
    }

    private fun requestPermission() {
        storagePermission.launch(PERMISSIONS)
//        if (ActivityCompat.shouldShowRequestPermissionRationale(
//                activity!!,
//                Manifest.permission.WRITE_EXTERNAL_STORAGE
//            )
//        ) {
//            Toast.makeText(
//                activity,
//                "Write External Storage permission allows us to do store images. Please allow this permission in App Settings.",
//                Toast.LENGTH_LONG
//            ).show()
//        } else {
//            ActivityCompat.requestPermissions(
//                activity!!, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
//                PERMISSION_REQUEST_CODE
//            )
//        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (PERMISSION_REQUEST_CODE == 202) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.e("value", "Permission Granted, Now you can use local drive .")
            } else {
                Log.e("value", "Permission Denied, You cannot use local drive .")
            }
        }
    }
}