package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.SutasSaverFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.GetFile;


@SuppressLint("RecyclerView")
public class StatusVideoAdapter extends RecyclerView.Adapter<StatusVideoAdapter.ViewHolder> {
    public interface Callback {
        void OnItemClick(int position, ArrayList list);
    }

    int selectedItemPosition = 0;

    SutasSaverFragment whatsappOrBusinessActivity = new SutasSaverFragment();
    Callback callback;
    Context context;
    ArrayList list;
    String path;
    String str;
    GetFile getFile;
    String root;

    public StatusVideoAdapter(Context context, Callback callback) {
        this.context = context;
        list = new ArrayList();
        this.callback = callback;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.video_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {

            Glide.with(context).load(whatsappOrBusinessActivity.rootDocumentVideo.get(position).getUri()).centerCrop().placeholder(R.color.white).into(holder.imageItem);

        } else {
            Glide.with(context).load(list.get(position)).centerCrop().placeholder(R.color.white).into(holder.imageItem);
        }

        if (list.get(position).toString().endsWith(".mp4")) {
            holder.imageView.setVisibility(View.VISIBLE);
        } else {
            holder.imageView.setVisibility(View.GONE);
        }
        holder.imageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "onClick: " + position);
                callback.OnItemClick(position, list);
                selectedItemPosition = position;
                notifyDataSetChanged();
            }
        });
        if (selectedItemPosition == position)
            holder.cardView.setCardBackgroundColor(Color.parseColor("#8FC34C"));
        else
            holder.cardView.setCardBackgroundColor(Color.parseColor("#00ffffff"));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void UpData(ArrayList rootVideo) {
        this.list = rootVideo;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ShapeableImageView imageItem;
        ImageView imageView;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageItem = (ShapeableImageView) itemView.findViewById(R.id.image_item);
            cardView = itemView.findViewById(R.id.cardView);

            imageView = itemView.findViewById(R.id.playerimage);
        }
    }
}