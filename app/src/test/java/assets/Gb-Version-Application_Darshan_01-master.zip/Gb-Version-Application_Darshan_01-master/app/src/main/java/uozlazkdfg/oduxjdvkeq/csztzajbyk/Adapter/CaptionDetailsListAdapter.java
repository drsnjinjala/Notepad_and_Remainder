package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import static com.blankj.utilcode.util.ActivityUtils.startActivity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

public class CaptionDetailsListAdapter extends RecyclerView.Adapter<CaptionDetailsListAdapter.Myclass> {
    public Context context;

    public String[] items;

    public CaptionDetailsListAdapter(Context context, String[] items) {
        this.context = context;
        this.items = items;

    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.listview_item, parent, false);
        Myclass myclass = new Myclass(inflate);
        return myclass;
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onBindViewHolder(@NonNull Myclass holder, @SuppressLint("RecyclerView") int position) {
        holder.textView.setText(this.items[position]);
        holder.copyButton.setOnClickListener(view -> {
            ((ClipboardManager) context.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("Copied Text", items[position]));
            Toast.makeText(context, context.getResources().getString(R.string.copyline), 0).show();
        });

        try {

            holder.shareButton1.setVisibility(View.VISIBLE);
            holder.shareButton2.setVisibility(View.VISIBLE);

            holder.shareButton1.setVisibility(View.VISIBLE);
            holder.shareButton2.setVisibility(View.GONE);

            holder.shareButton1.setVisibility(View.GONE);
            holder.shareButton2.setVisibility(View.VISIBLE);
        } catch (Exception e) {

        }


        holder.shareButton1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                try {
                    String str = items[position];
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.setPackage("com.whatsapp");
                    intent.setType("text/plain");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("android.intent.extra.TEXT", str);
                    context.startActivity(intent);

                } catch (Exception e) {
                    Toast.makeText(context, "Whatsapp have not been installed.", 0).show();
                }

            }
        });
        holder.shareButton2.setOnClickListener(view -> {
            try {
                String str = items[position];
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.setType("text/plain");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("android.intent.extra.TEXT", str);
                context.startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(context, "Whatsapp have not been installed.", 0).show();
            }
        });

        holder.sharecaption.setOnClickListener(view -> {
            String str = items[position];
            shareText(str);

        });
    }

    private void shareText(String text) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(shareIntent, "Share text via"));
    }

    @Override
    public int getItemCount() {
        return items.length;
    }

    public class Myclass extends RecyclerView.ViewHolder {

        private ImageView imageView;
        private TextView textView;
        private LinearLayout actionLayout;
        private ImageView sharecaption;
        private ImageView copyButton;
        private ImageView shareButton1;
        private ImageView shareButton2;

        public Myclass(@NonNull View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            textView = (TextView) itemView.findViewById(R.id.textView);
            actionLayout = (LinearLayout) itemView.findViewById(R.id.action_layout);
            sharecaption = (ImageView) itemView.findViewById(R.id.sharecaption);
            copyButton = (ImageView) itemView.findViewById(R.id.copy_button);
            shareButton1 = (ImageView) itemView.findViewById(R.id.share_button1);
            shareButton2 = (ImageView) itemView.findViewById(R.id.share_button2);

        }
    }


    private boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }
}
