package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Theme

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager

import think.outside.the.box.util.TinyDB
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.IntroActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.LanguageAdapter
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityLanguageBinding


class LanguageActivity : BaseActivity() {
    private var tinyDB: TinyDB? = null
    private var languageAdapter: LanguageAdapter? = null
    private lateinit var binding: ActivityLanguageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val arrayList = ArrayList<Language>()
        tinyDB = TinyDB(this@LanguageActivity)

        APIManager.showNative(binding!!.nativeLanguage);
        languageAdapter = LanguageAdapter(this@LanguageActivity) { position, codeKey, image ->
            languageAdapter?.updatePosition(codeKey)
        }

        binding.apply {
            rcvLanguage.layoutManager = LinearLayoutManager(this@LanguageActivity)
            rcvLanguage.adapter = languageAdapter
            setLanguageList(arrayList)
            languageAdapter?.updateData(arrayList)
            val string = tinyDB?.getString("langCode", "en")
            languageAdapter?.updatePosition(string)
            cvSelect.setOnClickListener {
                tinyDB?.putString("langCode", languageAdapter?.lang)
                setLocale(this@LanguageActivity, languageAdapter?.lang)
                if (!intent.getBooleanExtra("fromSetting", false)) {
                    APIManager.showInter(this@LanguageActivity, false, object : AdsCallback {
                        override fun onClose(isfail: Boolean) {
                            val mainIntent = Intent(this@LanguageActivity, IntroActivity::class.java)
                            startActivity(mainIntent)
                        }
                    })
                } else {
                    APIManager.showInter(this@LanguageActivity, true, object : AdsCallback {
                        override fun onClose(isfail: Boolean) {
                            finish()
                        }
                    })
                }
            }
        }
    }

    private fun setLanguageList(arrayList: ArrayList<Language>) {
        arrayList.add(Language(R.drawable.english, getString(R.string.english), "en"))
        arrayList.add(Language(R.drawable.hindi, getString(R.string.hindi), "hi"))
        arrayList.add(Language(R.drawable.spanish, getString(R.string.spanish), "es"))
        arrayList.add(Language(R.drawable.africans, getString(R.string.african), "su"))
        arrayList.add(Language(R.drawable.russian, getString(R.string.russian), "ru"))
        arrayList.add(Language(R.drawable.portuguese, getString(R.string.portuguese), "pt"))
        arrayList.add(Language(R.drawable.indonesian, getString(R.string.indonesian), "id"))
        arrayList.add(Language(R.drawable.german, getString(R.string.german), "de"))
        arrayList.add(Language(R.drawable.italian, getString(R.string.italian), "it"))
    }

}