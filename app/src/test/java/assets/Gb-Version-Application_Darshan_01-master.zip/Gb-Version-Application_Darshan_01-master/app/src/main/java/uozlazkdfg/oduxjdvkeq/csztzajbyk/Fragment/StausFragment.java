package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class StausFragment extends Fragment {
    View view;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_status, viewGroup, false);
        this.view = inflate;
        return inflate;
    }
}
