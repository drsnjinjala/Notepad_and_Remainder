package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.content.Context;
import android.content.SharedPreferences;


import java.util.ArrayList;
import java.util.StringTokenizer;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;

public class EmojiconRecentsManager extends ArrayList<Emojicon> {
    private static final Object LOCK = new Object();
    private static final String PREFERENCE_NAME = "emojicon";
    private static final String PREF_PAGE = "recent_page";
    private static final String PREF_RECENTS = "recent_emojis";
    private static EmojiconRecentsManager sInstance;
    private Context mContext;

    private EmojiconRecentsManager(Context context) {
        this.mContext = context.getApplicationContext();
        loadRecents();
    }

    public static EmojiconRecentsManager getInstance(Context context) {
        if (sInstance == null) {
            synchronized (LOCK) {
                if (sInstance == null) {
                    sInstance = new EmojiconRecentsManager(context);
                }
            }
        }
        return sInstance;
    }

    public int getRecentPage() {
        return getPreferences().getInt(PREF_PAGE, 0);
    }

    public void setRecentPage(int i) {
        getPreferences().edit().putInt(PREF_PAGE, i).commit();
    }

    public void push(Emojicon emojicon) {
        if (contains(emojicon)) {
            super.remove(emojicon);
        }
        add(0, emojicon);
    }

    public boolean add(Emojicon emojicon) {
        return super.add(emojicon);
    }

    public void add(int i, Emojicon emojicon) {
        super.add(i, emojicon);
    }

    public boolean remove(Object obj) {
        return super.remove(obj);
    }

    private SharedPreferences getPreferences() {
        return this.mContext.getSharedPreferences(PREFERENCE_NAME, 0);
    }

    private void loadRecents() {
        StringTokenizer stringTokenizer = new StringTokenizer(getPreferences().getString(PREF_RECENTS, ""), "~");
        while (stringTokenizer.hasMoreTokens()) {
            try {
                add(new Emojicon(stringTokenizer.nextToken()));
            } catch (NumberFormatException unused) {
            }
        }
    }

    public void saveRecents() {
        StringBuilder sb = new StringBuilder();
        int size = size();
        for (int i = 0; i < size; i++) {
            sb.append(((Emojicon) get(i)).getEmoji());
            if (i < size - 1) {
                sb.append('~');
            }
        }
        getPreferences().edit().putString(PREF_RECENTS, sb.toString()).commit();
    }
}
