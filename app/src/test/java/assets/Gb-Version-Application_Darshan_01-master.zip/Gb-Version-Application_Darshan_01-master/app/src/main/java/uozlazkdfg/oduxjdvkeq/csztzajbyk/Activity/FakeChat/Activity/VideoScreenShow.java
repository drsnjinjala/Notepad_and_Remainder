package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;


import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.Facing;

import java.io.IOException;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity; 
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.CircleImageView;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.CallsFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class VideoScreenShow extends BaseActivity {
    private CircleImageView profile;
    private LinearLayout audioBtn;
    private LinearLayout videoBtn;
    private CameraView camera;
    private ImageView callend;
    private LinearLayout linear;
    private LinearLayout flip;
    private TextView privacy;
    private RelativeLayout relative;
    int id = 1;
    private TextView profilename;
    UserChatActivity userChat = new UserChatActivity();
    String username;
    Bitmap bitmap;
    View decorview;
    MediaPlayer mediaPlayer;

    @SuppressLint("MissingPermission")
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_screen_show);

        mediaPlayer = MediaPlayer.create(this, R.raw.phone_ringing);
        decorview = getWindow().getDecorView();
        decorview.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {

                if (visibility == 0) {
                    decorview.setSystemUiVisibility(hidesystembar());
                }
            }
        });

        //setHideStatusBar(true);
        initView();

        username = getIntent().getStringExtra("profile");

        if (getIntent().getExtras().getInt("ID") == 1) {
            if (CallsFragment.selectedImageUri != null) {
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), CallsFragment.selectedImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                    bitmap = null;
                }
                this.profile.setImageBitmap(bitmap);
            }
        } else {
            if (UserChatActivity.callImages != null) {
                this.profile.setImageBitmap(UserChatActivity.callImages);
            }
        }

        profilename.setText("" + username);
        camera.start();
        camera.setFacing(Facing.FRONT);
        mediaPlayer.start();


        callend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                VideoScreenShow.this.finish();
            }
        });

        flip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (id == 1) {
                    id = 2;
                    camera.setFacing(Facing.FRONT);
                } else if (id == 2) {
                    id = 1;
                    camera.setFacing(Facing.BACK);
                }
            }
        });

    }

    @SuppressLint("WrongViewCast")
    private void initView() {
        audioBtn = findViewById(R.id.audioBtn);
        videoBtn = findViewById(R.id.videoBtn);
        camera = findViewById(R.id.camera);
        callend = findViewById(R.id.callend);
        linear = findViewById(R.id.linear);
        flip = findViewById(R.id.flip);
        privacy = findViewById(R.id.privacy);
        relative = findViewById(R.id.relative);
        profilename = findViewById(R.id.profilename);
        profile = findViewById(R.id.profile);
    }

    public void onBackPressed() {
        super.onBackPressed();
        mediaPlayer.stop();
        Utility.GotoBack(this);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasWindowFocus()) {
            decorview.setSystemUiVisibility(hidesystembar());
        }
    }

    public int hidesystembar() {

        return View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
    }
}