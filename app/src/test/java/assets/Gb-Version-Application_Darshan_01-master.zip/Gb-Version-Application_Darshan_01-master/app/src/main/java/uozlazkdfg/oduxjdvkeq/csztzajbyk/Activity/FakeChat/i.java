package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat;

public final class i {
    public static final String APPLICATION_ID = "com.appnext.core";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = -1;
    public static final String VERSION_NAME = "2.5.3.472";
    public static final String co = "https://global.appnext.com";
    public static final String dh = "https://cdn.appnext.com/tools/sdk/banner/2.4.3";
    public static final String eT = "4.7.2";
    public static final boolean hj = false;
    public static final String hk = "https://cdn.appnext.com/tools/sdk/langs/2.4.4";
    public static final String hl = "https://cdn.appnext.com/tools/sdk/confign";
    public static final String hm = "http://apis.appnxt.net:443";
    public static final String hn = "https://api.appnxt.net";
    public static final String ho = "http://cdn.appnext.com/tools/services/4.7.2";
}
