package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R

class ComingSoonActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coming_soon)
    }
}