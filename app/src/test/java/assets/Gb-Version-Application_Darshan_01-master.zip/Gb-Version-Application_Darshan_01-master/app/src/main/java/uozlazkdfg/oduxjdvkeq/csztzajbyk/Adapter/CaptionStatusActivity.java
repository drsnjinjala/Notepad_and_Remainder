package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import android.content.Intent;
import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.CaptionStutas.CaptionAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.CaptionStutas.CaptionDetailsActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityCaptionDetailsBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class CaptionStatusActivity extends BaseActivity {

    ActivityCaptionDetailsBinding binding;
    CaptionAdapter adapter;
    String[] logos = {"Best", "Clever", "Cool", "Cute", "Fitness", "Funny", "Life", "Love", "Motivation", "Sad", "Savage", "Selfie", "Song"};
    GridLayoutManager gridLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityCaptionDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initView();
        adapter = new CaptionAdapter(this, logos, i -> {
            APIManager.showInter(CaptionStatusActivity.this, false, isfail -> {
                Intent intent = new Intent(CaptionStatusActivity.this, CaptionDetailsActivity.class);
                intent.putExtra("image", CaptionStatusActivity.this.logos[i]);
                intent.putExtra("P", i);
                CaptionStatusActivity.this.startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right,
                        R.anim.slide_out_left);
            });

        });

        gridLayoutManager = new GridLayoutManager(this, 3);

        binding.simpleGridView.setLayoutManager(gridLayoutManager);
        binding.simpleGridView.setAdapter(adapter);
        binding.back.setOnClickListener(v -> {
            onBackPressed();
        });

        APIManager.showNative(binding.adContainerNative);
        APIManager.showBanner(binding.adContainerBanner);

    }

    private void initView() {

    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}