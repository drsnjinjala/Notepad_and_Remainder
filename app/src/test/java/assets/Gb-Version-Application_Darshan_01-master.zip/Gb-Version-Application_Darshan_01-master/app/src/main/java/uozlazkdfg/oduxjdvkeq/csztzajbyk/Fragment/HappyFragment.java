package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.HappyAdaptersGallery;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class HappyFragment extends Fragment {

    private String[] happyAscii = {"¯\\_(ツ)_/¯", "(☞ﾟヮﾟ)☞", "(◕‿◕)", "(｡◕‿◕｡)", "( ಠ ͜ʖರೃ)", "(⊙﹏⊙)", "(◠﹏◠)", "(ﾉ◕ヮ◕)ﾉ", "( ͡° ͜ʖ ͡°)", "( ͡°( ͡° ͜ʖ( ͡° ͜ʖ ͡°)ʖ ͡°) ͡°)", "┬┴┬┴┤ ͜ʖ ͡°) ├┬┴┬┴", "(◕‿◕✿)", "ᕕ(✿◕‿◕)ᕗ", "ᕕ(  ◕‿◕)ᕗ", "(ᵔᴥᵔ)", "(づ￣ ³￣)づ", "\\ (•◡•) /", "\\(◕◡◕)/", "(☞ﾟヮﾟ)☞ ☜(ﾟヮﾟ☜)", "☜(ﾟヮﾟ☜)", "♪~ ᕕ(ᐛ)ᕗ", "༼ʘ̚ل͜ʘ̚༽", "ʘ‿ʘ", "~ (˘▾˘~)", "(~˘▾˘)~", "(͡o‿O͡)", "(❍ᴥ❍ʋ)", "| (• ◡•)| (❍ᴥ❍ʋ)", "─=≡Σᕕ( ͡° ͜ʖ ͡°)ᕗ", "( ͡° ͜ʖ ͡°)>⌐■-■", "( ͡ᶢ ͜ʖ ͡ᶢ)", "( ͡^ ͜ʖ ͡^)", "( ͡ᵔ ͜ʖ ͡ᵔ )", "( ͡° ͜ ͡°)", "(˵ ͡° ͜ʖ ͡°˵)", "(∩ ͡° ͜ʖ ͡°)⊃━☆ﾟ", "ᕦ( ͡° ͜ʖ ͡°)ᕤ", "（╯ ͡° ▽ ͡°）╯︵ ┻━┻", "( ͡°╭͜ʖ╮͡° )", "༼ つ  ͡° ͜ʖ ͡° ༽つ", "(｡◕‿‿◕｡)", "(ง°ل͜°)ง", "ಠ⌣ಠ", "♡‿♡", "(●´ω｀●)", "(╹◡╹)", "ლ(╹◡╹ლ)", "(づ｡◕‿‿◕｡)づ", "┏(＾0＾)┛┗(＾0＾) ┓"};

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.happy_fragment, viewGroup, false);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.list);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        recyclerView.setHasFixedSize(true);
        HappyAdaptersGallery adapter = new HappyAdaptersGallery(getActivity(),this.happyAscii);
        recyclerView.setAdapter(adapter);
        return inflate;
    }
    public static HappyFragment newInstance() {
        return new HappyFragment();
    }
}
