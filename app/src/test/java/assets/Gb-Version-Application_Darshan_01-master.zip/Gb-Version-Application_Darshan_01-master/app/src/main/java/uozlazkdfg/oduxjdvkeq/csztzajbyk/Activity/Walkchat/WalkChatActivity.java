package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Walkchat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityWalkchatBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class WalkChatActivity extends BaseActivity {

    public static boolean isWalk = true;
    private ActivityWalkchatBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Utility.transparentStatusBar(this);

        binding = ActivityWalkchatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        APIManager.showSmallNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);

        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        binding.openWhatsapp.setOnClickListener(v -> {
            try {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");
                startActivity(sendIntent);

            } catch (Exception e) {
                Toast.makeText(WalkChatActivity.this, "Whatsapp have not been installed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }

}