package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat;


/* compiled from: Annotations.kt */
public enum AnnotationRetention {
    SOURCE,
    BINARY,
    RUNTIME
}
