package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.OtherAdaptersGallery;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class OtherFragment extends Fragment {
    private String[] OtherAscii = {"( ཀ ʖ̯ ཀ)", "(╥﹏╥)", "( ͡°ᴥ ͡° ʋ)", "ಠ_ಥ", "ಠ~ಠ", "ʕ◉.◉ʔ", "༼ つ ◕_◕ ༽つ", "(ಥ﹏ಥ)", "ヾ(⌐■_■)ノ", "( ︶︿︶)", "(✖╭╮✖)", "༼ つ ಥ_ಥ ༽つ", "(\"º _ º)", "┬─┬ノ( º _ ºノ)", "(._.) ( l: ) ( .-. ) ( :l ) (._.)", "༼ ºل͟º ༼ ºل͟º ༼ ºل͟º ༽ ºل͟º ༽ ºل͟º ༽", "┬┴┬┴┤(･_├┬┴┬┴", "(°ロ°)☝", "(▀̿Ĺ̯▀̿ ̿)", "﴾͡๏̯͡๏﴿ O'RLY?", "⚆ _ ⚆", "ಠ‿↼", "☼.☼", "◉_◉", "( ✧≖ ͜ʖ≖)", "( ͠° ͟ʖ ͡°)", "( ‾ ʖ̫ ‾)", "(͡ ͡° ͜ つ ͡͡°)", "( ﾟдﾟ)", "┬──┬ ノ( ゜-゜ノ)", "¯\\(°_o)/¯", "(ʘᗩʘ')", "☜(⌒▽⌒)☞", "(;´༎ຶД༎ຶ`)", "̿̿ ̿̿ ̿̿ ̿'̿'\\̵͇̿̿\\з= ( ▀ ͜͞ʖ▀) =ε/̵͇̿̿/’̿’̿ ̿ ̿̿ ̿̿ ̿̿", "[̲̅$̲̅(̲̅5̲̅)̲̅$̲̅]", "(ᇂﮌᇂ)", "(≧ω≦)", "►_◄", "أ ̯ أ", "ლ(╹ε╹ლ)", "ᇂ_ᇂ", "＼(￣ー＼)(／ー￣)／", "♪┏ ( ･o･) ┛♪┗ (･o･ ) ┓♪┏(･o･)┛♪", "╘[◉﹃◉]╕", "( ･_･)♡", "(¤﹏¤)", "( ˘︹˘ )"};

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(R.layout.other_fragment, viewGroup, false);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.list);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        recyclerView.setHasFixedSize(true);
        OtherAdaptersGallery adapter = new OtherAdaptersGallery(getActivity(),this.OtherAscii);
        recyclerView.setAdapter(adapter);
        return inflate;
    }
}
