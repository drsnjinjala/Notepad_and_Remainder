package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.ChatActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.FakeChatActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.UserChatActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails.UserDetails;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.UserAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class ChatsFragment extends Fragment implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {
    public static ArrayList<UserDetails> arrayList;
    public DatabaseHelper databaseHelper;
    private FloatingActionButton materialDesignFAM;
    private Cursor objCursor;
    public UserAdapter userAdapter;
    public ListView userList;
    View view;
    int j;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = layoutInflater.inflate(R.layout.fragment_chat, viewGroup, false);
        this.databaseHelper = new DatabaseHelper(getActivity());

        materialDesignFAM = view.findViewById(R.id.material_design_android_floating_action_menu);
        userList = view.findViewById(R.id.userlist);
        CallList();
        materialDesignFAM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utility.GotoNext(getActivity(), ChatActivity.class);
            }
        });
        return view;
    }

    private void CallList() {
        GetUserDetails();
        this.userList.setOnItemClickListener(this);
        this.userList.setOnItemLongClickListener(this);
    }

    private void GetUserDetails() {
        this.objCursor = this.databaseHelper.ViewUserList();
        arrayList = new ArrayList<>();
        this.objCursor.moveToFirst();
        for (int i = 0; i < this.objCursor.getCount(); i++) {
            Cursor cursor = this.objCursor;
            @SuppressLint("Range") int i2 = cursor.getInt(cursor.getColumnIndex("uid"));
            Cursor cursor2 = this.objCursor;
            @SuppressLint("Range") String string = cursor2.getString(cursor2.getColumnIndex("uname"));
            Cursor cursor3 = this.objCursor;
            @SuppressLint("Range") String string2 = cursor3.getString(cursor3.getColumnIndex("ustatus"));
            Cursor cursor4 = this.objCursor;
            @SuppressLint("Range") String string3 = cursor4.getString(cursor4.getColumnIndex("utyping"));
            Cursor cursor5 = this.objCursor;
            @SuppressLint("Range") String string4 = cursor5.getString(cursor5.getColumnIndex("uonline"));
            Cursor cursor6 = this.objCursor;
            @SuppressLint("Range") byte[] blob = cursor6.getBlob(cursor6.getColumnIndex("uprofile"));
            UserDetails userDetails = new UserDetails();
            userDetails.setUid(i2);
            userDetails.setUname(string);
            userDetails.setUstatus(string2);
            userDetails.setUonline(string4);
            userDetails.setUtyping(string3);
            userDetails.setBytes(blob);
            arrayList.add(userDetails);
            this.objCursor.moveToNext();
            userAdapter = new UserAdapter(getActivity(), arrayList);
            this.userList.setAdapter((ListAdapter) userAdapter);
            userAdapter.notifyDataSetChanged();
        }
    }

    private void CallDialog(int i) {
        final UserDetails userDetails = arrayList.get(i);
        j = i;
        Log.i("ContentValues", "SEND ID: " + userDetails.getUid());
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(getActivity());
        builder.setTitle("Delete Conversation.");
        builder.setMessage("Are you sure you want to delete this conversation?");
        builder.setPositiveButton("YES", (dialogInterface, i2) -> {
            databaseHelper.DeleteUserProfile(userDetails.getUid());
            ChatsFragment.arrayList.remove(j);
            ChatsFragment.this.userAdapter.notifyDataSetChanged();
        });
        builder.setNegativeButton("NO", (dialog, which) -> dialog.dismiss());
        builder.setNeutralButton("Rate Us", (dialog, which) -> startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + ChatsFragment.this.getActivity().getPackageName()))));
        builder.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        CallList();
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        APIManager.showInter(getActivity(), false, isfail -> {
            Intent intent = new Intent(getActivity(), UserChatActivity.class);
            UserDetails userDetails = arrayList.get(i);
            intent.putExtra("USER_ID", userDetails.getUid());
            intent.putExtra("USER_NAME", userDetails.getUname());
            intent.putExtra("USER_ONLINE", userDetails.getUonline());
            intent.putExtra("USER_TYPING", userDetails.getUtyping());
            intent.putExtra("USER_PROFILE", i);
            startActivity(intent);
        });

    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        CallDialog(i);
        return true;
    }
}
