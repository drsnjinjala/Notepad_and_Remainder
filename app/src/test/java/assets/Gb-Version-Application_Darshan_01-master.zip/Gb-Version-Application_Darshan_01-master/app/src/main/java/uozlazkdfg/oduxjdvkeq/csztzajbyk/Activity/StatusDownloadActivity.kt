package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import think.outside.the.box.handler.APIManager
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityStatusDownloadBinding
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.VideoItemBinding
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility
import java.io.File


private const val TAG = "StatusDownloadActivity"

class StatusDownloadActivity : BaseActivity() {
    lateinit var binding: ActivityStatusDownloadBinding
    var adapter: StatusAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatusDownloadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setData()

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.ivDelete.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setMessage("Are you sure you want to delete ?")
                .setPositiveButton("Delete") { dialog, which ->
                    // Respond to positive button press
                    adapter?.getSelectedFiles()?.forEach {
                        it.delete()
                    }
                    setData()
                }
                .setNegativeButton("Cancel") { dialog, which ->
                    // Respond to positive button press
                }
                .show()
        }

        APIManager.showSmallNative(binding!!.adContainerSmallNative);
        APIManager.showBanner(binding!!.adContainerBanner);
    }

    private fun setData() {
        val videofile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            File.separator + getResources().getString(
                R.string.app_name
            ) + "/Whatsapp/Video"
        )

        val photofile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            File.separator + getResources().getString(
                R.string.app_name
            ) + "/Whatsapp/Photo"
        )
        var files = photofile.listFiles()?.toMutableList() ?: mutableListOf()
        videofile.listFiles()?.let { files.addAll(it.toMutableList()) }
        files.sortByDescending { it.lastModified() }
        Log.e(TAG, "onCreate: " + files)

        binding.recycler.layoutManager = GridLayoutManager(this, 3)
        adapter = StatusAdapter(this, files)
        binding.recycler.adapter = adapter
    }


    class StatusAdapter(val context: Context, val files: MutableList<File>) :
        RecyclerView.Adapter<StatusAdapter.Holder>() {

        var list = mutableListOf<Int>()

        class Holder(itemView: VideoItemBinding) : RecyclerView.ViewHolder(itemView.root) {
            val binding = itemView
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = VideoItemBinding.inflate(LayoutInflater.from(context), parent, false)
            return Holder(view)
        }

        override fun getItemCount(): Int {
            return files.size
        }

        fun getSelectedFiles(): MutableList<File> {
            var filelist = mutableListOf<File>()
            list.forEach {
                filelist.add(files.get(it))
            }
            return filelist
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
//            if (files.get(position).getName().endsWith(".mp4") || files.get(position).getName().endsWith(".mkv") || files.get(position).getName().endsWith(".gif")) {
//                Glide.with(context).load(files.get(position))
//                    .centerCrop().placeholder(R.color.white).into( holder.binding.imageItem)
//            }else{
//            }
            holder.binding.checkDelete.isVisible = true
            holder.binding.checkDelete.isChecked = list.contains(position)

            Glide.with(context).load(files.get(position)).centerCrop().placeholder(R.color.white)
                .into(holder.binding.imageItem)

            if (files.get(position).toString().endsWith(".mp4")) {
                holder.binding.playerimage.setVisibility(View.VISIBLE)
            } else {
                holder.binding.playerimage.setVisibility(View.GONE)
            }

            holder.binding.root.setOnClickListener {
                openFile(context, files.get(position))
            }
            holder.binding.checkDelete.setOnCheckedChangeListener { buttonView, isChecked ->
                if (buttonView.isPressed()) {
                    if (isChecked) {
                        list.add(position)
                    } else {
                        list.remove(position)
                    }
                }
            }
        }

        fun openFile(context: Context, url: File) {
            try {
//                val uri = Uri.fromFile(url)
                val uri =
                    FileProvider.getUriForFile(context, context.packageName + ".provider", url);
                val intent = Intent(Intent.ACTION_VIEW)
                if (url.toString().contains(".doc") || url.toString().contains(".docx")) {
                    // Word document
                    intent.setDataAndType(uri, "application/msword")
                } else if (url.toString().contains(".pdf")) {
                    // PDF file
                    intent.setDataAndType(uri, "application/pdf")
                } else if (url.toString().contains(".ppt") || url.toString().contains(".pptx")) {
                    // Powerpoint file
                    intent.setDataAndType(uri, "application/vnd.ms-powerpoint")
                } else if (url.toString().contains(".xls") || url.toString().contains(".xlsx")) {
                    // Excel file
                    intent.setDataAndType(uri, "application/vnd.ms-excel")
                } else if (url.toString().contains(".zip")) {
                    // ZIP file
                    intent.setDataAndType(uri, "application/zip")
                } else if (url.toString().contains(".rar")) {
                    // RAR file
                    intent.setDataAndType(uri, "application/x-rar-compressed")
                } else if (url.toString().contains(".rtf")) {
                    // RTF file
                    intent.setDataAndType(uri, "application/rtf")
                } else if (url.toString().contains(".wav") || url.toString().contains(".mp3")) {
                    // WAV audio file
                    intent.setDataAndType(uri, "audio/x-wav")
                } else if (url.toString().contains(".gif")) {
                    // GIF file
                    intent.setDataAndType(uri, "image/gif")
                } else if (url.toString().contains(".jpg") || url.toString()
                        .contains(".jpeg") || url.toString().contains(".png")
                ) {
                    // JPG file
                    intent.setDataAndType(uri, "image/jpeg")
                } else if (url.toString().contains(".txt")) {
                    // Text file
                    intent.setDataAndType(uri, "text/plain")
                } else if (url.toString().contains(".mkv") || url.toString().contains(".mpg") ||
                    url.toString().contains(".mpeg") || url.toString()
                        .contains(".mpe") || url.toString().contains(".mp4") || url.toString()
                        .contains(".avi")
                ) {
                    // Video files
                    intent.setDataAndType(uri, "video/*")
                } else {
                    intent.setDataAndType(uri, "*/*")
                }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                context.startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(
                    context,
                    "No application found which can open the file",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onBackPressed() {
        Utility.GotoBack(this)
    }
}