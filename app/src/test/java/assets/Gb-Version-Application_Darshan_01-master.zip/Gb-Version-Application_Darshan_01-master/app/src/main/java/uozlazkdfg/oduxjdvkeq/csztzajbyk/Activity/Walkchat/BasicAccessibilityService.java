package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Walkchat;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class BasicAccessibilityService extends AccessibilityService {
    public static Context context;
    public static View view;
    private final AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
    LayoutInflater layoutInflater;
    private WindowManager.LayoutParams layoutParams;
    ActivityManager objActivityMang;
    private View view1;
    private WindowManager windowManager;

    @SuppressLint("WrongConstant")
    public void onServiceConnected() {
        this.windowManager = (WindowManager) getApplicationContext().getSystemService("window");
        this.accessibilityServiceInfo.eventTypes = -1;
        this.accessibilityServiceInfo.feedbackType = 16;
        this.accessibilityServiceInfo.notificationTimeout = 100;
        setServiceInfo(this.accessibilityServiceInfo);
        context = this;
        this.objActivityMang = (ActivityManager) getApplicationContext().getSystemService("activity");
        LayoutInflater layoutInflater2 = (LayoutInflater) getBaseContext().getSystemService("layout_inflater");
        this.layoutInflater = layoutInflater2;
        this.view1 = layoutInflater2.inflate(R.layout.service_transnlat_text, (ViewGroup) null);
        this.layoutParams.x = 0;
        this.layoutParams.y = 0;
        AccessibilityServiceInfo accessibilityServiceInfo2 = new AccessibilityServiceInfo();
        accessibilityServiceInfo2.eventTypes = 32;
        accessibilityServiceInfo2.feedbackType = 16;
        accessibilityServiceInfo2.flags = 2;
        setServiceInfo(accessibilityServiceInfo2);

    }

    private ActivityInfo m18198a(ComponentName componentName) {
        try {
            return getPackageManager().getActivityInfo(componentName, 0);
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    @SuppressLint("WrongConstant")
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        try {
            if (accessibilityEvent.getEventType() == 32 && accessibilityEvent.getPackageName() != null && accessibilityEvent.getClassName() != null) {
                ComponentName componentName = new ComponentName(accessibilityEvent.getPackageName().toString(), accessibilityEvent.getClassName().toString());
                if ((m18198a(componentName) != null ? 1 : null) != null) {
                    if (componentName.getPackageName().equals("com.whatsapp")) {
                        if (WalkChatActivity.isWalk) {
                            View methOverlayCheck = CameraOverlay.methOverlayCheck(this);
                            view = methOverlayCheck;
                            if (methOverlayCheck != null) {
                                methOverlayCheck.setAlpha(0.5f);
                            }
                        }
                    } else if (view != null) {
                        CameraOverlay.methWinManager();
                    }
                }
            }
        } catch (Exception unused) {
        }
    }

    public void onInterrupt() {
        Log.e("Service", "Interupted");
    }
}
