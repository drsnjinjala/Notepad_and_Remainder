package com.id.caller.Activity.Theme

import android.content.Intent
import android.os.Bundle
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.util.TinyDB
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Theme.LanguageActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityThemeBinding

class ThemeActivity : BaseActivity() {
    private var isLightMode = true

    lateinit var binding: ActivityThemeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThemeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (TinyDB(this@ThemeActivity).getInt("theme", 1) == 2) {
            this.isLightMode = false
            binding.selectDark.setImageResource(R.drawable.ic_select)
            binding.selectLight.setImageResource(R.drawable.ic_no_select)
        } else {
            this.isLightMode = true
            binding.selectLight.setImageResource(R.drawable.ic_select)
            binding.selectDark.setImageResource(R.drawable.ic_no_select)
        }
        binding.lnLight.setOnClickListener {
            isLightMode = true
            binding.txtDark.setTextColor(getColor(R.color.gnt_black))
            binding.txtLight.setTextColor(getColor(R.color.gnt_black))
            binding.txtname.setTextColor(getColor(R.color.gnt_black))
            binding.bgMain.setBackgroundColor(getColor(R.color.gnt_white))
            binding.selectLight.setImageResource(R.drawable.ic_select)
            binding.selectDark.setImageResource(R.drawable.ic_no_select)
        }

        binding.lnDark.setOnClickListener {
            isLightMode = false
            binding.txtLight.setTextColor(getColor(R.color.gnt_white))
            binding.txtname.setTextColor(getColor(R.color.gnt_white))
            binding.bgMain.setBackgroundColor(getColor(R.color.gnt_black))
            binding.txtDark.setTextColor(getColor(R.color.gnt_white))
            binding.selectDark.setImageResource(R.drawable.ic_select)
            binding.selectLight.setImageResource(R.drawable.ic_no_select)
        }

        binding.btnApply.setOnClickListener {
            if (isLightMode) {
                TinyDB(this@ThemeActivity).putInt("theme", 1)
            } else {
                TinyDB(this@ThemeActivity).putInt("theme", 2)
            }
            themeToggleMode()
            if (!intent.getBooleanExtra("fromSetting", false)) {
                APIManager.showInter(this@ThemeActivity, false, object : AdsCallback {
                    override fun onClose(isfail: Boolean) {
                        Intent(this@ThemeActivity, LanguageActivity::class.java).apply {
                            putExtra("fromSetting", false)
                            startActivity(this)
                            finish()
                        }
                    }
                })
            } else {
                finish()
            }
        }
    }

    override fun onBackPressed() {
        finish()
    }

}