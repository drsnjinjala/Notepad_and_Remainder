package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.VideoView;

import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.Facing;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity; 
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class VideoCallActivity extends BaseActivity {

    private VideoView videocall;
    private CameraView camera;
    private ImageView callend;
    private LinearLayout linear;
    private LinearLayout flip;
    private LinearLayout audioBtn;
    private LinearLayout videoBtn;
    String VideoUri;
    Uri videosurl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_call);
        initView();
        camera.start();
        camera.setFacing(Facing.FRONT);
        VideoUri = getIntent().getStringExtra("videocalluri");
        videosurl = Uri.parse(VideoUri);
        videocall.setVideoURI(videosurl);
        videocall.start();
        callend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videocall.stopPlayback();
                onBackPressed();
            }
        });
    }

    private void initView() {
        videocall = findViewById(R.id.videocall);
        camera = findViewById(R.id.camera);
        callend = findViewById(R.id.callend);
        linear = findViewById(R.id.linear);
        flip = findViewById(R.id.flip);
        audioBtn = findViewById(R.id.audioBtn);
        videoBtn = findViewById(R.id.videoBtn);
    }
    //status

    @Override
    protected void onResume() {
        super.onResume();
        videocall.resume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        videocall.stopPlayback();
    }

    @Override
    public void onBackPressed() {
        videocall.stopPlayback();

        Utility.GotoBack(this);
    }
}