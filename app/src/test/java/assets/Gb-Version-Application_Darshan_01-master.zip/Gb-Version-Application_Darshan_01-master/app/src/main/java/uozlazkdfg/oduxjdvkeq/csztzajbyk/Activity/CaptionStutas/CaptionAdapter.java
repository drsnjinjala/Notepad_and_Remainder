package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.CaptionStutas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class CaptionAdapter extends RecyclerView.Adapter<CaptionAdapter.Myclass> {

    private Context context;
    private String[] logos;
    Callback callback;

    public interface Callback {
        void onItemClick(int pos);
    }

    public CaptionAdapter(Context context, String[] logos, Callback callback) {
        this.context = context;
        this.logos = logos;
        this.callback = callback;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.gridview, parent, false);
        Myclass myclass = new Myclass(inflate);
        return myclass;
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
        holder.name.setText(logos[position]);
        holder.itemView.setOnClickListener(v -> {
            callback.onItemClick(position);
        });
    }

    @Override
    public int getItemCount() {
        return logos.length;
    }

    public class Myclass extends RecyclerView.ViewHolder {
        private TextView name;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.name);
        }
    }
}
