package uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.download;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;

import androidx.documentfile.provider.DocumentFile;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.circularreveal.CircularRevealRelativeLayout;
import com.google.android.material.textview.MaterialTextView;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class DocCopyMoveDialog {

    private static MaterialTextView progressPercentages;
    private static MaterialTextView totalFiles;
    private static ProgressBar progressBar;

    public static void show(Activity context, File srcFile, File descFile, List<DocumentFile> fileList, boolean isMove, Callback callback) {
        BottomSheetDialog mBottomSheetDialog = new RoundedBottomSheetDialog(context);
        View view = LayoutInflater.from(context).inflate(R.layout.layout_dialog_copy_move, null);
        mBottomSheetDialog.setContentView(view);
        mBottomSheetDialog.setCancelable(false);

        MaterialTextView dialogTitle = (MaterialTextView) view.findViewById(R.id.dialog_title);
        CircularRevealRelativeLayout frame = (CircularRevealRelativeLayout) view.findViewById(R.id.frame);
        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar);
        progressPercentages = (MaterialTextView) view.findViewById(R.id.progress_percentages);
        totalFiles = (MaterialTextView) view.findViewById(R.id.total_files);

        if (isMove) dialogTitle.setText("Moving file..");
        else dialogTitle.setText("Coping file..");

        MoveFilesTask moveFilesTask = new MoveFilesTask(context, fileList, descFile, isMove, callback, mBottomSheetDialog);
        moveFilesTask.execute();

        mBottomSheetDialog.getWindow().setDimAmount(0);
        mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (!context.isFinishing()) {
            mBottomSheetDialog.show();
        }
    }

    public static void setProgress(int i) {
        progressBar.setProgress(i);
        progressPercentages.setText(i + "/" + 100);
    }

    public static void setFilesProgress(int i, int fileCount, int listSize) {
        progressBar.setProgress(i);
        progressPercentages.setText(i + "/" + 100);
        totalFiles.setText(fileCount + "/" + listSize);
    }

    public interface Callback {
        void onComplete(boolean isComplete);
    }

    static class MoveFilesTask extends AsyncTask<Boolean, String, Boolean> {

        private final BottomSheetDialog bottomSheetDialog;
        private Activity activity;
        private List<DocumentFile> fileList;
        private File destFile;
        private boolean isMove;
        private int fileCount = 0;
        private Callback callback;

        public MoveFilesTask(Activity activity, List<DocumentFile> fileList, File destFile, boolean isMove, Callback callback, BottomSheetDialog bottomSheetDialog) {
            this.activity = activity;
            this.fileList = fileList;
            this.destFile = destFile;
            this.isMove = isMove;
            this.callback = callback;
            this.bottomSheetDialog = bottomSheetDialog;
        }

        public boolean createOrExistsFile(File file) {
            if (file == null) return false;
            // 如果存在，是文件则返回true，是目录则返回false
            if (file.exists()) return file.isFile();
            try {
                file.getParentFile().mkdirs();
                return file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Boolean doInBackground(Boolean... voids) {
            for (int i = 0; i < fileList.size(); i++) {
                fileCount = i + 1;
                DocumentFile srcFile = fileList.get(i);
                if (srcFile == null || new File(destFile + "/" + srcFile.getName()) == null)
                    return false;
                if (!srcFile.exists() || !srcFile.isFile()) return false;
                if (new File(destFile + "/" + srcFile.getName()).exists() && new File(destFile + "/" + srcFile.getName()).isFile())
                    return false;
                try {
                    InputStream is = activity.getContentResolver().openInputStream(srcFile.getUri());
                    if (new File(destFile + "/" + srcFile.getName()) == null || is == null)
                        return false;
                    if (!createOrExistsFile(new File(destFile + "/" + srcFile.getName())))
                        return false;
                    OutputStream os = null;
                    try {
                        os = new BufferedOutputStream(new FileOutputStream(new File(destFile + "/" + srcFile.getName()), false));
                        byte[] data = new byte[1024];
                        int len;
                        long fileLength = srcFile.length();
                        long total = 0;
                        while ((len = is.read(data, 0, 1024)) != -1) {
                            total += len;
                            publishProgress("" + (int) ((total * 100) / fileLength));
                            os.write(data, 0, len);
                        }
                        os.flush();
                        os.close();
                        is.close();

                        if (fileList.size() == fileCount)
                            return true;
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.e("IOException", ": " + e);
                        return false;
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                    }
                } catch (FileNotFoundException e) {
                    Log.e("FileNotFoundException", ": " + e);
                    e.printStackTrace();
                    return false;
                }
            }
            return false;
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            setFilesProgress(Integer.parseInt(progress[0]), fileCount, fileList.size());
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            bottomSheetDialog.dismiss();
            if (callback != null) {
                callback.onComplete(aBoolean);
            }
        }
    }
}