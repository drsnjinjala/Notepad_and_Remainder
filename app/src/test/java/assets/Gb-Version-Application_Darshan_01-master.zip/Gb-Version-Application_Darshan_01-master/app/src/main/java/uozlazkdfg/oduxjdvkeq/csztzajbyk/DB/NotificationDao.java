package uozlazkdfg.oduxjdvkeq.csztzajbyk.DB;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NotificationDao {

    @Query("SELECT * FROM Notification_List")
    List<NotificationModel> getAll();

    @Insert
    void insert(NotificationModel notificationModel);

    @Delete
    void delete(NotificationModel notificationModel);

    @Update
    void update(NotificationModel notificationModel);

    @Query("SELECT * FROM Notification_List WHERE title = :userName")
    boolean isDataExist(String userName);


    @Query("SELECT * FROM Notification_List ORDER BY time DESC LIMIT 1")
    NotificationModel getLastEntry();

    @Query("SELECT * FROM Notification_List ORDER BY 1 DESC LIMIT 1")
    NotificationModel getLastMgs();

    @Query("SELECT * FROM Notification_List WHERE notification_id = :id ORDER BY text DESC LIMIT 1")
    NotificationModel getLastEntryById(int id);


    @Query("UPDATE Notification_List SET mgs_list=:text WHERE notification_id = :id")
    void update(String text, int id);


}