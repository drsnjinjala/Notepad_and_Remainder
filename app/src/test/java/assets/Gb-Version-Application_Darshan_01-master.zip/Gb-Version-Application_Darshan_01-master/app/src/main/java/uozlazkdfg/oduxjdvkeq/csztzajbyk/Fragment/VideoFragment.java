package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;


import static com.otaliastudios.cameraview.CameraView.PERMISSION_REQUEST_CODE;
import static uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.SutasSaverFragment.documentFiles;
import static uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.SutasSaverFragment.rootDocumentVideo;
import static uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.GetFile.rootVideo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.yalantis.ucrop.util.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.MainActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.StatusVideoAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.FragmentVideoStutasBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.GetFile;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.download.DocCopyMoveDialog;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.helper.PreferenceManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.ActivityKt;


public class VideoFragment extends Fragment {
    FragmentVideoStutasBinding binding;
    GridLayoutManager gridLayoutManager;
    GetFile getFile;
    String TAG = "Video Fragmenet";

    private StatusVideoAdapter statusAdapter;

    int po = 0;
    public ArrayList listVideo = new ArrayList();
    String path;
    public static VideoView videoView;
    String str;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentVideoStutasBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        binding.playerimage.setVisibility(View.GONE);
        videoView
                = view.findViewById(R.id.videoView1);
        setAdapter();
        initView();
        if (PreferenceManager.getInstance().getBoolean("isPermissionGranted", false)) {
            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(PreferenceManager.getInstance().getString("document_uri")));
            documentFiles = fromTreeUri.listFiles();
            for (DocumentFile documentFile : documentFiles) {
                if (documentFile.getName().endsWith(".mp4") || documentFile.getName().endsWith(".mkv") || documentFile.getName().endsWith(".gif")) {
                    rootVideo.add(documentFile.getUri());
                    rootDocumentVideo.add(documentFile);
                    listVideo.add(documentFile.getUri());
                }
            }

            statusAdapter.UpData(listVideo);
            statusAdapter.notifyDataSetChanged();
            if (!(GetFile.rootVideo.size() == 0)) {
                path = getFile.rootVideo.get(0).toString();
                Glide.with(this).load(getFile.rootVideo.get(0)).centerCrop().placeholder(R.color.black).into(binding.ImageView);
            } else {
                binding.tv404.setVisibility(View.VISIBLE);
                binding.otherContaint.setVisibility(View.GONE);
            }

        }

        return view;
    }

    private void setAdapter() {

        binding.videoPlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        getFile = new GetFile();
        binding.recView.setLayoutManager(new LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false));
        statusAdapter = new StatusVideoAdapter(requireActivity(), (position, list) -> {
            po = position;

            //  Glide.with(this).load(getFile.rootVideo.get(position)).centerCrop().placeholder(R.color.black).into(binding.ImageView);

            MediaController mediaController = new MediaController(getActivity());
            mediaController.setAnchorView(videoView);
            Uri uri = Uri.parse(getFile.rootVideo.get(po).toString());
            //Setting MediaController and URI, then starting the videoView
            videoView.setMediaController(mediaController);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
            videoView.seekTo(15);
            videoView.resume();
        });

        if (!(getFile.rootVideo.size() == 0)) {
            path = getFile.rootVideo.get(0).toString();
            Glide.with(this).load(getFile.rootVideo.get(0)).centerCrop().placeholder(R.color.black).into(binding.ImageView);
        }/* else {
            binding.tv404.setVisibility(View.VISIBLE);
            binding.otherContaint.setVisibility(View.GONE);
        }*/
        binding.recView.setAdapter(statusAdapter);
    }

    private void initView() {
        binding.btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkPermission()) {
                    String root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
                    File file = new File(root + "/" + getResources().getString(R.string.app_name) + "/" + "Whatsapp" + "/" + "Video");
                    if (!file.exists()) {
                        file.mkdirs();
                    }
                    path = getFile.rootVideo.get(po).toString();
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                        // s
                        String root2 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "/" + getActivity().getResources().getString(R.string.app_name) + "/Whatsapp/Video/";
                        ArrayList<DocumentFile> documentFileArrayList = new ArrayList<>();
                        documentFileArrayList.add(rootDocumentVideo.get(po));
                        Log.d("~~~", "path  : " + new File(root2).toString() + "\n" + documentFileArrayList.toString());
                        DocCopyMoveDialog.show(getActivity(), null, new File(root2), documentFileArrayList, false, new DocCopyMoveDialog.Callback() {
                            @Override
                            public void onComplete(boolean isComplete) {
                                Log.d("TAG", "onComplete: ");
                            }
                        });
                        Toast.makeText(getActivity(), "Download", Toast.LENGTH_SHORT).show();

                    } else {

                        if (path.endsWith(".mp4") || path.endsWith(".gif") || path.endsWith(".mkv")) {
                            File file1 = new File(getFile.rootVideo.get(po).toString());
                            if (!file.exists()) {
                                file.mkdir();
                            }
                            int number = new Random().nextInt(10000);
                            int number2 = new Random().nextInt(20000);
                            str = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/" + getActivity().getResources().getString(R.string.app_name) + "/Whatsapp/Videos/" + ("Video" + number + number2 + ".mp4");
                            Log.d("~~~", "str  :" + str);
                            File file2 = new File(str);

                            try {
                                FileUtils.copyFile(file1.toString(), file2.toString());
                                Toast.makeText(getActivity(), "Download", Toast.LENGTH_SHORT).show();

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                } else requestPermission();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
//        listVideo.clear();
//        setAdapter();
//        initView();
//        if (PreferenceManager.getInstance().getBoolean("isPermissionGranted", false)) {
//            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(PreferenceManager.getInstance().getString("document_uri")));
//            documentFiles = fromTreeUri.listFiles();
//            for (DocumentFile documentFile : documentFiles) {
//                if (documentFile.getName().endsWith(".mp4") || documentFile.getName().endsWith(".mkv") || documentFile.getName().endsWith(".gif")) {
//                    //    rootVideo.add(documentFile.getUri());
//                    listVideo.add(documentFile.getUri());
//                    //    rootDocumentVideo.add(documentFile);
//                }
//            }
//        }
//        // listVideo = GetFile.rootVideo;
//        statusAdapter.UpData(listVideo);
//        statusAdapter.notifyDataSetChanged();
//        if (!(GetFile.rootVideo.size() == 0)) {
//            path = getFile.rootVideo.get(0).toString();
//            Glide.with(this).load(getFile.rootVideo.get(0)).centerCrop().placeholder(R.color.black).into(binding.ImageView);
//        } else {
//            binding.tv404.setVisibility(View.VISIBLE);
//            binding.otherContaint.setVisibility(View.GONE);
//        }
    }

    @Override
    public void setMenuVisibility(boolean menuVisible) {
        super.setMenuVisibility(menuVisible);
        if (menuVisible) {
            if (videoView.isPlaying()) videoView.pause();
        } else if (!(videoView == null)) {
            if (videoView.isPlaying())
                videoView.pause();
        }
        Log.d("~~~", "setMenuVisibility: Video Fragmenet");
    }


    @Override
    public void onPause() {
        Log.d(TAG, "onPause() called");
        if (videoView.isPlaying()) {
            videoView.pause();
        }
        super.onPause();

    }

    private boolean checkPermission() {
//        int result = ContextCompat.checkSelfPermission(getActivity(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
//        if (result == PackageManager.PERMISSION_GRANTED) {
//            return true;
//        } else {
            return ActivityKt.hasPermissions(requireActivity());
//        }
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
        } else {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
        }

//        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
//            Toast.makeText(getActivity(), "Write External Storage permission allows us to do store images. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
//        } else {
//            ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
//        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("value", "Permission Granted, Now you can use local drive .");
                } else {
                    Log.e("value", "Permission Denied, You cannot use local drive .");
                }
                break;
        }
    }



    public static void stopVideoPlaye() {
        if (!(videoView == null)) {
            if (videoView.isPlaying())
                videoView.pause();
        }
//        else Toast.makeText(getActivity(), "else condition check ", Toast.LENGTH_SHORT).show();
    }
}