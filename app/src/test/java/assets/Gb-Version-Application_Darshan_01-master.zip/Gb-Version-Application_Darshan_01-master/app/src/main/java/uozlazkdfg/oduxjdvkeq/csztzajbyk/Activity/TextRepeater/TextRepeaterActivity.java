package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.TextRepeater;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;


import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityTextRepeaterBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class TextRepeaterActivity extends BaseActivity {
    String RepeatText;
    String Maintext;
    String no;
    int NoofRepeat;
    boolean isNewLine = false;
    ProgressDialog pDialog;
    ActivityTextRepeaterBinding binding;


    private class btnConverListner implements View.OnClickListener {
        private btnConverListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            binding.convertedEmojeeTxt.setText("");
            TextRepeaterActivity TextRepeaterActivity = TextRepeaterActivity.this;
            TextRepeaterActivity.RepeatText = binding.inputText.getText().toString();
            TextRepeaterActivity TextRepeaterActivity2 = TextRepeaterActivity.this;
            TextRepeaterActivity2.no = binding.emojeeTxt.getText().toString();
            try {
                NoofRepeat = Integer.parseInt(no);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            if (binding.inputText.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Enter Repeat Text", 0).show();
            } else if (binding.emojeeTxt.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Enter Number of Repeat Text", 0).show();
            } else if (NoofRepeat <= 10000) {
                new CreateRepeateText().execute(new String[0]);
            } else {
                Toast.makeText(getApplicationContext(), "Number of Repeter Text Limited Please Enter Limited Number", 0).show();
            }
        }
    }

    private class btnClearTextListner implements View.OnClickListener {
        private btnClearTextListner() {
        }

        public void onClick(View view) {
            binding.convertedEmojeeTxt.setText("");
        }
    }

    private class btnConvertedTexListner implements View.OnClickListener {
        private btnConvertedTexListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (!binding.convertedEmojeeTxt.getText().toString().isEmpty()) {
            }
        }
    }

    private class btnCopyListner implements View.OnClickListener {
        private btnCopyListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (binding.convertedEmojeeTxt.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Convert text before copy", 0).show();
                return;
            }
            ((ClipboardManager) getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(binding.inputText.getText().toString(), binding.convertedEmojeeTxt.getText().toString()));
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.copyline), 0).show();
        }
    }

    private class btnShareListner implements View.OnClickListener {
        private btnShareListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (binding.convertedEmojeeTxt.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please Convert text to share", 1).show();
                return;
            }

            try {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.putExtra("android.intent.extra.TEXT", binding.convertedEmojeeTxt.getText().toString());
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "Select an app to share"));

            } catch (Exception e) {
                Toast.makeText(TextRepeaterActivity.this, "Whatsapp have not been installed", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private class CreateRepeateText extends AsyncTask<String, Void, String> {
        private CreateRepeateText() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            pDialog.setMessage("Please Wait...");
            pDialog.setProgressStyle(0);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        public String doInBackground(String... strArr) {
            if (isNewLine) {
                for (int i = 1; i <= NoofRepeat; i++) {
                    if (i == 1) {
                        TextRepeaterActivity TextRepeaterActivity = TextRepeaterActivity.this;
                        TextRepeaterActivity.Maintext = TextRepeaterActivity.RepeatText;
                    } else {
                        StringBuilder sb = new StringBuilder();
                        TextRepeaterActivity TextRepeaterActivity2 = TextRepeaterActivity.this;
                        sb.append(TextRepeaterActivity2.Maintext);
                        sb.append(IOUtils.LINE_SEPARATOR_UNIX);
                        sb.append(RepeatText);
                        TextRepeaterActivity2.Maintext = sb.toString();
                    }
                }
                return null;
            }
            for (int i2 = 1; i2 <= NoofRepeat; i2++) {
                if (i2 == 1) {
                    TextRepeaterActivity TextRepeaterActivity3 = TextRepeaterActivity.this;
                    TextRepeaterActivity3.Maintext = TextRepeaterActivity3.RepeatText;
                } else {
                    StringBuilder sb2 = new StringBuilder();
                    TextRepeaterActivity TextRepeaterActivity4 = TextRepeaterActivity.this;
                    sb2.append(TextRepeaterActivity4.Maintext);
                    sb2.append("\t");
                    sb2.append(RepeatText);
                    TextRepeaterActivity4.Maintext = sb2.toString();
                }
            }
            return null;
        }

        public void onPostExecute(String str) {
            pDialog.dismiss();
            binding.convertedEmojeeTxt.setText(Maintext);
            hideKeyboard();
        }
    }

    public void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = getCurrentFocus();
        if (view == null) {
            view = new View(this);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private class newLineClick implements View.OnClickListener {
        private newLineClick() {
        }

        public void onClick(View view) {
            if (isNewLine) {
                isNewLine = false;
                binding.txtNewLine.setText(getResources().getString(R.string.newlineoff));
                binding.btnWalk.setImageResource(R.drawable.ic_switch_off);
                return;
            }
            isNewLine = true;
            binding.txtNewLine.setText("New Line On");
            binding.btnWalk.setImageResource(R.drawable.ic_switch_on);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setLightTheme(true);
        binding = ActivityTextRepeaterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initView();

        APIManager.showSmallNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);

        this.pDialog = new ProgressDialog(this);
        if (this.isNewLine) {
            binding.txtNewLine.setText(getResources().getString(R.string.newlineon));
            binding.btnWalk.setImageResource(R.drawable.ic_switch_on);
        } else {
            binding.txtNewLine.setText(getResources().getString(R.string.newlineoff));
            binding.btnWalk.setImageResource(R.drawable.ic_switch_off);
        }
        binding.btnWalk.setOnClickListener(new newLineClick());

        binding.convertEmojeeBtn.setOnClickListener(new btnConverListner());
        binding.clearTxtBtn.setOnClickListener(new btnClearTextListner());
        binding.convertedEmojeeTxt.setOnClickListener(new btnConvertedTexListner());
        binding.copyTxtBtn.setOnClickListener(new btnCopyListner());
        binding.shareTxtBtn.setOnClickListener(new btnShareListner());
    }

    private void initView() {

        binding.back.setOnClickListener(view -> onBackPressed());
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}