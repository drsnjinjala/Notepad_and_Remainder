package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class AngryRecycerAdaptersGallery extends RecyclerView.Adapter<AngryRecycerAdaptersGallery.MyViewHolder> {
    public String[] AngryAscii;
    public Context context;

    class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView Share;
        TextView TextFaces;
        ImageView WhatsApp, bisinesswhats;
        LinearLayout whatsapplinear, Bwhatsapplinear, sharelinear;

        MyViewHolder(View view) {
            super(view);
            this.TextFaces = (TextView) view.findViewById(R.id.txt);
            this.WhatsApp = (ImageView) view.findViewById(R.id.whats);
            this.Share = (ImageView) view.findViewById(R.id.share);
            this.bisinesswhats = (ImageView) view.findViewById(R.id.bisinesswhats);
            this.whatsapplinear = (LinearLayout) view.findViewById(R.id.whatsapplinear);
            this.Bwhatsapplinear = (LinearLayout) view.findViewById(R.id.Bwhatsapplinear);
            this.sharelinear = (LinearLayout) view.findViewById(R.id.sharelinear);
        }
    }

    public AngryRecycerAdaptersGallery(FragmentActivity fragmentActivity, String[] strArr) {
        this.context = fragmentActivity;
        this.AngryAscii = strArr;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_listfacis, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {


        try {

            myViewHolder.whatsapplinear.setVisibility(View.VISIBLE);
            myViewHolder.Bwhatsapplinear.setVisibility(View.VISIBLE);

            myViewHolder.whatsapplinear.setVisibility(View.VISIBLE);

            myViewHolder.whatsapplinear.setVisibility(View.GONE);
            myViewHolder.Bwhatsapplinear.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            Toast.makeText(context, "Whatsapp have not been installed", Toast.LENGTH_SHORT).show();
        }


        myViewHolder.TextFaces.setText(this.AngryAscii[i]);
        myViewHolder.WhatsApp.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = AngryRecycerAdaptersGallery.this.AngryAscii[i];
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", str);
                try {
                    AngryRecycerAdaptersGallery.this.context.startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(AngryRecycerAdaptersGallery.this.context, "Whatsapp have not been installed.", 0).show();
                }
            }
        });

        myViewHolder.bisinesswhats.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = AngryRecycerAdaptersGallery.this.AngryAscii[i];
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", str);
                try {
                    AngryRecycerAdaptersGallery.this.context.startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(AngryRecycerAdaptersGallery.this.context, "Whatsapp have not been installed.", 0).show();
                }
            }
        });

        myViewHolder.Share.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = AngryRecycerAdaptersGallery.this.AngryAscii[i];
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", str);
                try {
                    AngryRecycerAdaptersGallery.this.context.startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(AngryRecycerAdaptersGallery.this.context, "Some problems", 0).show();
                }
            }
        });
    }

    public int getItemCount() {
        String[] strArr = this.AngryAscii;
        if (strArr == null) {
            return 0;
        }
        return strArr.length;
    }

    private boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }
}
