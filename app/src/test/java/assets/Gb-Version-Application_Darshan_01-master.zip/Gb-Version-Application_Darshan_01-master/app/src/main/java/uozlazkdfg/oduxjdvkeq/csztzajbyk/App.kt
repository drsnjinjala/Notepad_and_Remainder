package uozlazkdfg.oduxjdvkeq.csztzajbyk

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.viewbinding.BuildConfig
import think.outside.the.box.AppClass
import think.outside.the.box.handler.APIManager
import think.outside.the.box.handler.APIManager.isLog
import think.outside.the.box.util.TinyDB
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.SplashActivity
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.BaseApp

class App : AppClass() {
    override fun onCreate() {
        super.onCreate()
        themeToggleMode()
        val langCode = TinyDB(this).getString("langCode")
        BaseActivity.setLocale(this, langCode)
        context = applicationContext

        if (uozlazkdfg.oduxjdvkeq.csztzajbyk.BuildConfig.DEBUG) {
            APIManager.isLog = true
        }
        setClass(SplashActivity::class.java)
//        APIManager.setAppName("test")
        APIManager.setAppName("216_gb_version")
    }

    companion object {
        var context: Context? = null
    }

    fun themeToggleMode() {
//        if (TinyDB(this).getInt("theme", 1) == 1) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//        } else {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//        }
    }
}