package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.viewpager.widget.PagerAdapter
import think.outside.the.box.callback.AdsCallback
import think.outside.the.box.handler.APIManager
import think.outside.the.box.util.TinyDB
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityIntroBinding

class IntroActivity : BaseActivity() {
    private lateinit var binding: ActivityIntroBinding
    private var myViewPagerAdapter: MyViewPagerAdapter? = null
    private var layouts: IntArray = intArrayOf(R.layout.intro1a, R.layout.intro2b, R.layout.intro3c)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        transparentStatusBar()
        binding = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        APIManager.showTopSmallNative(binding.adContainer)
        myViewPagerAdapter = MyViewPagerAdapter()
        binding.viewpager.adapter = myViewPagerAdapter
        binding.indicator.setViewPager(binding.viewpager)
        binding.btnNext.setOnClickListener { v: View? ->
            val current = getItem(+1)
            if (current < layouts.size) {
                binding.viewpager.currentItem = current
                if (binding.viewpager.currentItem==2){
                    APIManager.showInter(this@IntroActivity, false, object : AdsCallback {
                        override fun onClose(isfail: Boolean) {
                        }
                    })
                }
            } else {
                launchHomeScreen()
            }
        }
    }

    private fun getItem(i: Int): Int {
        return binding.viewpager.currentItem + i
    }

    private fun launchHomeScreen() {
        TinyDB(this@IntroActivity).putBoolean("AppOpenFirst", true)
        startActivity(Intent(this@IntroActivity, PermissionActivity::class.java))
        finish()
//        APIManager.showInter(this@IntroActivity, false, object : AdsCallback {
//            override fun onClose(isfail: Boolean) {
//
//            }
//        })
    }

    inner class MyViewPagerAdapter : PagerAdapter() {
        private lateinit var layoutInflater: LayoutInflater
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val view = layoutInflater.inflate(layouts[position], container, false)
            container.addView(view)
            return view
        }

        override fun getCount(): Int {
            return layouts.size
        }

        override fun isViewFromObject(view: View, obj: Any): Boolean {
            return view === obj
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            val view = `object` as View
            container.removeView(view)
        }
    }

    override fun onBackPressed() {
        finish()
    }
    fun transparentStatusBar() {
        val window = window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
        }
        window.statusBarColor = Color.TRANSPARENT
    }
}