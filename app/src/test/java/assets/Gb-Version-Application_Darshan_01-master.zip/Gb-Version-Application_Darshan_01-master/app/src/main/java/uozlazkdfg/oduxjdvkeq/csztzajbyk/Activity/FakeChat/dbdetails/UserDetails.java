package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails;

public class UserDetails {
    private byte[] bytes;
    private int uid;
    private String uname;
    private String uonline;
    private String ustatus;
    private String utyping;

    public int getUid() {
        return this.uid;
    }

    public void setUid(int i) {
        this.uid = i;
    }

    public String getUname() {
        return this.uname;
    }

    public void setUname(String str) {
        this.uname = str;
    }

    public String getUtyping() {
        return this.utyping;
    }

    public void setUtyping(String str) {
        this.utyping = str;
    }

    public String getUonline() {
        return this.uonline;
    }

    public void setUonline(String str) {
        this.uonline = str;
    }

    public byte[] getBytes() {
        return this.bytes;
    }

    public void setBytes(byte[] bArr) {
        this.bytes = bArr;
    }

    public String getUstatus() {
        return this.ustatus;
    }

    public void setUstatus(String str) {
        this.ustatus = str;
    }
}
