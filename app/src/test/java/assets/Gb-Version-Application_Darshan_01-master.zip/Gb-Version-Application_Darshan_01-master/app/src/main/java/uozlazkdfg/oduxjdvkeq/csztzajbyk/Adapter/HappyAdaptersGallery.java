package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class HappyAdaptersGallery extends RecyclerView.Adapter<HappyAdaptersGallery.MyViewHolder> {
    /* access modifiers changed from: private */
    public String[] HappyAscii;
    /* access modifiers changed from: private */
    public Context context;

    class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView Share;
        TextView TextFaces;
        ImageView WhatsApp, bisinesswhats;
        LinearLayout whatsapplinear, Bwhatsapplinear, sharelinear;


        MyViewHolder(View view) {
            super(view);
            this.TextFaces = (TextView) view.findViewById(R.id.txt);
            this.WhatsApp = (ImageView) view.findViewById(R.id.whats);
//            Blurry day
            this.Share = (ImageView) view.findViewById(R.id.share);
            this.bisinesswhats = (ImageView) view.findViewById(R.id.bisinesswhats);
            this.whatsapplinear = (LinearLayout) view.findViewById(R.id.whatsapplinear);
            this.Bwhatsapplinear = (LinearLayout) view.findViewById(R.id.Bwhatsapplinear);
            this.sharelinear = (LinearLayout) view.findViewById(R.id.sharelinear);

        }
    }

    public HappyAdaptersGallery(FragmentActivity fragmentActivity, String[] strArr) {
        this.context = fragmentActivity;
        this.HappyAscii = strArr;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_listfacis, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {


        myViewHolder.whatsapplinear.setVisibility(View.VISIBLE);
        myViewHolder.Bwhatsapplinear.setVisibility(View.VISIBLE);


        myViewHolder.whatsapplinear.setVisibility(View.VISIBLE);
        myViewHolder.Bwhatsapplinear.setVisibility(View.GONE);


        myViewHolder.whatsapplinear.setVisibility(View.GONE);
        myViewHolder.Bwhatsapplinear.setVisibility(View.VISIBLE);


        myViewHolder.TextFaces.setText(this.HappyAscii[i]);
        myViewHolder.WhatsApp.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = HappyAdaptersGallery.this.HappyAscii[i];
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", str);
                try {
                    HappyAdaptersGallery.this.context.startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(HappyAdaptersGallery.this.context, "Whatsapp have not been installed.", 0).show();
                }
            }
        });

        myViewHolder.bisinesswhats.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = HappyAdaptersGallery.this.HappyAscii[i];
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", str);
                try {
                    HappyAdaptersGallery.this.context.startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(HappyAdaptersGallery.this.context, "Whatsapp have not been installed.", 0).show();
                }
            }
        });

        myViewHolder.Share.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = HappyAdaptersGallery.this.HappyAscii[i];
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", str);
                try {
                    HappyAdaptersGallery.this.context.startActivity(intent);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(HappyAdaptersGallery.this.context, "Some problems", 0).show();
                }
            }
        });
    }

    public int getItemCount() {
        String[] strArr = this.HappyAscii;
        if (strArr == null) {
            return 0;
        }
        return strArr.length;
    }

    private boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }
}
