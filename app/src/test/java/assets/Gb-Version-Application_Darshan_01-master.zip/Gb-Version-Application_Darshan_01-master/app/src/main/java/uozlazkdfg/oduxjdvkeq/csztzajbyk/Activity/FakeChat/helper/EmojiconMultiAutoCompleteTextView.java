package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.MultiAutoCompleteTextView;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


@SuppressLint("AppCompatCustomView")
public class EmojiconMultiAutoCompleteTextView extends MultiAutoCompleteTextView {
    private int mEmojiconAlignment;
    private int mEmojiconSize;
    private int mEmojiconTextSize;
    private boolean mUseSystemDefault;

    public EmojiconMultiAutoCompleteTextView(Context context) {
        super(context);
        this.mUseSystemDefault = false;
        this.mEmojiconSize = (int) getTextSize();
        this.mEmojiconTextSize = (int) getTextSize();
    }

    public EmojiconMultiAutoCompleteTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mUseSystemDefault = false;
        init(attributeSet);
    }

    public EmojiconMultiAutoCompleteTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mUseSystemDefault = false;
        init(attributeSet);
    }

    private void init(AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.Emojicon);
        obtainStyledAttributes.recycle();
        this.mEmojiconTextSize = (int) getTextSize();
        setText(getText());
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        updateText();
    }

    public void setEmojiconSize(int i) {
        this.mEmojiconSize = i;
        updateText();
    }

    private void updateText() {
        EmojiconHandler.addEmojis(getContext(), getText(), this.mEmojiconSize, this.mEmojiconAlignment, this.mEmojiconTextSize, this.mUseSystemDefault);
    }

    public void setUseSystemDefault(boolean z) {
        this.mUseSystemDefault = z;
    }
}
