package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji;

import android.os.Parcel;
import android.os.Parcelable;

public class Emojicon implements Parcelable {
    public static final Creator<Emojicon> CREATOR = new Creator<Emojicon>() {
        public Emojicon createFromParcel(Parcel parcel) {
            return new Emojicon(parcel);
        }

        public Emojicon[] newArray(int i) {
            return new Emojicon[i];
        }
    };
    private String emoji;
    private int icon;
    private char value;

    public int describeContents() {
        return 0;
    }

    public Emojicon(int i, char c, String str) {
        this.icon = i;
        this.value = c;
        this.emoji = str;
    }

    public Emojicon(Parcel parcel) {
        this.icon = parcel.readInt();
        this.value = (char) parcel.readInt();
        this.emoji = parcel.readString();
    }

    private Emojicon() {
    }

    public Emojicon(String str) {
        this.emoji = str;
    }

    public static Emojicon fromResource(int i, int i2) {
        Emojicon emojicon = new Emojicon();
        emojicon.icon = i;
        emojicon.value = (char) i2;
        return emojicon;
    }

    public static Emojicon fromCodePoint(int i) {
        Emojicon emojicon = new Emojicon();
        emojicon.emoji = newString(i);
        return emojicon;
    }

    public static Emojicon fromChar(char c) {
        Emojicon emojicon = new Emojicon();
        emojicon.emoji = Character.toString(c);
        return emojicon;
    }

    public static Emojicon fromChars(String str) {
        Emojicon emojicon = new Emojicon();
        emojicon.emoji = str;
        return emojicon;
    }

    public static final String newString(int i) {
        if (Character.charCount(i) == 1) {
            return String.valueOf(i);
        }
        return new String(Character.toChars(i));
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.icon);
        parcel.writeInt(this.value);
        parcel.writeString(this.emoji);
    }

    public char getValue() {
        return this.value;
    }

    public int getIcon() {
        return this.icon;
    }

    public String getEmoji() {
        return this.emoji;
    }

    public boolean equals(Object obj) {
        return (obj instanceof Emojicon) && this.emoji.equals(((Emojicon) obj).emoji);
    }

    public int hashCode() {
        return this.emoji.hashCode();
    }
}
