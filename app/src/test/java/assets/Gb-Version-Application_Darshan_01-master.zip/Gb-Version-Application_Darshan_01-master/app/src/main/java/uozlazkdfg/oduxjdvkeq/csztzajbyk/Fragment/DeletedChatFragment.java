package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;

import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter.ChatListAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.DB.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.DB.NotificationModel;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Service.MyListener;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Service.MyNotificationListenerService;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.FragmentDeletedChat2Binding;

public class DeletedChatFragment extends Fragment implements MyListener {

    FragmentDeletedChat2Binding binding;
    private DatabaseHelper helper;
    ArrayList<NotificationModel> arrayList;
    ChatListAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDeletedChat2Binding.inflate(inflater, container, false);
        View view = binding.getRoot();

        helper = DatabaseHelper.getInstance(getActivity());
        new MyNotificationListenerService().setListener(this);
        arrayList = new ArrayList<>();

        String notificationListenerString = Settings.Secure.getString(getActivity().getContentResolver(), "enabled_notification_listeners");
        String packageName = getActivity().getPackageName();
        boolean isNotificationListenerEnabled = (notificationListenerString != null && notificationListenerString.contains(packageName));

        /*    if (!isNotificationListenerEnabled) {
            Intent requestIntent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            startActivity(requestIntent);
        }*/
        APIManager.showSmallNative(binding.adContainerSmallNative);

        arrayList = (ArrayList<NotificationModel>) helper.notificationDao().getAll();
        ArrayList<NotificationModel> uniqueList = new ArrayList<NotificationModel>();

        for (int i = 0; i < arrayList.size(); i++) {
            NotificationModel currentModel = arrayList.get(i);
            boolean isDuplicate = false;
            for (int j = 0; j < uniqueList.size(); j++) {
                NotificationModel uniqueModel = uniqueList.get(j);
                if (currentModel.getTitle().equals(uniqueModel.getTitle())) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) {
                uniqueList.add(currentModel);
            }
        }
        adapter = new ChatListAdapter(uniqueList, getActivity());
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.recyclerView.setAdapter(adapter);
        if (!(uniqueList.size() == 0)) {
            binding.dataNotfound.setVisibility(View.GONE);
        }
        return view;
    }


    @Override
    public void setValue(StatusBarNotification sbn, String stutas) {
        Notification notification = sbn.getNotification();
        Bundle extras = NotificationCompat.getExtras(notification);

        if (extras != null) {
          /*  String key = extras.getString("key");
            String name = extras.getString("name");
            String status = extras.getString("status");
            String types = extras.getString("types");
            String userId = extras.getString("userId");
            int notificationId = extras.getInt("notificationId");
            String extraText = extras.getString("extraText");
            String title = extras.getString(Notification.EXTRA_TITLE);
            long postTime = notification.when;

            Log.d("NotificationDetails", "Key: " + key);
            Log.d("NotificationDetails", "Name: " + name);
            Log.d("NotificationDetails", "Status: " + status);
            Log.d("NotificationDetails", "Types: " + types);
            Log.d("NotificationDetails", "User ID: " + userId);
            Log.d("NotificationDetails", "Notification ID: " + notificationId);
            Log.d("NotificationDetails", "Extra Text: " + extraText);
            Log.d("NotificationDetails", "Title: " + title);
            Log.d("NotificationDetails", "Post Time: " + new Date(postTime).toString());*/
            //  getShortCurrentDate(postTime);
            //       if (!sbn.getTag().toString().equals("null")) {
        //    Log.d("~~~", "sbn  : " + stutas + "\n       PackageName  :" + sbn.getPackageName() + "\n   getTag  : " + sbn.getTag() + "\n    getId   :" + sbn.getId() + "\n EXTRA Title  :" + extras.getCharSequence(NotificationCompat.EXTRA_TITLE) + "\n       Extra Text  :" + extras.getCharSequence(NotificationCompat.EXTRA_TEXT) + "\n       Sub Text  :" + extras.getCharSequence(Notification.EXTRA_SUB_TEXT) + "\n       Big Text  :" + extras.getCharSequence(NotificationCompat.EXTRA_BIG_TEXT) + "\n       CHANNEL_ID  :" + extras.getCharSequence(NotificationCompat.EXTRA_CHANNEL_ID) + "\n        ID  :" + extras.getCharSequence(NotificationCompat.EXTRA_NOTIFICATION_ID) + "\n       GROUP_ID  :" + extras.getCharSequence(NotificationCompat.EXTRA_CHANNEL_GROUP_ID) + "\n       Time  :" + sbn.getPostTime());
            try {
                if (!(extras.getCharSequence(NotificationCompat.EXTRA_TEXT).toString().contains("new messages") || extras.getCharSequence(NotificationCompat.EXTRA_TEXT).toString().contains("messages from"))) {
                    helper.notificationDao().insert(new NotificationModel(sbn.getTag(), extras.getCharSequence(NotificationCompat.EXTRA_TITLE).toString(), extras.getCharSequence(NotificationCompat.EXTRA_TEXT).toString(), getShortCurrentDate(sbn.getPostTime())));
                } else
                    helper.notificationDao().update(extras.getCharSequence(NotificationCompat.EXTRA_TEXT).toString(), helper.notificationDao().getLastEntry().getNotification_id());

                arrayList = (ArrayList<NotificationModel>) helper.notificationDao().getAll();
                ArrayList<NotificationModel> uniqueList = new ArrayList<NotificationModel>();

                for (int i = 0; i < arrayList.size(); i++) {
                    NotificationModel currentModel = arrayList.get(i);
                    boolean isDuplicate = false;
                    for (int j = 0; j < uniqueList.size(); j++) {
                        NotificationModel uniqueModel = uniqueList.get(j);
                        if (currentModel.getTitle().equals(uniqueModel.getTitle())) {
                            isDuplicate = true;
                            break;
                        }
                    }
                    if (!isDuplicate) {
                        uniqueList.add(currentModel);
                    }
                }
                adapter.updateList(uniqueList);
                if (!(uniqueList.size() == 0)) {
                    binding.dataNotfound.setVisibility(View.GONE);
                }
            } catch (Exception e) {
            }
            //  }
        }
    }

    public static String getShortCurrentDate(long millies) {
        new SimpleDateFormat("dd-MM-yy");
        return new SimpleDateFormat("dd MMM yyyy").format(new Date(millies));
    }

}