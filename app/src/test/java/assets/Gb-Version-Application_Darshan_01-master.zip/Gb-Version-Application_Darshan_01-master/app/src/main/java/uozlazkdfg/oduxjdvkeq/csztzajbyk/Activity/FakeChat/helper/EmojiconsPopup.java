package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.Arrays;
import java.util.List;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.HttpStatus;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Cars;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Electr;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Food;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Nature;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.People;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Sport;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Symbols;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class EmojiconsPopup extends PopupWindow implements ViewPager.OnPageChangeListener, EmojiconRecents {
    String backgroundColor;
    /* access modifiers changed from: private */
    public ViewPager emojisPager;
    String iconPressedColor;
    /* access modifiers changed from: private */
    public Boolean isOpened;
    /* access modifiers changed from: private */
    public int keyBoardHeight;
    Context mContext;
    private int mEmojiTabLastSelectedIndex;
    private View[] mEmojiTabs;
    private PagerAdapter mEmojisAdapter;
    private EmojiconRecentsManager mRecentsManager;
    boolean mUseSystemDefault;
    OnEmojiconBackspaceClickedListener onEmojiconBackspaceClickedListener;
    public EmojiconGridView.OnEmojiconClickedListener onEmojiconClickedListener;
    OnSoftKeyboardOpenCloseListener onSoftKeyboardOpenCloseListener;
    /* access modifiers changed from: private */
    public Boolean pendingOpen;
    int positionPager;
    View rootView;
    boolean setColor;
    String tabsColor;
    View view;

    public interface OnEmojiconBackspaceClickedListener {
        void onEmojiconBackspaceClicked(View view);
    }

    public interface OnSoftKeyboardOpenCloseListener {
        void onKeyboardClose();

        void onKeyboardOpen(int i);
    }

    public void onPageScrollStateChanged(int i) {
    }

    public void onPageScrolled(int i, float f, int i2) {
    }

    @SuppressLint("WrongConstant")
    public EmojiconsPopup(View view2, Context context, boolean z, String str, String str2, String str3) {
        super(context);
        this.mEmojiTabLastSelectedIndex = -1;
        this.keyBoardHeight = 0;
        this.pendingOpen = false;
        this.isOpened = false;
        this.mUseSystemDefault = false;
        this.positionPager = 0;
        this.setColor = false;
        this.iconPressedColor = "#495C66";
        this.tabsColor = "#DCE1E2";
        this.backgroundColor = "#E6EBEF";
        this.setColor = true;
        this.backgroundColor = str3;
        this.iconPressedColor = str;
        this.tabsColor = str2;
        this.mUseSystemDefault = z;
        this.mContext = context;
        this.rootView = view2;
        setContentView(createCustomView());
        setSoftInputMode(5);
        setSize(-1, 255);
        setBackgroundDrawable((Drawable) null);
    }

    @SuppressLint("WrongConstant")
    public EmojiconsPopup(View view2, Context context, boolean z) {
        super(context);
        this.mEmojiTabLastSelectedIndex = -1;
        this.keyBoardHeight = 0;
        this.pendingOpen = false;
        this.isOpened = false;
        this.mUseSystemDefault = false;
        this.positionPager = 0;
        this.setColor = false;
        this.iconPressedColor = "#495C66";
        this.tabsColor = "#DCE1E2";
        this.backgroundColor = "#E6EBEF";
        this.mUseSystemDefault = z;
        this.mContext = context;
        this.rootView = view2;
        setContentView(createCustomView());
        setSoftInputMode(5);
        setSize(-1, 255);
        setBackgroundDrawable((Drawable) null);
    }

    public void setOnSoftKeyboardOpenCloseListener(OnSoftKeyboardOpenCloseListener onSoftKeyboardOpenCloseListener2) {
        this.onSoftKeyboardOpenCloseListener = onSoftKeyboardOpenCloseListener2;
    }

    public void setOnEmojiconClickedListener(EmojiconGridView.OnEmojiconClickedListener onEmojiconClickedListener2) {
        this.onEmojiconClickedListener = onEmojiconClickedListener2;
    }

    public void setOnEmojiconBackspaceClickedListener(OnEmojiconBackspaceClickedListener onEmojiconBackspaceClickedListener2) {
        this.onEmojiconBackspaceClickedListener = onEmojiconBackspaceClickedListener2;
    }

    public void showAtBottom() {
        showAtLocation(this.rootView, 80, 0, 0);
    }

    public void showAtBottomPending() {
        if (isKeyBoardOpen().booleanValue()) {
            showAtBottom();
        } else {
            this.pendingOpen = true;
        }
    }

    public Boolean isKeyBoardOpen() {
        return this.isOpened;
    }

    public void dismiss() {
        super.dismiss();
        EmojiconRecentsManager.getInstance(this.mContext).saveRecents();
    }

    public void setSizeForSoftKeyboard() {
        this.rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                Rect rect = new Rect();
                EmojiconsPopup.this.rootView.getWindowVisibleDisplayFrame(rect);
                int access$000 = EmojiconsPopup.this.getUsableScreenHeight() - (rect.bottom - rect.top);
                int identifier = EmojiconsPopup.this.mContext.getResources().getIdentifier("status_bar_height", "dimen", "android");
                if (identifier > 0) {
                    access$000 -= EmojiconsPopup.this.mContext.getResources().getDimensionPixelSize(identifier);
                }
                if (access$000 > 100) {
                    int unused = EmojiconsPopup.this.keyBoardHeight = access$000;
                    EmojiconsPopup emojiconsPopup = EmojiconsPopup.this;
                    emojiconsPopup.setSize(-1, emojiconsPopup.keyBoardHeight);
                    if (!EmojiconsPopup.this.isOpened.booleanValue() && EmojiconsPopup.this.onSoftKeyboardOpenCloseListener != null) {
                        EmojiconsPopup.this.onSoftKeyboardOpenCloseListener.onKeyboardOpen(EmojiconsPopup.this.keyBoardHeight);
                    }
                    Boolean unused2 = EmojiconsPopup.this.isOpened = true;
                    if (EmojiconsPopup.this.pendingOpen.booleanValue()) {
                        EmojiconsPopup.this.showAtBottom();
                        Boolean unused3 = EmojiconsPopup.this.pendingOpen = false;
                        return;
                    }
                    return;
                }
                Boolean unused4 = EmojiconsPopup.this.isOpened = false;
                if (EmojiconsPopup.this.onSoftKeyboardOpenCloseListener != null) {
                    EmojiconsPopup.this.onSoftKeyboardOpenCloseListener.onKeyboardClose();
                }
            }
        });
    }

    /* access modifiers changed from: private */
    @SuppressLint("WrongConstant")
    public int getUsableScreenHeight() {
        if (Build.VERSION.SDK_INT < 17) {
            return this.rootView.getRootView().getHeight();
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) this.mContext.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }

    public void setSize(int i, int i2) {
        setWidth(i);
        setHeight(i2);
    }

    public void updateUseSystemDefault(boolean z) {
        if (this.view != null) {
            this.mEmojisAdapter = null;
            this.positionPager = this.emojisPager.getCurrentItem();
            dismiss();
            this.mUseSystemDefault = z;
            setContentView(createCustomView());
            this.mEmojiTabs[this.positionPager].setSelected(true);
            this.emojisPager.setCurrentItem(this.positionPager);
            onPageSelected(this.positionPager);
            if (isShowing()) {
                return;
            }
            if (isKeyBoardOpen().booleanValue()) {
                showAtBottom();
            } else {
                showAtBottomPending();
            }
        }
    }

    private View createCustomView() {
        @SuppressLint("WrongConstant") View inflate = ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(R.layout.emojicons, (ViewGroup) null, false);
        this.view = inflate;
        this.emojisPager = (ViewPager) inflate.findViewById(R.id.emojis_pager);
        LinearLayout linearLayout = (LinearLayout) this.view.findViewById(R.id.emojis_tab);
        this.emojisPager.setOnPageChangeListener(this);
        int i = 1;
        EmojisPagerAdapter emojisPagerAdapter = new EmojisPagerAdapter(Arrays.asList(new EmojiconGridView[]{new EmojiconRecentsGridView(this.mContext, (Emojicon[]) null, (EmojiconRecents) null, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, People.DATA, this, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, Nature.DATA, this, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, Food.DATA, this, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, Sport.DATA, this, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, Cars.DATA, this, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, Electr.DATA, this, this, this.mUseSystemDefault), new EmojiconGridView(this.mContext, Symbols.DATA, this, this, this.mUseSystemDefault)}));
        this.mEmojisAdapter = emojisPagerAdapter;
        this.emojisPager.setAdapter(emojisPagerAdapter);
        View[] viewArr = new View[8];
        this.mEmojiTabs = viewArr;
        viewArr[0] = this.view.findViewById(R.id.emojis_tab_0_recents);
        this.mEmojiTabs[1] = this.view.findViewById(R.id.emojis_tab_1_people);
        this.mEmojiTabs[2] = this.view.findViewById(R.id.emojis_tab_2_nature);
        this.mEmojiTabs[3] = this.view.findViewById(R.id.emojis_tab_3_food);
        this.mEmojiTabs[4] = this.view.findViewById(R.id.emojis_tab_4_sport);
        this.mEmojiTabs[5] = this.view.findViewById(R.id.emojis_tab_5_cars);
        this.mEmojiTabs[6] = this.view.findViewById(R.id.emojis_tab_6_elec);
        this.mEmojiTabs[7] = this.view.findViewById(R.id.emojis_tab_7_sym);
        int i2 = 0;
        while (true) {
            View[] viewArr2 = this.mEmojiTabs;
            if (i2 >= viewArr2.length) {
                break;
            }
            int finalI = i2;
            viewArr2[i2].setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    EmojiconsPopup.this.emojisPager.setCurrentItem(finalI);
                }
            });
            i2++;
        }
        this.emojisPager.setBackgroundColor(Color.parseColor(this.backgroundColor));
        linearLayout.setBackgroundColor(Color.parseColor(this.tabsColor));
        int i3 = 0;
        while (true) {
            View[] viewArr3 = this.mEmojiTabs;
            if (i3 >= viewArr3.length) {
                break;
            }
            ((ImageButton) viewArr3[i3]).setColorFilter(Color.parseColor(this.iconPressedColor));
            i3++;
        }
        ImageButton imageButton = (ImageButton) this.view.findViewById(R.id.emojis_backspace);
        imageButton.setColorFilter(Color.parseColor(this.iconPressedColor));
        imageButton.setBackgroundColor(Color.parseColor(this.backgroundColor));
        this.view.findViewById(R.id.emojis_backspace).setOnTouchListener(new RepeatListener(HttpStatus.SC_INTERNAL_SERVER_ERROR, 50, new View.OnClickListener() {
            public void onClick(View view) {
                if (EmojiconsPopup.this.onEmojiconBackspaceClickedListener != null) {
                    EmojiconsPopup.this.onEmojiconBackspaceClickedListener.onEmojiconBackspaceClicked(view);
                }
            }
        }));
        EmojiconRecentsManager instance = EmojiconRecentsManager.getInstance(this.view.getContext());
        this.mRecentsManager = instance;
        int recentPage = instance.getRecentPage();
        if (!(recentPage == 0 && this.mRecentsManager.size() == 0)) {
            i = recentPage;
        }
        if (i == 0) {
            onPageSelected(i);
        } else {
            this.emojisPager.setCurrentItem(i, false);
        }
        return this.view;
    }

    public void addRecentEmoji(Context context, Emojicon emojicon) {
        ((EmojisPagerAdapter) this.emojisPager.getAdapter()).getRecentFragment().addRecentEmoji(context, emojicon);
    }

    public void onPageSelected(int i) {
        int i2 = this.mEmojiTabLastSelectedIndex;
        if (i2 != i) {
            switch (i) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    if (i2 >= 0) {
                        View[] viewArr = this.mEmojiTabs;
                        if (i2 < viewArr.length) {
                            viewArr[i2].setSelected(false);
                        }
                    }
                    this.mEmojiTabs[i].setSelected(true);
                    this.mEmojiTabLastSelectedIndex = i;
                    this.mRecentsManager.setRecentPage(i);
                    return;
                default:
                    return;
            }
        }
    }

    private static class EmojisPagerAdapter extends PagerAdapter {
        private List<EmojiconGridView> views;

        public boolean isViewFromObject(View view, Object obj) {
            return obj == view;
        }

        public EmojiconRecentsGridView getRecentFragment() {
            for (EmojiconGridView next : this.views) {
                if (next instanceof EmojiconRecentsGridView) {
                    return (EmojiconRecentsGridView) next;
                }
            }
            return null;
        }

        public EmojisPagerAdapter(List<EmojiconGridView> list) {
            this.views = list;
        }

        public int getCount() {
            return this.views.size();
        }

        public Object instantiateItem(ViewGroup viewGroup, int i) {
            View view = this.views.get(i).rootView;
            ((ViewPager) viewGroup).addView(view, 0);
            return view;
        }

        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            ((ViewPager) viewGroup).removeView((View) obj);
        }
    }

    public static class RepeatListener implements View.OnTouchListener {
        /* access modifiers changed from: private */
        public final View.OnClickListener clickListener;
        /* access modifiers changed from: private */
        public View downView;
        /* access modifiers changed from: private */
        public Handler handler = new Handler();
        private Runnable handlerRunnable = new Runnable() {
            public void run() {
                if (RepeatListener.this.downView != null) {
                    RepeatListener.this.handler.removeCallbacksAndMessages(RepeatListener.this.downView);
                    RepeatListener.this.handler.postAtTime(this, RepeatListener.this.downView, SystemClock.uptimeMillis() + ((long) RepeatListener.this.normalInterval));
                    RepeatListener.this.clickListener.onClick(RepeatListener.this.downView);
                }
            }
        };
        private int initialInterval;
        /* access modifiers changed from: private */
        public final int normalInterval;

        public RepeatListener(int i, int i2, View.OnClickListener onClickListener) {
            if (onClickListener == null) {
                throw new IllegalArgumentException("null runnable");
            } else if (i < 0 || i2 < 0) {
                throw new IllegalArgumentException("negative interval");
            } else {
                this.initialInterval = i;
                this.normalInterval = i2;
                this.clickListener = onClickListener;
            }
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.downView = view;
                this.handler.removeCallbacks(this.handlerRunnable);
                this.handler.postAtTime(this.handlerRunnable, this.downView, SystemClock.uptimeMillis() + ((long) this.initialInterval));
                this.clickListener.onClick(view);
                return true;
            } else if (action != 1 && action != 3 && action != 4) {
                return false;
            } else {
                this.handler.removeCallbacksAndMessages(this.downView);
                this.downView = null;
                return true;
            }
        }
    }
}
