package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import static com.otaliastudios.cameraview.CameraView.PERMISSION_REQUEST_CODE;
import static uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.SutasSaverFragment.documentFiles;
import static uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility.RootDirectoryWhatsappShow;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutionException;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.FragmentPhotoBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.GetFile;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.StatusImageAdapter;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.helper.PreferenceManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.ActivityKt;

public class PhotosFragment extends Fragment {
    FragmentPhotoBinding binding;
    GetFile getFile;
    String TAG = "PhotoFragment";
    private StatusImageAdapter statusAdapter;
    private ArrayList<String> list = new ArrayList<>();

    String currentpath = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentPhotoBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        Log.d(TAG, "onCreateView() called");
        binding.playerimage.setVisibility(View.GONE);
        if (!RootDirectoryWhatsappShow.exists()) {
            RootDirectoryWhatsappShow.mkdirs();
        }
//        setAdapter();
//        initView();


        return view;
    }

    public void reload(){
        setAdapter();
        initView();
        Log.e(TAG, "reload1: "+list.size() );
        if (PreferenceManager.getInstance().getBoolean("isPermissionGranted", false)) {
            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(PreferenceManager.getInstance().getString("document_uri")));
            documentFiles = fromTreeUri.listFiles();
            for (DocumentFile documentFile : documentFiles) {
                if (documentFile.getName().endsWith(".jpg") || documentFile.getName().endsWith(".jpeg") || documentFile.getName().endsWith(".png")) {
                    //  rootImage.add(documentFile.getUri());
                    list.add(String.valueOf(documentFile.getUri()));
                    //  rootDocumentImage.add(documentFile);
                }
            }
            Log.e(TAG, "reload2: "+list );
        }
        statusAdapter.UpData(list);
        statusAdapter.notifyDataSetChanged();
        if (!(list.size() == 0)) {
            currentpath = list.get(0);
            Glide.with(this).load(list.get(0)).centerCrop().placeholder(R.color.black).into(binding.ImageView);
        } else {
            binding.tv404.setVisibility(View.VISIBLE);
            binding.otherContaint.setVisibility(View.GONE);
        }
    }
    private void setAdapter() {
        getFile = new GetFile();

        if (!(list.size() == 0)) {
            currentpath = list.get(0);
            Glide.with(this).load(list.get(0)).centerCrop().placeholder(R.color.black).into(binding.ImageView);
        }/* else {
            binding.tv404.setVisibility(View.VISIBLE);
            binding.otherContaint.setVisibility(View.GONE);
        }*/
        binding.recView.setLayoutManager(new LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false));
        statusAdapter = new StatusImageAdapter(requireActivity(), new StatusImageAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position, String path) {
                currentpath = path;
                Glide.with(getActivity()).load(path).centerCrop().placeholder(R.color.black).into(binding.ImageView);
            }
        });
        binding.recView.setAdapter(statusAdapter);
    }

    private void initView() {

        binding.btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                if (checkPermission()) {

                    new AsyncTask<Void, Void, Void>() {
                        Bitmap bitmap = null;
                        ProgressDialog pd;
                        @Override
                        protected void onPreExecute() {
                            super.onPreExecute();
                            try {
                                pd = new ProgressDialog(getActivity());
                                pd.setMessage("Downloading..");
                                pd.setCancelable(false);
                                pd.show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        @Override
                        protected Void doInBackground(Void... params) {
                            Random generator = new Random();
                            int n = 10000;
                            n = generator.nextInt(n);
                            String fname = "Image-" + n + ".png";
                            String root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
                            File myDir = new File(root + "/" + getResources().getString(R.string.app_name) + "/" + "Whatsapp" + "/" + "Photo", fname);

                            try {
                                bitmap = Glide.
                                        with(requireActivity()).asBitmap().
                                        load(currentpath).
                                        submit().get();
                                saveImage(bitmap, fname);
                            } catch (ExecutionException e) {
                                throw new RuntimeException(e);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                            return null;
                        }

                        @Override
                        protected void onPostExecute(Void dummy) {
                            if (pd != null && pd.isShowing()) {
                                pd.dismiss();
                            }
                            if (bitmap != null) {
                                Toast.makeText(getActivity(), "Save Successfully!!!", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity().getApplicationContext(), "Failed to Save", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }.execute();
//                    Bitmap savebitmap = getbitmap(binding.ImageView);
//                    saveImage(savebitmap, fname);

//                        BufferedSink bufferedSink = Okio.buffer(Okio.sink(myDir));
//                        bufferedSink.writeAll(Okio.source(new File()));
//                        bufferedSink.close();
//                        Toast.makeText(getActivity(), "Save Successfully!!!", Toast.LENGTH_SHORT).show();
//                    } catch (Exception e) {
//                        e.printStackTrace();

//                    }

                } else requestPermission();

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
//        list.clear();
//        setAdapter();
//        initView();

    }

    private Bitmap getbitmap(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    private void saveImage(Bitmap bitmap, String fname) {
        String root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
        File myDir = new File(root + "/" + getResources().getString(R.string.app_name) + "/" + "Whatsapp" + "/" + "Photo");
        Log.d("SaveImage", "SaveImage: " + myDir);
        if (!myDir.exists()) {
            myDir.mkdirs();
        }


        File file = new File(myDir, fname);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called");
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated() called");
        reload();
    }


    private boolean checkPermission() {
        return ActivityKt.hasPermissions(requireActivity());
    }

    private void requestPermission() {
//        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
//            Toast.makeText(getActivity(), "Write External Storage permission allows us to do store images. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
//        } else {
//            ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},
//                    PERMISSION_REQUEST_CODE);
//        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
        } else {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("value", "Permission Granted, Now you can use local drive .");
                } else {
                    Log.e("value", "Permission Denied, You cannot use local drive .");
                }
                break;
        }
    }
}
