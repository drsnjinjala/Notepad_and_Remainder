package uozlazkdfg.oduxjdvkeq.csztzajbyk.statussaver.data.download;


import android.content.Context;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.jetbrains.annotations.NotNull;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

public class RoundedBottomSheetDialog extends BottomSheetDialog {
    public RoundedBottomSheetDialog(@NotNull Context context) {
        super(context, R.style.BottomSheetDialogTheme);
    }
}
