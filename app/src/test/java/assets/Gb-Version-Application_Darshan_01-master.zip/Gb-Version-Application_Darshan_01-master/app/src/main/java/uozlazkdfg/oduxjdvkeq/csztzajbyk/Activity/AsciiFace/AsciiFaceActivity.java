package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.AsciiFace;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TableLayout;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.AngryFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.HappyFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.OtherFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityAsciiFaceBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class AsciiFaceActivity extends BaseActivity {
    ActivityAsciiFaceBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAsciiFaceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initView();
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        addTabs(viewPager);
        ((TabLayout) findViewById(R.id.tabs)).setupWithViewPager(viewPager);

        APIManager.showSmallNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);
    }


    private void initView() {

        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });}

        class ViewPagerAdapter extends FragmentPagerAdapter {
            private final List<Fragment> mFragmentList = new ArrayList();
            private final List<String> mFragmentTitleList = new ArrayList();

            public ViewPagerAdapter(FragmentManager fragmentManager) {
                super(fragmentManager);
            }

            public Fragment getItem(int i) {
                return this.mFragmentList.get(i);
            }

            public int getCount() {
                return this.mFragmentList.size();
            }

            public void addFrag(Fragment fragment, String str) {
                this.mFragmentList.add(fragment);
                this.mFragmentTitleList.add(str);
            }

            public CharSequence getPageTitle(int i) {
                return this.mFragmentTitleList.get(i);
            }
        }

        private void addTabs (ViewPager viewPager){
            ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
            viewPagerAdapter.addFrag(new HappyFragment(), getResources().getString(R.string.Happy));
            viewPagerAdapter.addFrag(new AngryFragment(), getResources().getString(R.string.Angry));
            viewPagerAdapter.addFrag(new OtherFragment(), getResources().getString(R.string.Other));

            viewPager.setAdapter(viewPagerAdapter);
        }

        public boolean onOptionsItemSelected (MenuItem menuItem){
            onBackPressed();
            return true;
        }

        @Override
        public void onBackPressed () {
            Utility.GotoBack(this);
        }
    }