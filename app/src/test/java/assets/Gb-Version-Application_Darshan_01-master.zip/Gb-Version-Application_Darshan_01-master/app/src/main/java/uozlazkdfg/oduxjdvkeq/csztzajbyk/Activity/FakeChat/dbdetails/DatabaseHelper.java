package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.d;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class DatabaseHelper extends SQLiteOpenHelper {
    private SQLiteDatabase sqLiteDatabase;

    public DatabaseHelper(Context context) {
        super(context, "UserProfile", (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("create table user_info(uid INTEGER PRIMARY KEY ,uname TEXT,ustatus TEXT,uonline TEXT,utyping TEXT,uprofile BLOG)");
        sQLiteDatabase.execSQL("create table chat_info(chatid INTEGER PRIMARY KEY,uid TEXT,ismsg TEXT,sender TEXT, msg TEXT,imagepath TEXT,time TEXT,msgstatus TEXT)");
        Log.d("Database", "Table Created table....");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS user_info");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS chat_info");
        onCreate(sQLiteDatabase);
    }

    public void InsertStudentDetails(String str, String str2, String str3, String str4, byte[] bArr) {
        this.sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("uname", str);
        contentValues.put("ustatus", str2);
        contentValues.put("uonline", str3);
        contentValues.put("utyping", str4);
        contentValues.put("uprofile", bArr);
        this.sqLiteDatabase.insert("user_info", (String) null, contentValues);
        Log.d("Database", "Record.....]]]]] Created table....");
        this.sqLiteDatabase.close();
    }

    public Cursor ViewUserList() {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        this.sqLiteDatabase = writableDatabase;
        Cursor rawQuery = writableDatabase.rawQuery("select * from user_info", (String[]) null);
        Log.d("Datasend", "Data send to user");
        return rawQuery;
    }

    public void saveUserChat(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("uid", str);
        contentValues.put("sender", str2);
        contentValues.put("ismsg", str3);
        contentValues.put(NotificationCompat.CATEGORY_MESSAGE, str4);
        contentValues.put(d.fl, str5);
        contentValues.put("msgstatus", str6);
        contentValues.put("imagepath", str7);
        this.sqLiteDatabase.insert("chat_info", (String) null, contentValues);
        Log.d("Database", "Record.....]]]]] Created table....");
        this.sqLiteDatabase.close();
    }

    public Cursor getUserChatHistory(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        this.sqLiteDatabase = writableDatabase;
        return writableDatabase.rawQuery("select * from chat_info where uid ='" + str + "'", (String[]) null);
    }

    public void UpdateMessageDetails(String str, String str2, String str3, String str4) {
        this.sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("sender", str2);
        contentValues.put(NotificationCompat.CATEGORY_MESSAGE, str3);
        contentValues.put("msgstatus", str4);
        SQLiteDatabase sQLiteDatabase = this.sqLiteDatabase;
        sQLiteDatabase.update("chat_info", contentValues, "chatid=" + str, (String[]) null);
    }

    public Cursor getUserHistory(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        this.sqLiteDatabase = writableDatabase;
        return writableDatabase.rawQuery("select * from user_info where uid ='" + str + "'", (String[]) null);
    }

    public void getUserDetailsUpdate(int i, String str, String str2, String str3, String str4, byte[] bArr) {
        this.sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("uname", str);
        contentValues.put("ustatus", str2);
        contentValues.put("uonline", str3);
        contentValues.put("utyping", str4);
        contentValues.put("uprofile", bArr);
        SQLiteDatabase sQLiteDatabase = this.sqLiteDatabase;
        sQLiteDatabase.update("user_info", contentValues, "uid=" + i, (String[]) null);
    }

    public void DeleteMessage(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        this.sqLiteDatabase = writableDatabase;
        writableDatabase.execSQL("DELETE FROM chat_info WHERE chatid = '" + str + "'");
    }

    public void DeleteUserProfile(int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        this.sqLiteDatabase = writableDatabase;
        writableDatabase.execSQL("DELETE FROM user_info WHERE uid = '" + i + "'");
        SQLiteDatabase sQLiteDatabase = this.sqLiteDatabase;
        sQLiteDatabase.execSQL("DELETE FROM chat_info WHERE uid = '" + i + "'");
    }
}
