package uozlazkdfg.oduxjdvkeq.csztzajbyk.utils

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import think.outside.the.box.AppClass.a.currentActivity
import think.outside.the.box.util.TinyDB

open class BaseApp : Application(), Application.ActivityLifecycleCallbacks, LifecycleObserver {

    override fun onCreate() {
        super.onCreate()
        context = this
    }




    companion object {
        @JvmField
        var context: BaseApp? = null

        var currentActivity: Activity? = null
        var classes = java.util.ArrayList<Class<*>>()
    }

    fun loadOpenAd() {

    }

    open fun setAvoidClass(aClass: Class<*>) {
        classes.add(aClass)
    }

    @Keep
    open fun setAvoidMultipleClass(aClass: ArrayList<Class<*>>) {
        classes.addAll(aClass)
    }


    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
    }

    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {
    }

    override fun onActivityStopped(activity: Activity) {
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
    }

    override fun onActivityDestroyed(activity: Activity) {
    }

}