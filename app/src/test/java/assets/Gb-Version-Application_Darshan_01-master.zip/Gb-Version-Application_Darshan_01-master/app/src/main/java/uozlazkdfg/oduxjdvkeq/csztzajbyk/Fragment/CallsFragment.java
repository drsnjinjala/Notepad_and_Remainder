package uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.circularreveal.CircularRevealLinearLayout;
import com.google.android.material.imageview.ShapeableImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.CallsActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity.VideoCallActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

public class CallsFragment extends Fragment {

    public static Uri selectedImageUri;
    private byte[] bmyimage;
    private CircularRevealLinearLayout callNow, videocall;
    public String nameProfile;
    public EditText txtName;
    private LinearLayout user_profilepic;
    private ShapeableImageView user_profilepic1;
    private CircularRevealLinearLayout pickvideo;
    View view;
    Uri selectedVideoUri;
    private int REQUEST_TAKE_GALLERY_VIDEO;
    private static final int REQUEST_VIDEO_PERMISSIONS = 1;
    private static final String[] VIDEO_PERMISSIONS = {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO};

    String mediaPath1;

    private class btnUserProfilePicListner implements View.OnClickListener {
        private btnUserProfilePicListner() {
        }

        public void onClick(View view) {
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("image/*");
            CallsFragment.this.startActivityForResult(photoPickerIntent, 101);
//            CallsFragment.this.startActivityForResult(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 101);
        }
    }

    private class btnCallNowListner implements View.OnClickListener {
        private btnCallNowListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            CallsFragment callsFragment = CallsFragment.this;
            String unused = callsFragment.nameProfile = callsFragment.txtName.getText().toString();
            Log.i("ContentValues", "onClick: " + CallsFragment.this.nameProfile);
            if (CallsFragment.this.nameProfile.isEmpty()) {
                Toast.makeText(CallsFragment.this.getActivity(), "Please Enter The Caller Name ", 0).show();
                return;
            }
            Intent intent = new Intent(CallsFragment.this.getActivity(), CallsActivity.class);
            intent.putExtra("NAME", CallsFragment.this.nameProfile);
            intent.putExtra("ID", 1);
            intent.putExtra("PROFILEPIC", CallsFragment.selectedImageUri);
            CallsFragment.this.startActivity(intent);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.view = layoutInflater.inflate(R.layout.fragment_call, viewGroup, false);
        this.txtName = (EditText) this.view.findViewById(R.id.user_name);
        this.user_profilepic = this.view.findViewById(R.id.user_profilepic);
        this.user_profilepic1 = this.view.findViewById(R.id.user_profilepic1);
        this.callNow = this.view.findViewById(R.id.callnow);
        this.user_profilepic.setOnClickListener(new btnUserProfilePicListner());
        this.callNow.setOnClickListener(new btnCallNowListner());
        this.pickvideo = this.view.findViewById(R.id.pickvideo);
        this.pickvideo.setOnClickListener(new pickvideocalllistner());
        this.videocall = view.findViewById(R.id.videocallingfake);
        this.videocall.setOnClickListener(new videocallListner());
        return this.view;
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1 && i == 101) {
            onSelectFromGalleryResult(intent);
            Toast.makeText(getActivity(), "Image picked", Toast.LENGTH_SHORT).show();
        } else if (REQUEST_TAKE_GALLERY_VIDEO == i) {
            if (intent != null) {
                selectedVideoUri = intent.getData();

                String[] filePathColumn = {MediaStore.Video.Media.DATA};
                Cursor cursor = getActivity().getContentResolver().query(selectedVideoUri, filePathColumn, null, null, null);
                if (cursor != null) {
                    cursor.moveToFirst();
                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
                    mediaPath1 = cursor.getString(columnIndex);
                    Log.d("mediaPath1:::::", "onActivityResult: " + mediaPath1);
                    cursor.close();
                }
                Bitmap bitmap = createVideoThumbNail(mediaPath1);
//                pickvideo.setImageBitmap(bitmap);
                Toast.makeText(getActivity(), "Video picked", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Please Select Video", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void onSelectFromGalleryResult(Intent intent) {
        try {
            Uri data = intent.getData();
            selectedImageUri = data;
            this.user_profilepic1.setImageURI(data);
            this.bmyimage = saveImageInDB(selectedImageUri);
            getPath(selectedImageUri);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private byte[] saveImageInDB(Uri uri) {
        try {
            return getBytes(getActivity().openFileInput(String.valueOf(uri)));
        } catch (IOException e) {
            Log.e("Hello1", "<saveImageInDB> Error : " + e.getLocalizedMessage());
            return null;
        }
    }

    private byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
    }

    private String getPath(Uri uri) {
        Cursor managedQuery = getActivity().managedQuery(uri, new String[]{"_data"}, (String) null, (String[]) null, (String) null);
        int columnIndexOrThrow = managedQuery.getColumnIndexOrThrow("_data");
        managedQuery.moveToFirst();
        return managedQuery.getString(columnIndexOrThrow);
    }

    private class pickvideocalllistner implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            REQUEST_TAKE_GALLERY_VIDEO = 1;
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("video/*");
            startActivityForResult(photoPickerIntent, REQUEST_TAKE_GALLERY_VIDEO);
        }
    }

    public Bitmap createVideoThumbNail(String path) {
        return ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.MICRO_KIND);
    }

    private class videocallListner implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            if (requestVideoPermissions()) {
                if (mediaPath1 != null) {
                    Intent intent = new Intent(getActivity(), VideoCallActivity.class);
                    intent.putExtra("videocalluri", mediaPath1);
                    startActivity(intent);
                } else {
                    Toast.makeText(getContext(), "Please Pick Video", Toast.LENGTH_SHORT).show();
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_TAKE_GALLERY_VIDEO);
            }


        }
    }

    private boolean requestVideoPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(VIDEO_PERMISSIONS, REQUEST_VIDEO_PERMISSIONS);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_VIDEO_PERMISSIONS) {
            if (grantResults.length == VIDEO_PERMISSIONS.length) {
                boolean permissionsGranted = true;
                for (int result : grantResults) {
                    if (result != PackageManager.PERMISSION_GRANTED) {
                        permissionsGranted = false;
                        break;
                    }
                }
                if (permissionsGranted) {
                    if (mediaPath1 != null) {
                        Intent intent = new Intent(getActivity(), VideoCallActivity.class);
                        intent.putExtra("videocalluri", mediaPath1);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getContext(), "Please Pick Video", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Permissions not granted, show a message to the user
                }
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
