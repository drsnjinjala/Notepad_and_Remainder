package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import java.util.ArrayList;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.CircleImageView;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails.UserDetails;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class UserAdapter extends BaseAdapter {
    public  static ArrayList<UserDetails> userdetails;
    private Context context;
    private LayoutInflater inflater;

    public long getItemId(int i) {
        return (long) i;
    }

    public class Holder {
        CircleImageView img;
        TextView username;
        TextView visibility;

        public Holder() {
        }
    }

    @SuppressLint("WrongConstant")
    public UserAdapter(Context context2, ArrayList<UserDetails> arrayList) {
        this.context = context2;
        this.inflater = (LayoutInflater) context2.getSystemService("layout_inflater");
        userdetails = arrayList;
    }

    public int getCount() {
        return userdetails.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        UserDetails userDetails = userdetails.get(i);
        Holder holder = new Holder();
        View inflate = this.inflater.inflate(R.layout.activity_custlist_userprofile, (ViewGroup) null);
        holder.username = (TextView) inflate.findViewById(R.id.username);
        holder.visibility = (TextView) inflate.findViewById(R.id.visibilitystatus);
        holder.img = (CircleImageView) inflate.findViewById(R.id.user_icon);
        holder.username.setText(userDetails.getUname());
        if (userDetails.getUtyping().equals("typing")) {
            holder.visibility.setText("typing...");
        } else {
            holder.visibility.setText("");
        }
        holder.img.setImageBitmap(getImagefromdatabase(userDetails.getBytes()));
        return inflate;
    }

    private Bitmap getImagefromdatabase(byte[] bArr) {
        return BitmapFactory.decodeByteArray(bArr, 0, bArr.length);
    }
}
