package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.WpChat.ChatDetailActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.DB.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.DB.NotificationModel;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ViewHolder> {
    private ArrayList<NotificationModel> arrayList;
    private Activity activity;
    DatabaseHelper helper;

    public ChatListAdapter(ArrayList<NotificationModel> arrayList, Activity activity) {
        this.arrayList = arrayList;
        this.activity = activity;
        helper = DatabaseHelper.getInstance(activity);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.item_chat, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(arrayList.get(position).getTitle());

        holder.extraText.setText(helper.notificationDao().getLastMgs().getText());
        holder.time.setText(arrayList.get(position).getTime());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, ChatDetailActivity.class);
                intent.putExtra("Name", arrayList.get(holder.getAdapterPosition()).getTitle());
                activity.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public void updateList(ArrayList<NotificationModel> uniqueList) {
        arrayList = new ArrayList<>();
        arrayList.addAll(uniqueList);
        notifyDataSetChanged();

    }

/*
    public static String getShortCurrentDate(String millies) {
        new SimpleDateFormat("dd-MM-yy");
        return new SimpleDateFormat("dd MMM yyyy").format(new Date(millies));
    }
*/

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView title, extraText, time;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.title = (TextView) itemView.findViewById(R.id.user);
            this.extraText = (TextView) itemView.findViewById(R.id.last_message);
            this.time = (TextView) itemView.findViewById(R.id.date);
        }
    }
}
