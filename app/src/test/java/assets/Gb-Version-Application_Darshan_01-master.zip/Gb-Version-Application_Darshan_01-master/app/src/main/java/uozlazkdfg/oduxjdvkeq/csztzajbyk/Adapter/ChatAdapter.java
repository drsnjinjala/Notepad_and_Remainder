package uozlazkdfg.oduxjdvkeq.csztzajbyk.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;

public class ChatAdapter extends BaseAdapter {
    private static LayoutInflater inflater;
    private Context context;
    private ArrayList<String> imagpath;
    private ArrayList<String> ismessagetype;
    private ArrayList<String> messageArray;
    private ArrayList<String> msgstatuslist;
    private ArrayList<String> sendUser;
    private ArrayList<String> time;

    public long getItemId(int i) {
        return (long) i;
    }

    private class Holder {
        public LinearLayout imageLayoutreceiver;
        public LinearLayout imageLayoutsender;
        public ImageView msgread;
        public ImageView msgreceive;
        public ImageView msgsend;
        public TextView receive;
        public RelativeLayout receiverLayout;
        public TextView receivetime;
        public TextView receivetimeimage;
        public ImageView receverimage;
        public TextView send;
        public RelativeLayout senderLayout;
        public ImageView senderimage;
        public TextView sendertimeimage;
        public TextView sendtime;

        private Holder() {
        }
    }

    @SuppressLint("WrongConstant")
    public ChatAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3, ArrayList<String> arrayList4, ArrayList<String> arrayList5, ArrayList<String> arrayList6) {
        this.context = context;
        this.messageArray = arrayList;
        this.sendUser = arrayList2;
        this.time = arrayList3;
        this.msgstatuslist = arrayList4;
        this.ismessagetype = arrayList5;
        this.imagpath = arrayList6;
        inflater = (LayoutInflater) context.getSystemService("layout_inflater");

    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.messageArray.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        TextView textView;
        ImageView imageView;
        Holder holder = new Holder();
        View inflate = inflater.inflate(R.layout.custlistview, (ViewGroup) null);
        holder.send = (TextView) inflate.findViewById(R.id.send);
        holder.receive = (TextView) inflate.findViewById(R.id.receive);
        holder.sendtime = (TextView) inflate.findViewById(R.id.sendtime);
        holder.receivetime = (TextView) inflate.findViewById(R.id.receivetime);
        holder.senderLayout = (RelativeLayout) inflate.findViewById(R.id.senderLayout);
        holder.receiverLayout = (RelativeLayout) inflate.findViewById(R.id.receiverLayout);
        holder.msgsend = (ImageView) inflate.findViewById(R.id.msgsend);
        holder.msgreceive = (ImageView) inflate.findViewById(R.id.msgreceive);
        holder.msgread = (ImageView) inflate.findViewById(R.id.msgread);
        holder.imageLayoutsender = (LinearLayout) inflate.findViewById(R.id.imageLayoutsender);
        holder.imageLayoutreceiver = (LinearLayout) inflate.findViewById(R.id.imageLayoutreceiver);
        holder.senderimage = (ImageView) inflate.findViewById(R.id.senderimage);
        holder.receverimage = (ImageView) inflate.findViewById(R.id.receverimage);
        holder.receivetimeimage = (TextView) inflate.findViewById(R.id.receivetimeimage);
        holder.sendertimeimage = (TextView) inflate.findViewById(R.id.sendertimeimage);

        String str = this.sendUser.get(i);
        if (this.ismessagetype.get(i).equals("yes")) {
            if (str.equals("yes")) {
                holder.receiverLayout.setVisibility(View.INVISIBLE);
                holder.imageLayoutsender.setVisibility(View.INVISIBLE);
                holder.imageLayoutreceiver.setVisibility(View.INVISIBLE);
                holder.senderLayout.setVisibility(View.VISIBLE);
                holder.send.setText(this.messageArray.get(i));
                holder.sendtime.setText(this.time.get(i));
            } else {
                holder.imageLayoutsender.setVisibility(View.INVISIBLE);
                holder.imageLayoutreceiver.setVisibility(View.INVISIBLE);
                holder.senderLayout.setVisibility(View.INVISIBLE);
                holder.receiverLayout.setVisibility(View.VISIBLE);
                holder.receive.setText(this.messageArray.get(i));
                holder.receivetime.setText(this.time.get(i));
            }
        } else if (str.equals("yes")) {
            holder.receiverLayout.setVisibility(View.INVISIBLE);
            holder.imageLayoutreceiver.setVisibility(View.INVISIBLE);
            holder.senderLayout.setVisibility(View.INVISIBLE);
            holder.imageLayoutsender.setVisibility(View.VISIBLE);
            holder.senderimage.requestLayout();
            holder.senderimage.getLayoutParams().height = 200;
            holder.senderimage.getLayoutParams().width = 200;
            holder.senderimage.setScaleType(ImageView.ScaleType.FIT_XY);

//            Uri uri= FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID+".provider",new File(imagpath.get(i)));
            Log.e("fgjfgjh", "" + imagpath.get(i));
//            holder.senderimage.setImageURI(uri);


            Glide.with(context).load(new File(imagpath.get(i))).into(holder.senderimage);


            holder.sendertimeimage.setText(this.time.get(i));
        } else {
            holder.receiverLayout.setVisibility(View.INVISIBLE);
            holder.senderLayout.setVisibility(View.INVISIBLE);
            holder.imageLayoutsender.setVisibility(View.INVISIBLE);
            holder.imageLayoutreceiver.setVisibility(View.VISIBLE);
            holder.receverimage.requestLayout();
            holder.receverimage.getLayoutParams().height = 200;
            holder.receverimage.getLayoutParams().width = 200;
            holder.receverimage.setScaleType(ImageView.ScaleType.FIT_XY);
//            Glide.with(context).load(new File(imagpath.get(i).substring(1,imagpath.get(i).length()-1))).into(holder.receverimage);
            Glide.with(context).load(new File(imagpath.get(i))).into(holder.receverimage);
//            holder.receverimage.setImageURI(Uri.parse(this.imagpath.get(i)));
            holder.receivetimeimage.setText(this.time.get(i));
        }
        String str2 = this.msgstatuslist.get(i);
        if (str2.equals("send")) {
            holder.msgreceive.setVisibility(View.INVISIBLE);
            holder.msgread.setVisibility(View.INVISIBLE);
            holder.msgsend.setVisibility(View.VISIBLE);
        } else if (str2.equals("receive")) {
            holder.msgread.setVisibility(View.INVISIBLE);
            holder.msgsend.setVisibility(View.INVISIBLE);
            holder.msgreceive.setVisibility(View.VISIBLE);
        } else {
            holder.msgsend.setVisibility(View.INVISIBLE);
            holder.msgreceive.setVisibility(View.INVISIBLE);
            holder.msgread.setVisibility(View.VISIBLE);
        }
        return inflate;
    }
}
