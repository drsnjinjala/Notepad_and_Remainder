package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.yalantis.ucrop.UCrop;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.dbdetails.DatabaseHelper;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityChatBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class ChatActivity extends BaseActivity implements View.OnClickListener {
    ActivityChatBinding binding;
    public final int CODE_IMG_GALLARY = 1;
    public final String SAMPLE_CROPED_IMG_NAME = "SampleCropImg";
    String useronline;
    byte[] bmyimage;
    String userstatus;
    String usertyping;
    DatabaseHelper dataBaseDetails;
    String usename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initView();
        binding.imgeset.setOnClickListener(this);
        this.dataBaseDetails = new DatabaseHelper(this);
        binding.saveUserProfile.setOnClickListener(this);
        binding.back.setOnClickListener(this);
        APIManager.showSmallNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);
    }

    private void initView() {

    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.back) {
            onBackPressed();
        } else if (id == R.id.save_userProfile) {
            if (binding.userName.getText().toString().equals("")) {
                Toast.makeText(this, "Please enter your username", Toast.LENGTH_SHORT).show();
            } else ChatActivity.this.SavaProfile();

        } else if (id == R.id.imgeset) {
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("image/*");
            startActivityForResult(photoPickerIntent, CODE_IMG_GALLARY);
//            startActivityForResult(new Intent().setAction(Intent.ACTION_GET_CONTENT).setType("image/*"), CODE_IMG_GALLARY);
        }
    }

    public void SavaProfile() {
        this.usename = binding.userName.getText().toString();
        this.userstatus = binding.userStatus.getText().toString();
        if (binding.userOnlile.isChecked()) {
            this.useronline = "online";
        } else {
            this.useronline = "offline";
        }
        if (binding.userTyping.isChecked()) {
            this.usertyping = "typing";
        } else {
            this.usertyping = "nottyping";
        }

        Log.d("SELECTED DATA IS", "USER NAME" + this.usename + "USER Staus" + this.userstatus + " user onlile" + this.useronline + " user typing " + this.usertyping);
        if (this.bmyimage == null) {
            Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.user_photoo);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            decodeResource.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream);
            this.bmyimage = byteArrayOutputStream.toByteArray();
        }
        this.dataBaseDetails.InsertStudentDetails(this.usename, this.userstatus, this.useronline, this.usertyping, this.bmyimage);
        finish();
    }


    @SuppressLint("MissingSuperCall")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == CODE_IMG_GALLARY && resultCode == RESULT_OK) {
            Uri imageuri = data.getData();
            if (imageuri != null) {
                startCrop(imageuri);
            }
        } else if (requestCode == UCrop.REQUEST_CROP && resultCode == RESULT_OK) {
            Uri ImageUriResultCrop = UCrop.getOutput(data);
            if (ImageUriResultCrop != null) {
                binding.imgeset1.setImageURI(ImageUriResultCrop);
                this.bmyimage = saveImageInDB(ImageUriResultCrop);
            }
        }
    }

    public void startCrop(Uri uri) {
        String destinationalFileNAme = SAMPLE_CROPED_IMG_NAME;
        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), destinationalFileNAme)));
        uCrop.withAspectRatio(1, 1);
        uCrop.withMaxResultSize(450, 450);
        uCrop.start(ChatActivity.this);
    }

    private Uri getImageUri(Bitmap bitmap) {
        bitmap.compress(Bitmap.CompressFormat.JPEG, 10, new ByteArrayOutputStream());
        return Uri.parse(MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "Title", null));
    }

    private byte[] saveImageInDB(Uri uri) {
        try {
            return getBytes(getContentResolver().openInputStream(uri));
        } catch (IOException e) {
            Log.e("Hello1", "<saveImageInDB> Error : " + e.getLocalizedMessage());
            return null;
        }
    }

    private byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[3072];
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}