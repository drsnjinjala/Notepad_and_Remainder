package uozlazkdfg.oduxjdvkeq.csztzajbyk.DB;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Notification_List")
public class NotificationModel {
    // private String Tag, title, text, time;
    @PrimaryKey(autoGenerate = true)
    private int notification_id;
    @ColumnInfo(name = "Tag")
    private String Tag;
    @ColumnInfo(name = "title")
    private String title;
    @ColumnInfo(name = "text")
    private String text;

    @ColumnInfo(name = "mgs_list")
    private String mgs_list;

    @ColumnInfo(name = "time")
    private String time;


    public NotificationModel(String tag, String title, String text, String time) {
        Tag = tag;
        this.title = title;
        this.text = text;
        this.time = time;
    }

    public int getNotification_id() {
        return notification_id;
    }

    public void setNotification_id(int notification_id) {
        this.notification_id = notification_id;
    }

    public NotificationModel() {
    }

    public String getTag() {
        return Tag;
    }

    public void setTag(String tag) {
        Tag = tag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMgs_list() {
        return mgs_list;
    }

    public void setMgs_list(String mgs_list) {
        this.mgs_list = mgs_list;
    }

}
