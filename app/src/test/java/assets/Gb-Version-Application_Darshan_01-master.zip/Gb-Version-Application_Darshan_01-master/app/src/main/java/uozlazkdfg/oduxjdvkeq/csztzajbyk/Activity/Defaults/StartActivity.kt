package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults

import android.content.Intent
import android.graphics.Color
import android.net.MailTo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import com.airbnb.lottie.utils.Utils
import uozlazkdfg.oduxjdvkeq.csztzajbyk.BuildConfig
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityStartBinding
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility

class StartActivity : BaseActivity() {
    lateinit var binding: ActivityStartBinding
    var doubleBackToExitPressedOnce = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        transparentStatusBar()
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        binding.btnStart.setOnClickListener {
            Utility.GotoNext(this@StartActivity, MainActivity::class.java)
        }

        binding.btnMoreApp.setOnClickListener {
            startActivity(
                Intent(
                    "android.intent.action.VIEW",
                    Uri.parse("https://play.google.com/store/apps/developer?id=")
                )
            )
        }
        binding.btnShareApp.setOnClickListener {
            val intent = Intent()
            intent.action = "android.intent.action.SEND"
            intent.type = "text/plain"
            intent.putExtra(
                "android.intent.extra.TEXT",
                getString(R.string.app_name) + " app for Android - https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID
            )
            startActivity(Intent.createChooser(intent, "Share to"))
        }
        binding.btnSendFB.setOnClickListener { view ->
            val intent = Intent("android.intent.action.SENDTO")
            intent.data = Uri.parse(MailTo.MAILTO_SCHEME)
            intent.putExtra("android.intent.extra.EMAIL", arrayOf(""))
            intent.putExtra(
                "android.intent.extra.SUBJECT", "Feedback App " + getString(R.string.app_name)
            )
            startActivity(Intent.createChooser(intent, "Send email..."))
        }
    }

    override fun onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            finishAffinity()
            return
        }
        doubleBackToExitPressedOnce = true
        Toast.makeText(this, "Please Click Back Again To Exit", Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    fun transparentStatusBar() {
        val window = window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
        }
        window.statusBarColor = Color.TRANSPARENT
    }
}