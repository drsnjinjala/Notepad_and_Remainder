package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.content.Context;


import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;

public interface EmojiconRecents {
    void addRecentEmoji(Context context, Emojicon emojicon);
}
