package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import androidx.core.content.ContextCompat;

import java.io.IOException;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity; 
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.CallsFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class CallsActivity extends BaseActivity {
    TextView Name;
    /* access modifiers changed from: private */
    public Handler customHandler = new Handler();
    //  ImageView endCall;
    LinearLayout msg;
    LinearLayout mute;
    ImageView profileImages;
    String profilename;
    LinearLayout speaker;
    /* access modifiers changed from: private */
    public long startTime = 0;
    long timeInMilliseconds = 0;
    long timeSwapBuff = 0;
    TextView times;
    /* access modifiers changed from: private */
    public Runnable updateTimerThread = new updateTimeThreadListner();
    long updatedTime = 0;

    private class btnSpeakerListner implements View.OnClickListener {
        public void onClick(View view) {
        }

        private btnSpeakerListner() {
        }
    }

    private class btnMsgListner implements View.OnClickListener {
        public void onClick(View view) {
        }

        private btnMsgListner() {
        }
    }

    private class btnMuteListner implements View.OnClickListener {
        public void onClick(View view) {
        }

        private btnMuteListner() {
        }
    }

    private class btnEndCallListner implements View.OnClickListener {
        private btnEndCallListner() {
        }

        public void onClick(View view) {
            CallsActivity.this.timeSwapBuff += CallsActivity.this.timeInMilliseconds;
            CallsActivity.this.customHandler.removeCallbacks(CallsActivity.this.updateTimerThread);

        }
    }

    private class updateTimeThreadListner implements Runnable {
        private updateTimeThreadListner() {
        }

        public void run() {
            CallsActivity.this.timeInMilliseconds = SystemClock.uptimeMillis() - CallsActivity.this.startTime;
            CallsActivity calls = CallsActivity.this;
            calls.updatedTime = calls.timeSwapBuff + CallsActivity.this.timeInMilliseconds;
            int i = (int) (CallsActivity.this.updatedTime / 1000);
            TextView textView = CallsActivity.this.times;
            textView.setText("" + String.format("%02d", new Object[]{Integer.valueOf(i / 60)}) + " : " + String.format("%02d", new Object[]{Integer.valueOf(i % 60)}));
            CallsActivity.this.customHandler.postDelayed(this, 0);
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        Bitmap bitmap;
        super.onCreate(bundle);
        setStatusBarGradiant(this);
        setContentView((int) R.layout.activity_calls);

        this.Name = (TextView) findViewById(R.id.txtname);
        this.times = (TextView) findViewById(R.id.txtTime);
        this.profileImages = (ImageView) findViewById(R.id.rlProfile);
        //this.endCall = (ImageView) findViewById(R.id.imEndCall);
        this.speaker = (LinearLayout) findViewById(R.id.speaker);
        this.msg = (LinearLayout) findViewById(R.id.msg);
        this.mute = (LinearLayout) findViewById(R.id.mute);
        this.speaker.setOnClickListener(new btnSpeakerListner());
        this.msg.setOnClickListener(new btnMsgListner());
        this.mute.setOnClickListener(new btnMuteListner());

        findViewById(R.id.cutcall).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });

        if (getIntent().getExtras().getInt("ID") == 1) {
            this.profilename = getIntent().getExtras().getString("NAME");
            if (CallsFragment.selectedImageUri != null) {
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), CallsFragment.selectedImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                    bitmap = null;
                }
                this.profileImages.setBackground(new BitmapDrawable(getResources(), bitmap));
            } else {
                this.profileImages.setBackground(getResources().getDrawable(R.drawable.images));
            }
        } else {
            this.profilename = getIntent().getExtras().getString("NAME");
            if (UserChatActivity.callImages != null) {
                this.profileImages.setBackground(new BitmapDrawable(getResources(), UserChatActivity.callImages));
            } else {
                this.profileImages.setBackground(getResources().getDrawable(R.drawable.images));
            }
        }
        this.Name.setText(this.profilename);
        this.startTime = SystemClock.uptimeMillis();
        this.customHandler.postDelayed(this.updateTimerThread, 0);
        //this.endCall.setOnClickListener(new btnEndCallListner());
    }

    public void onBackPressed() {
        Utility.GotoBack(this);
    }

    public static void setStatusBarGradiant(Activity activity) {
        Window window = activity.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        //   window.setStatusBarColor(ContextCompat.getColor(activity, R.color.my_statusbar_color));
        window.setStatusBarColor(ContextCompat.getColor(activity, R.color.videocolor)); //
    }

}
