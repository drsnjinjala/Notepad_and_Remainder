package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.TextEmoji;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityTexttoEmojiBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;


public class TexttoEmojiActivity extends BaseActivity {

    ActivityTexttoEmojiBinding binding;

    private class btnConvertListner implements View.OnClickListener {
        private btnConvertListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (binding.emojeeTxt.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please Enter Emoji", 0).show();
            }
            if (binding.inputText.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "please Enter text", 0).show();
                return;
            }
            char[] charArray = binding.inputText.getText().toString().toCharArray();
            binding.convertedEmojeeTxt.setText(".\n");
            for (char c : charArray) {
                if (c == '?') {
                    try {
                        InputStream open = getBaseContext().getAssets().open("ques.txt");
                        byte[] bArr = new byte[open.available()];
                        open.read(bArr);
                        open.close();
                        binding.convertedEmojeeTxt.append(new String(bArr).replaceAll("[*]", binding.emojeeTxt.getText().toString()) + "\n\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else if (c == ((char) (c & '_')) || Character.isDigit(c)) {
                    try {
                        InputStream open2 = getBaseContext().getAssets().open(c + ".txt");
                        byte[] bArr2 = new byte[open2.available()];
                        open2.read(bArr2);
                        open2.close();
                        binding.convertedEmojeeTxt.append(new String(bArr2).replaceAll("[*]", binding.emojeeTxt.getText().toString()) + "\n\n");
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                } else {
                    try {
                        InputStream open3 = getBaseContext().getAssets().open("low" + c + ".txt");
                        byte[] bArr3 = new byte[open3.available()];
                        open3.read(bArr3);
                        open3.close();
                        binding.convertedEmojeeTxt.append(new String(bArr3).replaceAll("[*]", binding.emojeeTxt.getText().toString()) + "\n\n");
                    } catch (IOException e3) {
                        e3.printStackTrace();
                    }
                }
            }
            hideKeyboard();
        }
    }

    public void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(this);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private class btnClearTextListner implements View.OnClickListener {
        private btnClearTextListner() {
        }

        public void onClick(View view) {
            binding.convertedEmojeeTxt.setText("");
        }
    }

    private class btnConvertedTextListner implements View.OnClickListener {
        private btnConvertedTextListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (!binding.convertedEmojeeTxt.getText().toString().isEmpty()) {

            }
        }
    }

    private class btnCopyButtonListner implements View.OnClickListener {
        private btnCopyButtonListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (binding.convertedEmojeeTxt.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Convert text before copy", 0).show();
                return;
            }
            ((ClipboardManager) getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(binding.inputText.getText().toString(), binding.convertedEmojeeTxt.getText().toString()));
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.copyline), 0).show();
        }
    }

    private class btnShareListner implements View.OnClickListener {
        private btnShareListner() {
        }

        @SuppressLint("WrongConstant")
        public void onClick(View view) {
            if (binding.convertedEmojeeTxt.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "Convert text to share", 1).show();
                return;
            }
            try {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setPackage("com.whatsapp");
                intent.putExtra("android.intent.extra.TEXT", binding.convertedEmojeeTxt.getText().toString());
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "Select an app to share"));

            } catch (Exception e) {
                Toast.makeText(TexttoEmojiActivity.this, "Whatsapp have not been installed", Toast.LENGTH_SHORT).show();
            }
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setLightTheme(false);
        binding = ActivityTexttoEmojiBinding.inflate(getLayoutInflater());
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(binding.getRoot());
        binding.convertEmojeeBtn.setOnClickListener(new btnConvertListner());
        binding.clearTxtBtn.setOnClickListener(new btnClearTextListner());
        binding.convertedEmojeeTxt.setOnClickListener(new btnConvertedTextListner());
        binding.copyTxtBtn.setOnClickListener(new btnCopyButtonListner());
        binding.shareTxtBtn.setOnClickListener(new btnShareListner());
        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        APIManager.showSmallNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);

    }
}