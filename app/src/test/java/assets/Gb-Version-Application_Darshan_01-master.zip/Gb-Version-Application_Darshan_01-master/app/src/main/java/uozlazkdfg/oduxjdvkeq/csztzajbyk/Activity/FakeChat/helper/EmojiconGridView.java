package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import java.util.Arrays;

import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.Emojicon;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.emoji.People;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;


public class EmojiconGridView {
    Emojicon[] mData;
    EmojiconsPopup mEmojiconPopup;
    EmojiconRecents mRecents;
    private boolean mUseSystemDefault = false;
    public View rootView;

    public interface OnEmojiconClickedListener {
        void onEmojiconClicked(Emojicon emojicon);
    }

    @SuppressLint("WrongConstant")
    public EmojiconGridView(Context context, Emojicon[] emojiconArr, EmojiconRecents emojiconRecents, EmojiconsPopup emojiconsPopup, boolean z) {
        this.mEmojiconPopup = emojiconsPopup;
        this.rootView = ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(R.layout.emojicon_grid, (ViewGroup) null);
        setRecents(emojiconRecents);
        GridView gridView = (GridView) this.rootView.findViewById(R.id.Emoji_GridView);
        if (emojiconArr == null) {
            this.mData = People.DATA;
        } else {
            Object[] objArr = (Object[]) emojiconArr;
            this.mData = (Emojicon[]) Arrays.asList(objArr).toArray(new Emojicon[objArr.length]);
        }
        EmojiAdapter emojiAdapter = new EmojiAdapter(this.rootView.getContext(), this.mData, z);
        emojiAdapter.setEmojiClickListener(new OnEmojiconClickedListener() {
            public void onEmojiconClicked(Emojicon emojicon) {
                if (EmojiconGridView.this.mEmojiconPopup.onEmojiconClickedListener != null) {
                    EmojiconGridView.this.mEmojiconPopup.onEmojiconClickedListener.onEmojiconClicked(emojicon);
                }
                if (EmojiconGridView.this.mRecents != null) {
                    EmojiconGridView.this.mRecents.addRecentEmoji(EmojiconGridView.this.rootView.getContext(), emojicon);
                }
            }
        });
        gridView.setAdapter(emojiAdapter);
    }

    private void setRecents(EmojiconRecents emojiconRecents) {
        this.mRecents = emojiconRecents;
    }
}
