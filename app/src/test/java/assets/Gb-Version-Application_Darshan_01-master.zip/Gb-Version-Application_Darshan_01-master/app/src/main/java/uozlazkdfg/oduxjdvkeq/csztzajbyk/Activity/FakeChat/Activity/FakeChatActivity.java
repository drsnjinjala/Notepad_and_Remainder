package uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.FakeChat.Activity;


import android.annotation.SuppressLint;

import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

import think.outside.the.box.handler.APIManager;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Activity.Defaults.BaseActivity;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.CallsFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.ChatsFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.Fragment.StausFragment;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.R;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.databinding.ActivityFakeChatBinding;
import uozlazkdfg.oduxjdvkeq.csztzajbyk.utils.Utility;

public class FakeChatActivity extends BaseActivity {
    ActivityFakeChatBinding binding;

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        public ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        public int getCount() {
            return this.mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFakeChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        GetPermission();

        setupViewPager(binding.viewpager);
        binding.tabs.setupWithViewPager(binding.viewpager);
        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        APIManager.showSmallNative(binding.adContainerSmallNative);
        APIManager.showBanner(binding.adContainerBanner);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.menu_share) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND");
            intent.putExtra("android.intent.extra.TEXT", "GB WHATS TOOL : https://play.google.com/store/apps/details?id=gbwhats.apktool.free");
            intent.setType("text/plain");
            startActivity(intent);
        } else if (menuItem.getItemId() == R.id.menu_rate) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=gbwhats.apktool.free")));
        } else if (menuItem.getItemId() == R.id.menu_policy) {
            Intent intent2 = new Intent();
            intent2.setAction("android.intent.action.VIEW");
            intent2.addCategory("android.intent.category.BROWSABLE");
            intent2.setData(Uri.parse("https://sites.google.com/view/fo7privacypolicy"));
            startActivity(intent2);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void GetPermission() {
        CheckAccessPermission();
    }

    @SuppressLint("WrongConstant")
    public void CheckAccessPermission() {
        if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            Log.v("Permission", "Permission is granted");
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA"}, 555);
        }
    }

    private void setupViewPager(ViewPager viewPager2) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFrag(new ChatsFragment(), getResources().getString(R.string.Chats));
        viewPagerAdapter.addFrag(new StausFragment(), getResources().getString(R.string.Status));
        viewPagerAdapter.addFrag(new CallsFragment(), getResources().getString(R.string.Calls));
        viewPager2.setAdapter(viewPagerAdapter);
    }

    @Override
    public void onBackPressed() {
        Utility.GotoBack(this);
    }
}