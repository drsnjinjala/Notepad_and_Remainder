package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.adapter.LanguageAdapter;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityLanguageSelectBinding;



public class LanguageSelectActivity  extends AppCompatActivity {

    public static boolean changesLanguage=false;
    LanguageAdapter languageAdapter;
    int LanguagePosition=0;
    ActivityLanguageSelectBinding binding;

    int[] CountryFlag = {R.drawable.us,R.drawable.cn,R.drawable.in,R.drawable.es,R.drawable.fr,R.drawable.eg,R.drawable.ru,R.drawable.br,R.drawable.id};
    String[] languageList = {"English","Chinese","Hindi","Spanish","French","Arabic","Russian","Portuguese","Indonesian"};
    String[] LanguageCode = {"en","ch","hi","es","fr","ar","ru","pt","id"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        binding = ActivityLanguageSelectBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initAdapter();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void initAdapter() {

        languageAdapter = new LanguageAdapter(this, languageList, CountryFlag, position -> {
            LanguagePosition = position;
            languageAdapter.notifyDataSetChanged();
        });
        binding.languageRecyclerview.setAdapter(languageAdapter);



        binding.apply.setOnClickListener(v -> {
            startActivity(new Intent(this,BrowserMainActivity.class));
            finish();
        });
    }


}