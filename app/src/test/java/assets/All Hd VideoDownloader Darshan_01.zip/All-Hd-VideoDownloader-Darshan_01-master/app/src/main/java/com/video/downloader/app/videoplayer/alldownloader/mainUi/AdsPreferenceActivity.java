package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityAdsPrefrancesBinding;

 

public class AdsPreferenceActivity  extends AppCompatActivity {

    ActivityAdsPrefrancesBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAdsPrefrancesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initListener();
    }

    private void initListener() {

        binding.btnNext.setOnClickListener(v -> {



                    startActivity(new Intent(this, WelComeActivity.class));


        });
    }


}