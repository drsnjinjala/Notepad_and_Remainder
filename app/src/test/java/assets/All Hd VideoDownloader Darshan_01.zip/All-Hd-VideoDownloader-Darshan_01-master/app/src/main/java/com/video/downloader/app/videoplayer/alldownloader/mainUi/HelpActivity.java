package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.os.Bundle;
import android.view.View;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.adapter.IntroAdapter;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityHelpBinding;

import java.util.ArrayList;

 

public class HelpActivity  extends AppCompatActivity implements View.OnClickListener {

    ActivityHelpBinding binding;
    ArrayList<String>title;
    int image[] = {R.drawable.help_0,R.drawable.help_1,R.drawable.help_2};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        binding = ActivityHelpBinding.inflate(getLayoutInflater());
        
        setContentView(binding.getRoot());


        title = new ArrayList<>();
        title.add(getResources().getString(R.string.goWebsite));
        title.add(getResources().getString(R.string.PlayVideo));
        title.add(getResources().getString(R.string.clickDownload));
        IntroAdapter introAdapter = new IntroAdapter(this, title,image, () -> {
            onBackPressed();
        });
        binding.idViewPager.setAdapter(introAdapter);
        binding.indicatorView.setViewPager(binding.idViewPager);
        binding.idViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (position == 3) {
                    binding.idLinear1.setVisibility(View.GONE);
                    binding.idLinear2.setVisibility(View.VISIBLE);
                } else {
                    binding.idLinear2.setVisibility(View.GONE);
                    binding.idLinear1.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        binding.idSkip.setOnClickListener(this);
        binding.idNext.setOnClickListener(this);
        binding.idContinue.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.id_skip:
                binding.idViewPager.setCurrentItem(3);
                break;

            case R.id.id_next:
                if (binding.idViewPager.getCurrentItem() == 0) {
                    binding.idViewPager.setCurrentItem(1);
                } else if (binding.idViewPager.getCurrentItem() == 1) {
                    binding.idViewPager.setCurrentItem(2);
                } else if (binding.idViewPager.getCurrentItem() == 2) {
                    binding.idViewPager.setCurrentItem(3);
                } else if (binding.idViewPager.getCurrentItem() == 2) {
                    binding.idViewPager.setCurrentItem(0);
                }
                break;

            case R.id.id_continue:

                    finish();

                break;
        }
    }

 }