package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityMyPolicyBinding;

 

public class MyPolicyActivity  extends AppCompatActivity {

    ActivityMyPolicyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        binding = ActivityMyPolicyBinding.inflate(getLayoutInflater());
        
        setContentView(binding.getRoot());

        initListener();
    }

    private void initListener() {
        binding.btnNext.setOnClickListener(v -> {


                    startActivity(new Intent(this, WelComeActivity.class));


        });
    }
    @Override
    public void onBackPressed() {

            finish();

    }
}