package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityMainBinding;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivitySplashBinding;
import com.video.downloader.app.videoplayer.alldownloader.download.bookmark.BookmarksSQLite;
import com.video.downloader.app.videoplayer.alldownloader.utils.Converters;
import com.video.downloader.app.videoplayer.alldownloader.utils.PreferenceUtil;

import java.util.List;


public class SplashActivity  extends AppCompatActivity {
    ActivitySplashBinding binding;
    PreferenceUtil preferenceUtil;
    boolean abc = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        

        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        preferenceUtil = new PreferenceUtil(SplashActivity.this);
        runOnlyOneTime();
        goNext() ;

    }

    private void goNext() {
        Intent intent = new Intent(SplashActivity.this, BrowserMainActivity.class);
        startActivity(intent);
    }

    private boolean checkPermission1() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }

    public boolean isAppRunning() {
        boolean appFound = false;
        final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        final List<ActivityManager.RunningTaskInfo> recentTasks = activityManager.getRunningTasks(Integer.MAX_VALUE);

        for (int i = 0; i < recentTasks.size(); i++) {
            if (recentTasks.get(i).baseActivity.getPackageName().equals(getPackageName())) {
                appFound = true;
                break;
            }
        }
        return appFound;
    }

    public void runOnlyOneTime() {
        if (preferenceUtil.getBoolean("FirstRun", true)) {
            BookmarksSQLite bookmarksSQLite = new BookmarksSQLite(this);
            bookmarksSQLite.add(Converters.getImageFromResource(this, R.drawable.veoh_icon), getString(R.string.veoh), "https://www.veoh.com/");
            bookmarksSQLite.add(Converters.getImageFromResource(this, R.drawable.imdb_icon), getString(R.string.imob), "https://m.imdb.com/");
            bookmarksSQLite.add(Converters.getImageFromResource(this, R.drawable.ic_tik), getString(R.string.tikTok), "https://www.tiktok.com/");
            preferenceUtil.putBoolean("FirstRun", false);
        }
    }

}