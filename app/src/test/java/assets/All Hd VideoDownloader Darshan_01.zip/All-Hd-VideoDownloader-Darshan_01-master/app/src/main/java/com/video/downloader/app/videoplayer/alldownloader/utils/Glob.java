package com.video.downloader.app.videoplayer.alldownloader.utils;

public class Glob {
    public static boolean videoDownloader = false;
    public static String url11 = "";
}
