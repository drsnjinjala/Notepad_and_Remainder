package com.video.downloader.app.videoplayer.alldownloader.newFlow.utils.app_inteface;

import java.util.List;

/* loaded from: classes2.dex */
public interface AbstructProvider {
    List<?> getList();
}
