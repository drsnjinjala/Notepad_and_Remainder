package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityPrivacyBinding;

 

public class PrivacyActivity extends AppCompatActivity {
    ActivityPrivacyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        
        binding = ActivityPrivacyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


//        binding.backButton.setOnClickListener(v -> {
//            onBackPressed();
//        });

        binding.btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.acceptTermsAndConditions.isChecked()) {
                    if (checkPermission()) {
                           startActivity(new Intent(PrivacyActivity.this, WelComeActivity.class));

                    } else {
                            startActivity(new Intent(PrivacyActivity.this, PermissionGrantedActivity.class));

                    }
                } else
                    Toast.makeText(PrivacyActivity.this, "permission not granted", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }

}




