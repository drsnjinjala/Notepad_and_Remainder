

package com.video.downloader.app.videoplayer.alldownloader.download.history;

public class VisitedPage {
    public String title;
    public String link;
}
