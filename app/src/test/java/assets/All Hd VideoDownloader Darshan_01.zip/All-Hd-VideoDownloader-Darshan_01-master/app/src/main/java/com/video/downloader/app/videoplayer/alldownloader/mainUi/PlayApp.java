package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.app.Application;
import android.content.Intent;

import com.video.downloader.app.videoplayer.alldownloader.download.DownloadManager;
import com.video.downloader.app.videoplayer.alldownloader.BuildConfig;
import com.video.downloader.app.videoplayer.alldownloader.download.blockedAds.AdBlockDatabase;


public class PlayApp extends Application {

    public static PlayApp instance;
    public Intent downloadService;

    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;
        downloadService = new Intent(getApplicationContext(), DownloadManager.class);
        if (BuildConfig.DEBUG) {

        }

    }

    public static PlayApp getInstance() {
        return instance;
    }

    public Intent getDownloadService() {
        return downloadService;
    }

}
