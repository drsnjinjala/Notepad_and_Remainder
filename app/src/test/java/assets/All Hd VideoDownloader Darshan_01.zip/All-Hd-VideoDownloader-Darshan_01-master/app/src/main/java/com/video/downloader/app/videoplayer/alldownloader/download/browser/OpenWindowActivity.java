package com.video.downloader.app.videoplayer.alldownloader.download.browser;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityOpenWindowBinding;
import com.video.downloader.app.videoplayer.alldownloader.databinding.DialogDeleteBinding;

import java.util.List;

 
 
 

public class OpenWindowActivity extends AppCompatActivity {

    ActivityOpenWindowBinding openWindowBinding;
    BrowserManager browserManager;
    private List<BrowserWindow> windows;
    boolean aBoolean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        
        openWindowBinding = ActivityOpenWindowBinding.inflate(getLayoutInflater());
        setContentView(openWindowBinding.getRoot());

        browserManager = BrowserWindow.browserManager;

        windows = browserManager.getAllWindow();

        if (windows.size() == 0) {
            openWindowBinding.noDataText.setVisibility(View.VISIBLE);
            openWindowBinding.windowList.setVisibility(View.GONE);
        } else {
            openWindowBinding.noDataText.setVisibility(View.GONE);
            openWindowBinding.windowList.setVisibility(View.VISIBLE);
        }

//        openWindowBinding.nameText.getPaint().setShader(Utility.setTextGradient(OpenWindowActivity.this, openWindowBinding.nameText));

        openWindowBinding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        openWindowBinding.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(OpenWindowActivity.this, R.style.WideDialog);
                DialogDeleteBinding deleteBinding = DialogDeleteBinding.inflate(LayoutInflater.from(OpenWindowActivity.this), null, false);
                dialog.setContentView(deleteBinding.getRoot());
                dialog.setCancelable(false);
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.show();

                deleteBinding.titleText.setText(R.string.alert);
                deleteBinding.msgText.setText(R.string.are_you_sure_to_close_all_window);

                deleteBinding.yesButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        browserManager.closeWindowAll();
                        windows = browserManager.getAllWindow();
                        dialog.dismiss();


                            if (windows.size() == 0) {
                                setResult(123);
                                finish();
                            } else {
                                finish();
                            }


                    }
                });

                deleteBinding.noButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });
        openWindowBinding.windowList.setLayoutManager(new LinearLayoutManager(OpenWindowActivity.this, RecyclerView.VERTICAL, false));
        openWindowBinding.windowList.setAdapter(new AllWindowsAdapter());
    }

    private class AllWindowsAdapter extends RecyclerView.Adapter<WindowItem> {

        @NonNull
        @Override
        public WindowItem onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(OpenWindowActivity.this);
            View item = inflater.inflate(R.layout.item_browser_openwindow, parent, false);
            return new WindowItem(item);
        }

        @Override
        public void onBindViewHolder(@NonNull WindowItem holder, @SuppressLint("RecyclerView") int position) {
            holder.bind(windows.get(position).getWebView());

            holder.closeIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final Dialog dialog = new Dialog(OpenWindowActivity.this, R.style.WideDialog);
                    DialogDeleteBinding deleteBinding = DialogDeleteBinding.inflate(LayoutInflater.from(OpenWindowActivity.this), null, false);
                    dialog.setContentView(deleteBinding.getRoot());
                    dialog.setCancelable(false);
                    dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                    dialog.show();

                    deleteBinding.titleText.setText(R.string.alert);
                    deleteBinding.msgText.setText(R.string.are_you_sure_to_close_all_window);

                    deleteBinding.yesButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            browserManager.closeWindow(windows.get(position));
                            windows = browserManager.getAllWindow();
                            notifyDataSetChanged();
                            dialog.dismiss();
                            if (windows.size() == 0) {
                                finish();
                            }

                                finish();

                        }
                    });

                    deleteBinding.noButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();
                        }
                    });
                }
            });
        }

        @Override
        public int getItemCount() {
            return windows.size();
        }
    }

    private class WindowItem extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView windowTitle;
        ImageView favicon;
        ImageView closeIcon;

        WindowItem(View itemView) {
            super(itemView);
            windowTitle = itemView.findViewById(R.id.windowTitle);
            favicon = itemView.findViewById(R.id.favicon);
            closeIcon = itemView.findViewById(R.id.closeButton);
            itemView.setOnClickListener(this);

        }

        void bind(WebView webView) {
            windowTitle.setText(webView.getTitle());
            favicon.setImageBitmap(webView.getFavicon());
//            Glide.with(OpenWindowActivity.this).load(webView.getFavicon()).placeholder(R.drawable.google_icon).error(R.drawable.google_icon).into(favicon);

        }

        @Override
        public void onClick(View v) {
            browserManager.switchWindow(getAdapterPosition());
            finish();
        }
    }

  
}