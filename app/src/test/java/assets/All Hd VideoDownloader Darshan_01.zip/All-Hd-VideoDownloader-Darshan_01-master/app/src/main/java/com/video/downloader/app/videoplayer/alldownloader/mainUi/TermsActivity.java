package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityTermsBinding;

 

public class TermsActivity  extends AppCompatActivity {

    ActivityTermsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityTermsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
       
        initListener();
    }

    private void initListener() {
        binding.btnNext.setOnClickListener(v -> {
            if (binding.acceptTermsAndConditions.isChecked()){

                    startActivity(new Intent(this, WelComeActivity.class));
                    overridePendingTransition(R.anim.fadein, R.anim.fadeout);

            }
            else {
                Toast.makeText(this, R.string.terms, Toast.LENGTH_SHORT).show();
            }
        });
    }


}