package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityStartBinding;


public class StartActivity extends AppCompatActivity {

    ActivityStartBinding binding;
    private boolean doubleBackToExitPressedOnce;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        
        binding = ActivityStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        initListener();
    }

    private void initListener() {

        binding.adCallToAction.setOnClickListener(v -> {

                startActivity(new Intent(StartActivity.this, PrivacyActivity.class));

        });

        binding.btnrate.setOnClickListener(v -> {

        });

        binding.btnPrivacy.setOnClickListener(v -> {
               });

    }




    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }




}