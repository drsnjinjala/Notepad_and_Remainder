package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Window;

import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivitySplashBinding;
import com.video.downloader.app.videoplayer.alldownloader.download.bookmark.BookmarksSQLite;
import com.video.downloader.app.videoplayer.alldownloader.utils.Converters;
import com.video.downloader.app.videoplayer.alldownloader.utils.PreferenceUtil;

import java.util.List;

import aani.brothers.noty.Aanibrothers;
import think.outside.the.box.callback.AdsCallback;
import think.outside.the.box.callback.SplashCallback;
import think.outside.the.box.handler.APIManager;
import think.outside.the.box.vpn.VpnConnection;

public class SplashActivity extends BaseActivity {
    ActivitySplashBinding binding;
    PreferenceUtil preferenceUtil;
    boolean abc = true;
    VpnConnection vpnConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        setLightTheme(true);

        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Aanibrothers.subscribeNotification(this);
        Aanibrothers.configureNotification(this, getResources().getString(R.string.app_name), R.drawable.ic_video, R.color.transparent);
        preferenceUtil = new PreferenceUtil(SplashActivity.this);
        runOnlyOneTime();
        vpnConnection = new VpnConnection(this);

        APIManager.initializeSplash(
                this, () -> {
                    if (APIManager.getVPNStatus()) {
                        vpnConnection.connectVpnListener((s) -> {
                            goNext();
                        });
                    } else {
                        goNext();
                    }
                });
    }

    private void goNext() {

        APIManager.showSplashAD(SplashActivity.this, new AdsCallback() {
            @Override
            public void onClose(boolean b) {
                if (APIManager.hasStartScreen()) {
                    Intent intent = new Intent(SplashActivity.this, StartActivity.class);
                    startActivity(intent);
                    abc = false;
                    finish();
                } else {
                    if (checkPermission1()) {
                        Intent intent = new Intent(SplashActivity.this, WelComeActivity.class);
                        startActivity(intent);
                        abc = false;
                        finish();
                    } else {
                        Intent intent = new Intent(SplashActivity.this, PermissionGrantedActivity.class);
                        startActivity(intent);
                        abc = false;
                        finish();
                    }
                }
            }
        });
    }

    private boolean checkPermission1() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }

    //    @Override
//    public void onBackPressed() {
//        if (abc) {
//            VpnConnection.stopVpn();
//        }
//   App version updated...
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        boolean appRunning = isAppRunning();
        if (abc || !appRunning) {
            VpnConnection.stopVpn();
        }
    }

    public boolean isAppRunning() {
        boolean appFound = false;
        final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        final List<ActivityManager.RunningTaskInfo> recentTasks = activityManager.getRunningTasks(Integer.MAX_VALUE);

        for (int i = 0; i < recentTasks.size(); i++) {
            if (recentTasks.get(i).baseActivity.getPackageName().equals(getPackageName())) {
                appFound = true;
                break;
            }
        }
        return appFound;
    }

    public void runOnlyOneTime() {
        if (preferenceUtil.getBoolean("FirstRun", true)) {
            BookmarksSQLite bookmarksSQLite = new BookmarksSQLite(this);
            bookmarksSQLite.add(Converters.getImageFromResource(this, R.drawable.veoh_icon), getString(R.string.veoh), "https://www.veoh.com/");
            bookmarksSQLite.add(Converters.getImageFromResource(this, R.drawable.imdb_icon), getString(R.string.imob), "https://m.imdb.com/");
            bookmarksSQLite.add(Converters.getImageFromResource(this, R.drawable.ic_tik), getString(R.string.tikTok), "https://www.tiktok.com/");
            preferenceUtil.putBoolean("FirstRun", false);
        }
    }

}