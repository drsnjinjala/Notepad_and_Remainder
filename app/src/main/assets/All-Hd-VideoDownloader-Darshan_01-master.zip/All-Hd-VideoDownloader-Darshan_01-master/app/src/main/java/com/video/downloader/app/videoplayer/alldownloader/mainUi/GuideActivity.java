package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityGuideBinding;

import think.outside.the.box.handler.APIManager;

public class GuideActivity extends VPNConnection {

    ActivityGuideBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        setLightTheme(true);
        binding = ActivityGuideBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        APIManager.showSmallNative(binding.adNative);
        initListener();
    }

    private void initListener() {
        binding.start.setOnClickListener(v -> {
            APIManager.showInter(this, false, b -> {
                startActivity(new Intent(this, WelComeActivity.class));
                overridePendingTransition(R.anim.fadein, R.anim.fadeout);
            });
        });
    }

    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, b -> {
            finish();
        });
    }
}