package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityFolderBinding;
import com.video.downloader.app.videoplayer.alldownloader.fragment.SaveFragment;
import com.video.downloader.app.videoplayer.alldownloader.fragment.SettingFragment;

import think.outside.the.box.handler.APIManager;

public class FolderActivity extends VPNConnection {
    ActivityFolderBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        setLightTheme(true);
        binding = ActivityFolderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getIntentData();
        initFragment();
        initListener();
    }

    @SuppressLint("SetTextI18n")
    private void getIntentData() {
        String type = getIntent().getStringExtra("type");
        if (type.equals("folder")) {
            binding.title.setText(R.string.folder);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new SaveFragment()).commit();
        } else if (type.equals("setting")) {
            binding.title.setText(R.string.setting);
            setSettingColor();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new SettingFragment()).commit();
        } else {
            binding.title.setText(R.string.folder);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new SaveFragment()).commit();
        }
    }

    private void setSettingColor() {
        binding.homeImage.setImageResource(R.drawable.ic_home);
        binding.folderImage.setImageResource(R.drawable.folder_save);
        binding.settingImage.setImageResource(R.drawable.ic_setting_selected);
        //  binding.homeText.setTextColor(getResources().getColor(R.color.dark_Black));

        binding.folderImage.setColorFilter(getResources().getColor(R.color.white));
        binding.settingImage.setColorFilter(getResources().getColor(R.color.green));

        binding.settingText.setVisibility(View.VISIBLE);
        binding.folderText.setVisibility(View.GONE);


        // binding.folderText.setTextColor(getResources().getColor(R.color.dark_Black));
        //binding.settingText.setTextColor(getResources().getColor(R.color.pinkSelector));
    }

    private void initListener() {
        binding.icBack.setOnClickListener(v -> {
            onBackPressed();
        });
    }

    @SuppressLint("SetTextI18n")
    private void initFragment() {

        binding.home.setOnClickListener(v -> {
            ;
            binding.homeImage.setImageResource(R.drawable.ic_home_selectd);
            binding.folderImage.setImageResource(R.drawable.folder_save);
            binding.settingImage.setImageResource(R.drawable.setting);
            //  binding.homeText.setTextColor(getResources().getColor(R.color.pinkSelector));
            //binding.folderText.setTextColor(getResources().getColor(R.color.dark_Black));
            //  binding.settingText.setTextColor(getResources().getColor(R.color.dark_Black));

            binding.homeImage.setColorFilter(getResources().getColor(R.color.green));
            binding.folderImage.setColorFilter(getResources().getColor(R.color.white));
            binding.settingImage.setColorFilter(getResources().getColor(R.color.white));
            binding.folderText.setVisibility(View.GONE);
            binding.settingText.setVisibility(View.GONE);
            binding.homeText.setVisibility(View.VISIBLE);

            APIManager.showInter(this, false, b -> {
                finish();
            });
        });

        binding.folder.setOnClickListener(v -> {
            binding.title.setText(R.string.folder);
            binding.homeImage.setImageResource(R.drawable.ic_home);
            binding.folderImage.setImageResource(R.drawable.ic_folder_save_selected);
            binding.settingImage.setImageResource(R.drawable.setting);
            //    binding.homeText.setTextColor(getResources().getColor(R.color.dark_Black));
            // binding.folderText.setTextColor(getResources().getColor(R.color.pinkSelector));
            // binding.settingText.setTextColor(getResources().getColor(R.color.dark_Black));

            binding.folderImage.setColorFilter(getResources().getColor(R.color.green));
            binding.settingImage.setColorFilter(getResources().getColor(R.color.white));
            binding.folderText.setVisibility(View.VISIBLE);
            binding.settingText.setVisibility(View.GONE);

            APIManager.showInter(this, false, b -> {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new SaveFragment()).commit();
            });
        });

        binding.settings.setOnClickListener(v -> {
            setSettingColor();
            binding.title.setText(R.string.setting);
            APIManager.showInter(this, false, b -> {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new SettingFragment()).commit();
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (binding.settingText.getVisibility() == View.VISIBLE) {
            binding.home.performClick();
        } else if (binding.settingText.getVisibility() == View.VISIBLE) {
            binding.home.performClick();
        } else {
            APIManager.showInter(this, true, b -> {
                finish();
            });
        }
    }
}