package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import think.outside.the.box.handler.APIManager;
import think.outside.the.box.vpn.VPNConnections;
import think.outside.the.box.vpn.VpnConnection;


public class VPNConnection extends BaseActivity {
    VpnConnection vpnConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vpnConnection = new VpnConnection(this);

        if (APIManager.getVPNStatus()) {
            vpnConnection.isConnected(new VPNConnections() {
                @Override
                public void onConnected(Boolean isConnected) {
                    
                    if (!isConnected) {
                        //   Log.d("~~~", "true" + isConnected);
                        vpnConnection.connectToVpn();
                    }
                }
            });
        }
    }
}