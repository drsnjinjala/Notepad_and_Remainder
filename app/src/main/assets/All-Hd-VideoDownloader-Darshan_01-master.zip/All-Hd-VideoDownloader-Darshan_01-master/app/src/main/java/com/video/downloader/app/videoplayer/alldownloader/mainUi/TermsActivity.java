package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityTermsBinding;

import think.outside.the.box.handler.APIManager;

public class TermsActivity extends VPNConnection {

    ActivityTermsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityTermsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        APIManager.showNative(binding.adsNative200);
        initListener();
    }

    private void initListener() {
        binding.btnNext.setOnClickListener(v -> {
            if (binding.acceptTermsAndConditions.isChecked()){
                APIManager.showInter(this, false, b -> {
                    startActivity(new Intent(this, WelComeActivity.class));
                    overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                });
            }
            else {
                Toast.makeText(this, R.string.terms, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, b -> {
           finish();
        });
    }
}