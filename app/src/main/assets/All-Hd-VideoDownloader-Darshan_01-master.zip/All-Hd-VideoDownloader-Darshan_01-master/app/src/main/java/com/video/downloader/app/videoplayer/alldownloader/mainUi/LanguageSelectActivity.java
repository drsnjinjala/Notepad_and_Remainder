package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.adapter.LanguageAdapter;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityLanguageSelectBinding;

import think.outside.the.box.handler.APIManager;
import think.outside.the.box.util.TinyDB;

public class LanguageSelectActivity extends VPNConnection {

    public static boolean changesLanguage=false;
    LanguageAdapter languageAdapter;
    int LanguagePosition=0;
    ActivityLanguageSelectBinding binding;

    int[] CountryFlag = {R.drawable.us,R.drawable.cn,R.drawable.in,R.drawable.es,R.drawable.fr,R.drawable.eg,R.drawable.ru,R.drawable.br,R.drawable.id};
    String[] languageList = {"English","Chinese","Hindi","Spanish","French","Arabic","Russian","Portuguese","Indonesian"};
    String[] LanguageCode = {"en","ch","hi","es","fr","ar","ru","pt","id"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        binding = ActivityLanguageSelectBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        APIManager.showBanner(binding.adBanner);
        initAdapter();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void initAdapter() {

        languageAdapter = new LanguageAdapter(this, languageList, CountryFlag, position -> {
            LanguagePosition = position;
            languageAdapter.notifyDataSetChanged();
        });
        binding.languageRecyclerview.setAdapter(languageAdapter);

        int pos = new TinyDB(this).getInt("LangPos");
        languageAdapter.selectItem(pos);

        binding.apply.setOnClickListener(v -> {
            new TinyDB(this).putString("LangCode",LanguageCode[LanguagePosition]);
            new TinyDB(this).putInt("LangPos",LanguagePosition);
            if (changesLanguage){
                APIManager.showInter(this, false, b -> {
                    startActivity(new Intent(this,BrowserMainActivity.class));
                    finish();
                });
            }else {
                APIManager.showInter(this, false, b -> {
                    if (APIManager.getStartScreenCount() == 2) {
                        startActivity(new Intent(this, WelComeActivity.class));
                    } else {
                        startActivity(new Intent(this, AdsPreferenceActivity.class));
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                    }
                });
            }
        });
    }

    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, b -> {
            finish();
        });
    }
}