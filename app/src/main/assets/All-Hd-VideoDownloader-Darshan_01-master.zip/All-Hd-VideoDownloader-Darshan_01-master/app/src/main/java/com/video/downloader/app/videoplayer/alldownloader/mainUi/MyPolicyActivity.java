package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityMyPolicyBinding;

import think.outside.the.box.handler.APIManager;

public class MyPolicyActivity extends VPNConnection {

    ActivityMyPolicyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        binding = ActivityMyPolicyBinding.inflate(getLayoutInflater());
        setLightTheme(true);
        setContentView(binding.getRoot());
        APIManager.showNative(binding.adBanner);
        initListener();
    }

    private void initListener() {
        binding.btnNext.setOnClickListener(v -> {
            APIManager.showInter(this, false, b -> {
                if (APIManager.getStartScreenCount() == 5) {
                    startActivity(new Intent(this, WelComeActivity.class));
                } else {
                    startActivity(new Intent(this, GuideActivity.class));
                    overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                }
            });
        });
    }
    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, b -> {
            finish();
        });
    }
}