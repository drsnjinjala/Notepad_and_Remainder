package com.video.downloader.app.videoplayer.alldownloader.newFlow.utils.app_inteface;

import android.view.View;

/* loaded from: classes2.dex */
public interface CustomItemClickListener {
    void onItemClick(View view, int i);

    void onShareClick(View view, int i);
}
