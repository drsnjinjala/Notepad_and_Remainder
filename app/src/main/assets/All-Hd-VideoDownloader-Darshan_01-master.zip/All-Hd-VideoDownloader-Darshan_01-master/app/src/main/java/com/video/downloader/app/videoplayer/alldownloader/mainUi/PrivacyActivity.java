package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityPrivacyBinding;

import think.outside.the.box.handler.APIManager;

public class PrivacyActivity extends VPNConnection {
    ActivityPrivacyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        setLightTheme(true);
        binding = ActivityPrivacyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        APIManager.showNative(binding.adsNative200);
//        binding.backButton.setOnClickListener(v -> {
//            onBackPressed();
//        });

        binding.btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.acceptTermsAndConditions.isChecked()) {
                    if (checkPermission()) {
                        APIManager.showInter(PrivacyActivity.this, false, isfail -> {
                            startActivity(new Intent(PrivacyActivity.this, WelComeActivity.class));
                        });
                    } else {
                        APIManager.showInter(PrivacyActivity.this, false, isfail -> {
                            startActivity(new Intent(PrivacyActivity.this, PermissionGrantedActivity.class));
                        });
                    }
                } else
                    Toast.makeText(PrivacyActivity.this, "permission not granted", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }

}




