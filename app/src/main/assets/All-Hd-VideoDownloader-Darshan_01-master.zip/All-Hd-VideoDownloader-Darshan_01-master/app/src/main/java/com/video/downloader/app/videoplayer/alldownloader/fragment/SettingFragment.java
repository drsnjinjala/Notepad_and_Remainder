package com.video.downloader.app.videoplayer.alldownloader.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.video.downloader.app.videoplayer.alldownloader.download.history.HistorySQLite;
import com.video.downloader.app.videoplayer.alldownloader.mainUi.LanguageSelectActivity;
import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.DialogDeleteBinding;
import com.video.downloader.app.videoplayer.alldownloader.databinding.FragmentSettingBinding;
import com.video.downloader.app.videoplayer.alldownloader.download.history.VisitedPage;

import java.util.List;

import think.outside.the.box.handler.APIManager;


public class SettingFragment extends Fragment {

    FragmentSettingBinding binding;
    private HistorySQLite historySQLite;
    private List<VisitedPage> visitedPages;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSettingBinding.inflate(inflater,container,false);
        APIManager.showNative(binding.adNative);
        historySQLite = new HistorySQLite(getActivity());
        visitedPages = historySQLite.getAllVisitedPages();
        binding.clearHistory.setOnClickListener(v -> {
            Dialog dialog = new Dialog(getActivity(), R.style.WideDialog);
            DialogDeleteBinding deleteBinding = DialogDeleteBinding.inflate(LayoutInflater.from(getActivity()),  null, false);
            dialog.setContentView(deleteBinding.getRoot());
            dialog.setCancelable(false);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.show();

            deleteBinding.titleText.setText(R.string.delete);
            deleteBinding.msgText.setText(R.string.deleteHistory);

            deleteBinding.yesButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    APIManager.showInter(getActivity(), false, b -> {
                        historySQLite.clearHistory();
                        visitedPages.clear();
                        dialog.dismiss();
                    });
                }
            });

            deleteBinding.noButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
        });

        binding.changeLanguage.setOnClickListener(v -> {
             APIManager.showInter(getActivity(), false, b -> {
                 LanguageSelectActivity.changesLanguage = true;
                 startActivity(new Intent(getActivity(), LanguageSelectActivity.class));
             });
        });

        binding.rate.setOnClickListener(v -> {
            APIManager.showRattingDialog(getActivity(), () -> {
            });
        });

        binding.share.setOnClickListener(v -> {
            try {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                String shareMessage = "\nLet me recommend you this application\n\n";
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + getActivity().getPackageName() + "\n\n";
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                startActivity(Intent.createChooser(shareIntent, "choose one"));
            } catch (Exception e) {
                e.getMessage();
            }
        });

        binding.policy.setOnClickListener(v -> {
            APIManager.showPrivacyDialog(getActivity(), getResources().getStringArray(R.array.terms_of_service));
        });

        return binding.getRoot();
    }
}