package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.content.Intent;
import android.os.Bundle;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityAdsPrefrancesBinding;

import think.outside.the.box.handler.APIManager;

public class AdsPreferenceActivity extends VPNConnection {

    ActivityAdsPrefrancesBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAdsPrefrancesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        APIManager.showBanner(binding.adBanner);
        initListener();
    }

    private void initListener() {

        binding.btnNext.setOnClickListener(v -> {
            APIManager.showInter(this, false, b -> {
                if (APIManager.getStartScreenCount() == 3) {
                    startActivity(new Intent(this, WelComeActivity.class));
                } else {
                    startActivity(new Intent(this, TermsActivity.class));
                    overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, b -> {
            finish();
        });
    }
}