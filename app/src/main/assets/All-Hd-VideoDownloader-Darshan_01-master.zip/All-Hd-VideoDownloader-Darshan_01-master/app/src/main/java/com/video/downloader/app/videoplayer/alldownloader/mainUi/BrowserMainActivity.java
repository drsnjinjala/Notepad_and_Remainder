package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Window;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityBowserMainBinding;
import com.video.downloader.app.videoplayer.alldownloader.fragment.HomeFragment;
import com.video.downloader.app.videoplayer.alldownloader.fragment.SaveFragment;

import think.outside.the.box.callback.AdsCallback;
import think.outside.the.box.handler.APIManager;

public class BrowserMainActivity extends VPNConnection {

    ActivityBowserMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.green));
        setLightTheme(true);
        binding = ActivityBowserMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        APIManager.showBanner(binding.adBanner);
        initListener();
    }

    private void initListener() {
        binding.previous.setOnClickListener(v -> {
            binding.previousImage.setImageResource(R.drawable.ic_back_selected);
            binding.nextImage.setImageResource(R.drawable.ic_back);
            binding.homeImage.setImageResource(R.drawable.ic_home);
            binding.folderImage.setColorFilter(ContextCompat.getColor(this, R.color.dark_Black), android.graphics.PorterDuff.Mode.SRC_IN);
            binding.settingImage.setColorFilter(ContextCompat.getColor(this, R.color.dark_Black), android.graphics.PorterDuff.Mode.SRC_IN);
            binding.previousText.setTextColor(getResources().getColor(R.color.pinkSelector));
            //   binding.homeText.setTextColor(getResources().getColor(R.color.dark_Black));
            binding.nextText.setTextColor(getResources().getColor(R.color.dark_Black));
            binding.folderText.setTextColor(getResources().getColor(R.color.dark_Black));
            binding.settingText.setTextColor(getResources().getColor(R.color.dark_Black));
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new HomeFragment()).commit();
        });

        binding.next.setOnClickListener(v -> {

            binding.previousImage.setImageResource(R.drawable.ic_back);
            binding.nextImage.setImageResource(R.drawable.ic_back_selected);
            binding.homeImage.setImageResource(R.drawable.ic_home);
            binding.folderImage.setColorFilter(ContextCompat.getColor(this, R.color.dark_Black), android.graphics.PorterDuff.Mode.SRC_IN);
            binding.settingImage.setColorFilter(ContextCompat.getColor(this, R.color.dark_Black), android.graphics.PorterDuff.Mode.SRC_IN);
            binding.previousText.setTextColor(getResources().getColor(R.color.dark_Black));
            //  binding.homeText.setTextColor(getResources().getColor(R.color.dark_Black));
            binding.nextText.setTextColor(getResources().getColor(R.color.pinkSelector));
            binding.folderText.setTextColor(getResources().getColor(R.color.dark_Black));
            binding.settingText.setTextColor(getResources().getColor(R.color.dark_Black));
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new SaveFragment()).commit();
        });

        binding.home.setOnClickListener(v -> {
            setHomeColor();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new HomeFragment()).commit();
        });

        binding.folder.setOnClickListener(v -> {
            setHomeColor();
            APIManager.showInter(this, false, b -> {
                Intent intent = new Intent(this, FolderActivity.class);
                intent.putExtra("type", "folder");
                startActivity(intent);
            });
        });

        binding.settings.setOnClickListener(v -> {
            setHomeColor();
            APIManager.showInter(this, false, b -> {
                Intent intent = new Intent(this, FolderActivity.class);
                intent.putExtra("type", "setting");
                startActivity(intent);
            });
        });

        binding.process.setOnClickListener(v -> {
            APIManager.showInter(this, false, b -> {
                startActivity(new Intent(this, ProcessActivity.class));
            });
        });

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new HomeFragment()).commit();
    }

    private void setHomeColor() {
        binding.previousImage.setImageResource(R.drawable.ic_back);
        binding.nextImage.setImageResource(R.drawable.ic_back);
        binding.homeImage.setImageResource(R.drawable.ic_home_selectd);
        binding.folderImage.setColorFilter(ContextCompat.getColor(this, R.color.white), android.graphics.PorterDuff.Mode.SRC_IN);
        binding.settingImage.setColorFilter(ContextCompat.getColor(this, R.color.white), android.graphics.PorterDuff.Mode.SRC_IN);
        binding.previousText.setTextColor(getResources().getColor(R.color.white));
        // binding.homeText.setTextColor(getResources().getColor(R.color.pinkSelector));
        binding.nextText.setTextColor(getResources().getColor(R.color.white));
        binding.folderText.setTextColor(getResources().getColor(R.color.white));
        binding.settingText.setTextColor(getResources().getColor(R.color.white));
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED
                && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, 45);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkPermission()) {

        } else {
            requestPermission();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 45) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            } else {
                requestPermission();
                Toast.makeText(this, getString(R.string.storage_permission_required_toast), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, new AdsCallback() {
            @Override
            public void onClose(boolean b) {
                finish();
            }
        });
    }
}