package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import android.os.Bundle;
import android.view.Window;

import com.video.downloader.app.videoplayer.alldownloader.fragment.ProgressFragment;
import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityProcessBinding;

import think.outside.the.box.handler.APIManager;

public class  ProcessActivity extends VPNConnection {

    ActivityProcessBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        setLightTheme(true);
        binding = ActivityProcessBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_view, new ProgressFragment()).commit();
    }

    @Override
    public void onBackPressed() {
        APIManager.showInter(this, true, b -> {
            finish();
        });
    }
}