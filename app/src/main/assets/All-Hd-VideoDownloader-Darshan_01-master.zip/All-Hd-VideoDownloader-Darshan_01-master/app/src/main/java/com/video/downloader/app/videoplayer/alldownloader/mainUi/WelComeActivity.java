package com.video.downloader.app.videoplayer.alldownloader.mainUi;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.video.downloader.app.videoplayer.alldownloader.R;
import com.video.downloader.app.videoplayer.alldownloader.databinding.ActivityWelComeBinding;

import think.outside.the.box.handler.APIManager;
import think.outside.the.box.vpn.VpnConnection;

public class WelComeActivity extends VPNConnection {

    ActivityWelComeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));
        setLightTheme(true);

        binding = ActivityWelComeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        APIManager.showBanner(binding.adNative);
        APIManager.showNative(binding.nativeAds);
        initListener();
    }

    private void initListener() {
        binding.safeBrowser.setOnClickListener(v -> {
            APIManager.showInter(this, false, b -> {
                startActivity(new Intent(this, BrowserMainActivity.class));
            });
        });
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, 45);
    }

    @Override
    public void onBackPressed() {
        APIManager.showRattingDialog(this, () -> {
            APIManager.showExitDialog(this);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 45) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                startActivity(new Intent(this, BrowserMainActivity.class));
            } else {
                requestPermission();
                Toast.makeText(this, getString(R.string.storage_permission_required_toast), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        VpnConnection.stopVpn();
        super.onDestroy();
    }
}

