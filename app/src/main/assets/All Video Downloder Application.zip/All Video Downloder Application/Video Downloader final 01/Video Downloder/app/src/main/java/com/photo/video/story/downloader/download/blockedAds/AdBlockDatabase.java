package com.photo.video.story.downloader.download.blockedAds;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {AdFilter.class}, version = 2, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class AdBlockDatabase extends RoomDatabase {
    public abstract AdFilterDao adFilterDao();

    private static AdBlockDatabase INSTANCE;

    public static AdBlockDatabase getAdBlockDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE =
                    Room.databaseBuilder(context.getApplicationContext(), AdBlockDatabase.class, "DATABASE").allowMainThreadQueries().build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}
