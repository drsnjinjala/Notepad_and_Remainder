package com.ads.mynew;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MySavePreference {
    public String USER_PREFS = "USER PREFS";
    public Editor prefEditor;
    public SharedPreferences appSharedPref;
    String Ad_Status = "Ad_Status";
    String Adstyle = "Adstyle";
    String AdstyleNative = "AdstyleNative";
    String AdstyleBanner = "AdstyleBanner";
    String Ad_Flag = "Ad_Flag";
    String Qureka_Flag = "Qureka_Flag";
    String Click_Flag = "Click_Flag";
    String Click_Count = "Click_Count";
    String Qureka_Link = "Qureka_Link";
    String Privacy_Policy = "Privacy_Policy";
    String backclickadstyle = "backclickadstyle";
    String Splash_Interstitial_Id = "Splash_Interstitial_Id";
    String Admob_Interstitial_Id1 = "Admob_Interstitial_Id1";
    String Admob_Native_Id1 = "Admob_Native_Id1";
    String Admob_Banner_Id1 = "Admob_Banner_Id1";
    String Admob_Rewarded_Id = "Admob_Rewarded_Id";
    String Facebook_Interstitial = "Facebook_Interstitial";
    String Facebook_Native = "Facebook_Native";
    String Facebook_Banner = "Facebook_Banner";
    String adbtcolor = "Adbtcolor";
    Context contexts;
    String nativecount = "nativecount";
    String splash_flag = "splash_flag";
    String Splash_OpenApp_Id = "Splash_OpenApp_Id";
    String textColor = "textColor";
    String backColor = "backColor";
    String backflag = "backflag";
    String backclick = "backclick";
    String native_type_list = "native_type_list";
    String native_type_othe = "native_type_othe";
    public static boolean isFullScreenShow = false;
    String nativeflag = "native";
    String bannerflag = "banner";
    String fullflag = "fullflag";
    String openflag = "openflag";
    String fbrewardid = "fbrewardid";
    String direct_link = "direct_link";
    String url_for_ads = "url_for_ads";

    public MySavePreference(Context context) {
        this.appSharedPref = context.getSharedPreferences(this.USER_PREFS, 0);
        this.prefEditor = this.appSharedPref.edit();
        contexts = context;
    }

    public boolean isConnected() {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) contexts.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.e("Connectivity Exception", e.getMessage());
        }
        return connected;
    }

    public String getDirect_link() {
        return this.appSharedPref.getString(this.direct_link, "");
    }

    public void setDirect_link(String str) {
        this.prefEditor.putString(this.direct_link, str).commit();
    }

    public String getUrl_for_ads() {
        return this.appSharedPref.getString(this.url_for_ads, "");
    }

    public void setUrl_for_ads(String str) {
        this.prefEditor.putString(this.url_for_ads, str).commit();
    }


    public String getFbrewardid() {
        return this.appSharedPref.getString(this.fbrewardid, "");
    }

    public void setFbrewardid(String fbrewardid) {
        this.prefEditor.putString(this.fbrewardid, fbrewardid).commit();
    }

    public String getBackclickadstyle() {
        return this.appSharedPref.getString(this.backclickadstyle, "");
    }

    public void setBackclickadstyle(String backclickadstyle) {
        this.prefEditor.putString(this.backclickadstyle, backclickadstyle).commit();
    }

    public String getNativecount() {
        return this.appSharedPref.getString(this.nativecount, "");
    }

    public void setNativecount(String str) {
        this.prefEditor.putString(this.nativecount, str).commit();
    }

    public String get_splash_flag() {
        return this.appSharedPref.getString(this.splash_flag, "");
    }

    public void set_splash_flag(String str) {
        this.prefEditor.putString(this.splash_flag, str).commit();
    }

    public String get_Splash_OpenApp_Id() {
        return this.appSharedPref.getString(this.Splash_OpenApp_Id, "");
    }

    public void set_Splash_OpenApp_Id(String str) {
        this.prefEditor.putString(this.Splash_OpenApp_Id, str).commit();
    }

    public void StoreAllDataFromJSON(String response) throws JSONException {
        JSONObject object = new JSONObject(response);

        Log.e("Akash", "1: " + response);

        JSONArray data = object.getJSONArray("Data");

        Log.e("Akash", "2: " + response);
        set_Ad_Flag(data.getJSONObject(0).getString("Adflag"));

        Log.e("Akash", "3: " + response);

        set_Adstyle(data.getJSONObject(0).getString("Adstyle"));
        set_Ad_Status(data.getJSONObject(0).getString("Adstatus"));
        set_Privacy_Policy(data.getJSONObject(0).getString("pp"));
        set_Qureka_Flag(data.getJSONObject(0).getString("qureka"));
        set_Qureka_Link(data.getJSONObject(0).getString("qureka-link"));

//        set_Splash_OpenApp_Id(data.getJSONObject(0).getString("admob-splash-open"));
//        set_Splash_Interstitial_Id(data.getJSONObject(0).getString("admob-splash"));
//        set_Admob_Interstitial_Id1(data.getJSONObject(0).getString("admob-full"));
//        set_Admob_Native_Id1(data.getJSONObject(0).getString("admob-native"));
//        set_Admob_Banner_Id1(data.getJSONObject(0).getString("admob-banner"));

        set_Splash_OpenApp_Id("ca-app-pub-3940256099942544/3419835294");
        set_Splash_Interstitial_Id("ca-app-pub-3940256099942544/1033173712");
        set_Admob_Interstitial_Id1("ca-app-pub-3940256099942544/1033173712");
        set_Admob_Native_Id1("ca-app-pub-3940256099942544/2247696110");
        set_Admob_Banner_Id1("ca-app-pub-3940256099942544/6300978111");

        set_Click_Flag(data.getJSONObject(0).getString("clickflag"));
        set_Click_Count(data.getJSONObject(0).getString("click"));
        setNativeflag(data.getJSONObject(0).optString("native", "on"));
        setBannerflag(data.getJSONObject(0).optString("banner", "on"));
        setOpenflag(data.getJSONObject(0).optString("open", "on"));
        setFullflag(data.getJSONObject(0).optString("full", "on"));
        set_splash_flag(data.getJSONObject(0).getString("splash"));
        set_Facebook_Interstitial(data.getJSONObject(0).getString("fb-full"));
        set_Facebook_Native(data.getJSONObject(0).getString("fb-native"));
        set_Facebook_Banner(data.getJSONObject(0).getString("fb-banner"));
        setAdbtcolor(data.getJSONObject(0).getString("adbtclr"));
        setBackflag(data.getJSONObject(0).getString("backflag"));
        setBackclick(data.getJSONObject(0).getString("backclick"));
        setNativeTypeList(data.getJSONObject(0).getString("native_type_list"));
        setNativeTypeOther(data.getJSONObject(0).getString("native_type_other"));
        setBackcolor(data.getJSONObject(0).optString("backcolor", "ffffff"));
        setTextColor(data.getJSONObject(0).optString("textcolor", "000000"));
        setNativecount(data.getJSONObject(0).optString("nativecount", "2"));
        setBackclickadstyle(data.getJSONObject(0).optString("backclickadstyle", "admob"));
        set_AdstyleNative(data.getJSONObject(0).optString("AdstyleNative", "admob"));
        setAdstyleBanner(data.getJSONObject(0).optString("AdstyleBanner", "admob"));
        set_Privacy_Policy(data.getJSONObject(0).getString("pp"));
        setDirect_link(data.getJSONObject(0).optString("direct_link"));
        setUrl_for_ads(data.getJSONObject(0).optString("url_for_ads"));
    }

    public String getFullflag() {
        return this.appSharedPref.getString(this.fullflag, "");
    }

    public void setFullflag(String str) {
        this.prefEditor.putString(this.fullflag, str).commit();
    }

    public String getOpenflag() {
        return this.appSharedPref.getString(this.openflag, "");
    }

    public void setOpenflag(String str) {
        this.prefEditor.putString(this.openflag, str).commit();
    }

    public String getNativeflag() {
        return this.appSharedPref.getString(this.nativeflag, "");
    }

    public void setNativeflag(String str) {
        this.prefEditor.putString(this.nativeflag, str).commit();
    }

    public String getBannerflag() {
        return this.appSharedPref.getString(this.bannerflag, "");
    }

    public void setBannerflag(String str) {
        this.prefEditor.putString(this.bannerflag, str).commit();
    }

    public String getBackflag() {
        return this.appSharedPref.getString(this.backflag, "");
    }

    public void setBackflag(String backflag) {
        this.prefEditor.putString(this.backflag, backflag).commit();
    }

    public String getBackclick() {
        return this.appSharedPref.getString(this.backclick, "");
    }

    public void setBackclick(String backclick) {
        this.prefEditor.putString(this.backclick, backclick).commit();
    }

    public void setNativeTypeOther(String type) {
        this.prefEditor.putString(this.native_type_othe, type).commit();
    }

    public String getNativeTypeList() {
        return this.appSharedPref.getString(this.native_type_list, "");
    }

    public void setNativeTypeList(String type) {
        this.prefEditor.putString(this.native_type_list, type).commit();
    }

    public String getNativeTypeOther() {
        return this.appSharedPref.getString(this.native_type_othe, "");
    }

    public String getBackColor() {
        return this.appSharedPref.getString(this.backColor, "");
    }

    public void setBackcolor(String str) {
        this.prefEditor.putString(this.backColor, str).commit();
    }

    public String getTextColor() {
        return this.appSharedPref.getString(this.textColor, "");
    }

    public void setTextColor(String str) {
        this.prefEditor.putString(this.textColor, str).commit();
    }

    public String get_Click_Flag() {
        return this.appSharedPref.getString(this.Click_Flag, "");
    }

    public void set_Click_Flag(String str) {
        this.prefEditor.putString(this.Click_Flag, str).commit();
    }

    public String get_Click_Count() {
        return this.appSharedPref.getString(this.Click_Count, "");
    }

    public void set_Click_Count(String str) {
        this.prefEditor.putString(this.Click_Count, str).commit();
    }

    public String get_Admob_Rewarded_Id() {
        return this.appSharedPref.getString(this.Admob_Rewarded_Id, "");
    }

    public void set_Admob_Rewarded_Id(String str) {
        this.prefEditor.putString(this.Admob_Rewarded_Id, str).commit();
    }

    public String get_Ad_Status() {
        return this.appSharedPref.getString(this.Ad_Status, "");
    }

    public void set_Ad_Status(String str) {
        this.prefEditor.putString(this.Ad_Status, str).commit();
    }

    public String get_Adstyle() {
        return this.appSharedPref.getString(this.Adstyle, "");
    }

    public void set_Adstyle(String str) {
        this.prefEditor.putString(this.Adstyle, str).commit();
    }

    public String getAdstyleBanner() {
        return this.appSharedPref.getString(this.AdstyleBanner, "");
    }

    public void setAdstyleBanner(String AdstyleBanner) {
        this.prefEditor.putString(this.AdstyleBanner, AdstyleBanner).commit();
    }

    public String get_AdstyleNative() {
        return this.appSharedPref.getString(this.AdstyleNative, "");
    }

    public void set_AdstyleNative(String str) {
        this.prefEditor.putString(this.AdstyleNative, str).commit();
    }

    public String get_Qureka_Flag() {
        return this.appSharedPref.getString(this.Qureka_Flag, "");
    }

    public void set_Qureka_Flag(String str) {
        this.prefEditor.putString(this.Qureka_Flag, str).commit();
    }

    public String get_Ad_Flag() {
        return this.appSharedPref.getString(this.Ad_Flag, "");
    }

    public void set_Ad_Flag(String str) {
        this.prefEditor.putString(this.Ad_Flag, str).commit();
    }

    public String get_Qureka_Link() {
        return this.appSharedPref.getString(this.Qureka_Link, "");
    }

    public void set_Qureka_Link(String str) {
        this.prefEditor.putString(this.Qureka_Link, str).commit();
    }

    public String get_Privacy_Policy() {
        return this.appSharedPref.getString(this.Privacy_Policy, "");
    }

    public void set_Privacy_Policy(String str) {
        this.prefEditor.putString(this.Privacy_Policy, str).commit();
    }

    public String get_Splash_Interstitial_Id() {
        return this.appSharedPref.getString(this.Splash_Interstitial_Id, "");
    }

    public void set_Splash_Interstitial_Id(String str) {
        this.prefEditor.putString(this.Splash_Interstitial_Id, str).commit();
    }

    public String get_Admob_Interstitial_Id1() {
        return this.appSharedPref.getString(this.Admob_Interstitial_Id1, "");
    }

    public void set_Admob_Interstitial_Id1(String str) {
        this.prefEditor.putString(this.Admob_Interstitial_Id1, str).commit();
    }

    public String get_Admob_Native_Id1() {
        return this.appSharedPref.getString(this.Admob_Native_Id1, "");
    }

    public void set_Admob_Native_Id1(String str) {
        this.prefEditor.putString(this.Admob_Native_Id1, str).commit();
    }

    public String get_Admob_Banner_Id1() {
        return this.appSharedPref.getString(this.Admob_Banner_Id1, "");
    }

    public void set_Admob_Banner_Id1(String str) {
        this.prefEditor.putString(this.Admob_Banner_Id1, str).commit();
    }

    public String get_Facebook_Interstitial() {
        return this.appSharedPref.getString(this.Facebook_Interstitial, "");
    }

    public void set_Facebook_Interstitial(String str) {
        this.prefEditor.putString(this.Facebook_Interstitial, str).commit();
    }

    public String get_Facebook_Native() {
        return this.appSharedPref.getString(this.Facebook_Native, "");
    }

    public void set_Facebook_Native(String str) {
        this.prefEditor.putString(this.Facebook_Native, str).commit();
    }

    public String get_Facebook_Banner() {
        return this.appSharedPref.getString(this.Facebook_Banner, "");
    }

    public void set_Facebook_Banner(String str) {
        this.prefEditor.putString(this.Facebook_Banner, str).commit();
    }

    public String getAdbtcolor() {
        return this.appSharedPref.getString(this.adbtcolor, "");
    }

    public void setAdbtcolor(String str) {
        this.prefEditor.putString(this.adbtcolor, str).commit();
    }
}