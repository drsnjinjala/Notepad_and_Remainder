package com.photo.video.story.downloader.Utils;

@SuppressWarnings("All")
public class Glob {
    public static boolean videoDownloader = false;
    public static String url11 = "";
}
