package com.photo.video.story.downloader.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.mynew.InterstitialAdLoad;
import com.bumptech.glide.Glide;
import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.databinding.ItemsFileViewBinding;

import java.io.File;
import java.util.ArrayList;

@SuppressWarnings("All")
public class FileListAdapter extends RecyclerView.Adapter<FileListAdapter.ViewHolder> {
    private Context context;
    private ArrayList<File> fileArrayList;
    private LayoutInflater layoutInflater;

    public FileListAdapter(Context context, ArrayList<File> files) {
        this.context = context;
        this.fileArrayList = files;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemsFileViewBinding itemBinding = ItemsFileViewBinding.inflate(LayoutInflater.from(viewGroup.getContext()));
        return new ViewHolder(itemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        File fileItem = fileArrayList.get(i);
        try {
            String extension = fileItem.getName().substring(fileItem.getName().lastIndexOf("."));
            if (extension.equals(".mp4")) {
                viewHolder.mbinding.ivPlay.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mbinding.ivPlay.setVisibility(View.GONE);
            }

            Glide.with(context)
                    .load(fileItem.getPath())
                    .placeholder(R.drawable.no_data_image)
                    .into(viewHolder.mbinding.pc);
        } catch (Exception ex) {
        }

        viewHolder.mbinding.rlMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterstitialAdLoad.ShowfullAd((Activity) context, () -> {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.parse(fileItem.getPath()), "video/*");
                    context.startActivity(intent);
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return fileArrayList == null ? 0 : fileArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemsFileViewBinding mbinding;

        public ViewHolder(ItemsFileViewBinding mbinding) {
            super(mbinding.getRoot());
            this.mbinding = mbinding;
        }
    }
}