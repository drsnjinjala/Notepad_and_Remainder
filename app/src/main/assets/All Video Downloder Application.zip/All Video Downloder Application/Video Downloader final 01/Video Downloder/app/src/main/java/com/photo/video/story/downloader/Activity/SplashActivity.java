package com.photo.video.story.downloader.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigException;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigFetchThrottledException;
import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.Utils.TinyDB;
import com.ads.mynew.MySavePreference;
import com.ads.mynew.SplashAdmobAds;

import org.json.JSONException;

@SuppressWarnings("All")
public class SplashActivity extends AppCompatActivity {
    private FirebaseRemoteConfig firebaseRemoteConfig;
    MySavePreference pref;
    TinyDB tinyDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        pref = new MySavePreference(this);
        tinyDB = new TinyDB(this);
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        fetchRemoteConfigValues();
    }
    private void fetchRemoteConfigValues() {
        firebaseRemoteConfig.fetchAndActivate()
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        String jsonString = firebaseRemoteConfig.getString("Downloader");
                        Log.e("jsonString >> ", jsonString);
                        try {
                            pref.StoreAllDataFromJSON(jsonString);
                            NextCall();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Exception exception = task.getException();
                        if (exception instanceof FirebaseRemoteConfigFetchThrottledException) {
                            exception.printStackTrace();
                        } else if (exception instanceof FirebaseRemoteConfigException) {
                            exception.printStackTrace();
                        }
                    }
                });
    }
    private void NextCall() {
        if (pref.get_Ad_Status().equalsIgnoreCase("on")) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    SplashAdmobAds.startAdLoading(SplashActivity.this, pref, toGetIntent());
                }
            }, 3000);
        } else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(toGetIntent());
                    finish();
                }
            }, 3000);
        }
    }
    private Intent toGetIntent() {
        Intent intent;
        if (!(tinyDB.getBoolean("isIntro"))) {
            tinyDB.putBoolean("isIntro", true);
            intent = new Intent(this, WelcomeActivity.class);
        } else {
            intent = new Intent(this, MainActivity.class);
        }
        return intent;
    }

    @Override
    public void onBackPressed() {
    }
}