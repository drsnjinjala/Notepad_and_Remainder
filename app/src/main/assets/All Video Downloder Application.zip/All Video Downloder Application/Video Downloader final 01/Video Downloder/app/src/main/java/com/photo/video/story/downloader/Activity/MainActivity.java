package com.photo.video.story.downloader.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.ads.mynew.InterstitialAdLoad;
import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.adapter.MyAdapter;
import com.photo.video.story.downloader.databinding.ActivityMainBinding;

import java.io.File;

@SuppressWarnings("All")
public class MainActivity extends BaseActivity {
    private ActivityMainBinding binding;

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void createDirectoryInScopedStorage(Context context, String directoryName) {
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), directoryName);
        if (!directory.exists()) {
            boolean created = directory.mkdirs();
            if (created) {
                Toast.makeText(context, "Directory was successfully created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Directory creation failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static String convertBytes(long bytes) {
        if (bytes < 1024) {
            return bytes + " Bytes";
        } else if (bytes < 1024 * 1024) {
            double kb = (double) bytes / 1024;
            return String.format("%.2f KB", kb);
        } else {
            double mb = (double) bytes / (1024 * 1024);
            return String.format("%.2f MB", mb);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ClickEvent();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            createDirectoryInScopedStorage(this, "Video Downloder");
            Log.d("~~~", "onCreate: 10 > ");
        } else {
            createDirectoryInScopedStorage(this, "Video Downloder");
            Log.d("~~~", "onCreate: 11 + ");
        }

        final MyAdapter adapter = new MyAdapter(this, getSupportFragmentManager(), 3);
        binding.viewPager.setAdapter(adapter);
        binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    unselected();
                    binding.imgTab.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.tvColor), android.graphics.PorterDuff.Mode.SRC_IN);
                    binding.TvTab.setTextColor(getResources().getColor(R.color.tvColor));
                } else if (position == 1) {
                    unselected();
                    binding.imgProgress.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.tvColor), android.graphics.PorterDuff.Mode.SRC_IN);
                    binding.TvProgress.setTextColor(getResources().getColor(R.color.tvColor));
                } else if (position == 2) {
                    unselected();
                    binding.imgFinished.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.tvColor), android.graphics.PorterDuff.Mode.SRC_IN);
                    binding.TvFinished.setTextColor(getResources().getColor(R.color.tvColor));
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    private void ClickEvent() {
        binding.BtnTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 InterstitialAdLoad.ShowfullAd(MainActivity.this, () -> {
                    binding.viewPager.setCurrentItem(0);
                });
            }
        });
        binding.Btnprogress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 InterstitialAdLoad.ShowfullAd(MainActivity.this, () -> {
                    binding.viewPager.setCurrentItem(1);
                });

            }
        });
        binding.Btnfinished.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 InterstitialAdLoad.ShowfullAd(MainActivity.this, () -> {
                    binding.viewPager.setCurrentItem(2);
                });

            }
        });
    }

    private void unselected() {
        binding.imgTab.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.tabText), android.graphics.PorterDuff.Mode.SRC_IN);
        binding.TvTab.setTextColor(getResources().getColor(R.color.tabText));
        binding.imgProgress.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.tabText), android.graphics.PorterDuff.Mode.SRC_IN);
        binding.TvProgress.setTextColor(getResources().getColor(R.color.tabText));
        binding.imgFinished.setColorFilter(ContextCompat.getColor(MainActivity.this, R.color.tabText), android.graphics.PorterDuff.Mode.SRC_IN);
        binding.TvFinished.setTextColor(getResources().getColor(R.color.tabText));
    }

    @Override
    public void onBackPressed() {
        if (binding.viewPager.getCurrentItem() != 0) {
            binding.viewPager.setCurrentItem(binding.viewPager.getCurrentItem() - 1, false);
        } else {
            new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Closing Activity").setMessage("Are you sure you want to close this activity?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finishAffinity();
                }
            }).setNegativeButton("No", null).show();
        }
    }


}