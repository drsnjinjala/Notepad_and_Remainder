plugins {
    id("com.android.application") version "8.1.1" apply false
    id("com.google.gms.google-services") version "4.3.14" apply false
    id ("com.google.firebase.crashlytics")  version "2.9.5" apply false
}