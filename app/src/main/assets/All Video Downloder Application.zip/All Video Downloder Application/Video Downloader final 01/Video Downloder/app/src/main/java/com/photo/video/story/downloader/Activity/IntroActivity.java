package com.photo.video.story.downloader.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.photo.video.story.downloader.adapter.SliderPagerAdapter;
import com.photo.video.story.downloader.databinding.ActivityIntroBinding;

@SuppressWarnings("All")
public class IntroActivity extends BaseActivity {
    private SliderPagerAdapter adapter;
    private ActivityIntroBinding binding;
    private boolean isNext = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIntroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adapter = new SliderPagerAdapter(getSupportFragmentManager(),
                FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        binding.viewPager.setAdapter(adapter);

        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.viewPager.getCurrentItem() < adapter.getCount()) {
                    binding.viewPager.setCurrentItem(binding.viewPager.getCurrentItem() + 1);
                    isNext = false;
                }
                if (binding.viewPager.getCurrentItem() == 2) {
                    binding.button2.setVisibility(View.VISIBLE);
                    binding.button.setVisibility(View.GONE);
                } else {
                    binding.button.setVisibility(View.VISIBLE);
                    binding.button2.setVisibility(View.GONE);
                }
                Log.d("TAG", "viewPager: " + (binding.viewPager.getCurrentItem()));
                Log.d("TAG", "adapter: " + (adapter.getCount()));
//                if (isNext) {
//                    startActivity(new Intent(IntroActivity.this, StartActivity.class));
//                }
//                if ((binding.viewPager.getCurrentItem() == 4)) {
//                    isNext = true;
//                    //  startActivity(new Intent(IntroActivity.this, StartActivity.class));
//                }
            }
        });

        binding.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.viewPager.getCurrentItem() == 2) {
                    startActivity(new Intent(IntroActivity.this, StartActivity.class));
                }
            }
        });

        binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 2) {
                    binding.button2.setVisibility(View.VISIBLE);
                    binding.button.setVisibility(View.GONE);
                } else {
                    binding.button.setVisibility(View.VISIBLE);
                    binding.button2.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }
}
