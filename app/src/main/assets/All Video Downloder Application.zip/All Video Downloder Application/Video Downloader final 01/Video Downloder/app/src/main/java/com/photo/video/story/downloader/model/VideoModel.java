package com.photo.video.story.downloader.model;

public class VideoModel {
    private String link, size, type, name, page, website;

    public VideoModel(String link, String size, String type, String name, String page, String website) {
        this.link = link;
        this.size = size;
        this.type = type;
        this.name = name;
        this.page = page;
        this.website = website;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }
}
