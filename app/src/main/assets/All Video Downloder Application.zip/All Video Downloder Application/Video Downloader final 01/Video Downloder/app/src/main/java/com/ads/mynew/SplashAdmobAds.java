package com.ads.mynew;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class SplashAdmobAds {

    public static void CallOpenAd(MySavePreference preference, Activity activity, Intent intent) {
        String string = preference.get_Splash_OpenApp_Id();
        if (MySavePreference.isFullScreenShow) {
            return;
        }
        try {
            AppOpenAd.AppOpenAdLoadCallback loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                    super.onAdLoaded(appOpenAd);
                    FullScreenContentCallback r0 = new FullScreenContentCallback() {
                        @Override
                        public void onAdShowedFullScreenContent() {
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            activity.startActivity(intent);
                            activity.finish();
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                            activity.startActivity(intent);
                            activity.finish();
                        }
                    };
                    appOpenAd.show(activity);
                    appOpenAd.setFullScreenContentCallback(r0);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    activity.startActivity(intent);
                    activity.finish();
                }
            };
            AppOpenAd.load(activity, string, new AdRequest.Builder().build(), 1, loadCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void startAdLoading(Activity activity, MySavePreference preference, Intent intent) {
        MyApplication.loadAds(initializationStatus -> {
            if (preference.get_splash_flag().equalsIgnoreCase("open")) {
                if (preference.getOpenflag().equalsIgnoreCase("on")) {
                    CallOpenAd(preference, activity, intent);
                } else {
                    activity.startActivity(intent);
                }
            } else {
                if (preference.getFullflag().equalsIgnoreCase("on")) {
                    new Handler().postDelayed(() -> new InterstitialAdSplash().Show_Ads(activity, intent, true), 1000);
                } else {
                    new Handler().postDelayed(() -> activity.startActivity(intent), 1000);
                }
            }
        });
    }

    public static void Native_Banner_Count(Activity activity, FrameLayout viewGroup) {
        MySavePreference preference = new MySavePreference(activity);
        int nativecount = Integer.parseInt(preference.getNativecount());
        if (MyStaticMethod.NativeCountIncr == nativecount) {
            MyStaticMethod.NativeCountIncr = 0;
        }
        if (MyStaticMethod.NativeCountIncr % nativecount == 0) {
            MyStaticMethod.NativeCountIncr++;
            NativeAdsPreload1.getInstance(activity).Native_Banner_Ads(activity, viewGroup);
        } else {
            MyStaticMethod.NativeCountIncr++;
        }
    }

    public static void Native_Large_Count(Activity activity, FrameLayout viewGroup, boolean isList) {
        MySavePreference preference = new MySavePreference(activity);
        int nativecount = Integer.parseInt(preference.getNativecount());
        if (MyStaticMethod.NativeCountIncr == nativecount) {
            MyStaticMethod.NativeCountIncr = 0;
        }
        if (MyStaticMethod.NativeCountIncr % nativecount == 0) {
            MyStaticMethod.NativeCountIncr++;
            NativeAdsPreload1.getInstance(activity).addNativeAd(viewGroup, isList);
        } else {
            MyStaticMethod.NativeCountIncr++;
        }
    }

}
