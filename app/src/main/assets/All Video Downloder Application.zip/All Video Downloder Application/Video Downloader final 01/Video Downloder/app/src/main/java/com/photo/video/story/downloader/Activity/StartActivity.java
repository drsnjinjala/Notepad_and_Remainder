package com.photo.video.story.downloader.Activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.databinding.ActivityStartBinding;
import com.ads.mynew.NativeAdsPreload1;

@SuppressWarnings("All")
public class StartActivity extends BaseActivity {
    private ActivityStartBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.stutasBar));
        binding = ActivityStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        NativeAdsPreload1.getInstance(this).addNativeAd(binding.nativeAds,false);

        ClickEvent();
    }

    private void ClickEvent() {
        binding.BtnRatting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAppRating();
            }
        });

        binding.BtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GotoNext(StartActivity.this, MainActivity.class);
            }
        });
        binding.BtnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareApp();
            }
        });
    }

    private void openAppRating() {
        try {
            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(goToMarket);
        }
    }

    private void shareApp() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String shareSubject = "Check out this awesome app!";
        String shareText = "I found this amazing app that you might like. Download it from the Play Store: https://play.google.com/store/apps/details?id=" + getPackageName();
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

}