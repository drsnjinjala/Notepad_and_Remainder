package com.photo.video.story.downloader.Activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.ads.mynew.MySavePreference;
import com.ads.mynew.NativeAdmobAds;
import com.photo.video.story.downloader.databinding.ActivitySettingBinding;

@SuppressWarnings("All")
public class SettingActivity extends BaseActivity {
    private ActivitySettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ClickEvent();
        new NativeAdmobAds(this).Adaptive_Banner(binding.bannerRelative);
    }

    private void ClickEvent() {
        binding.imBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.btnFeedBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent feedbackEmail = new Intent(Intent.ACTION_SEND);
                feedbackEmail.setType("text/email");
                feedbackEmail.putExtra(Intent.EXTRA_EMAIL, new String[]{"elisioninfotech@gmail.com"});
                feedbackEmail.putExtra(Intent.EXTRA_SUBJECT, "Feedback");
                startActivity(Intent.createChooser(feedbackEmail, "Send Feedback:"));
            }
        });
    }

    public void howTodownload(View view) {
        GotoNext(SettingActivity.this, HowtoDownload.class);
    }

    public void browserHistoryClear(View view) {
        Toast.makeText(this, "Browser History Successfully Deleted", Toast.LENGTH_SHORT).show();
    }

    public void privacypolicy(View view) {
        MySavePreference preference = new MySavePreference(this);
        final Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(preference.get_Privacy_Policy()));
        startActivity(intent);
    }


}