package com.ads.mynew;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.photo.video.story.downloader.R;

import java.util.Random;

public class InterstitialQurekaPred {

    public static void Show_Qureka_Predchamp_Ads(Activity source_class, AdCloseListeners adCloseListener) {
        MySavePreference preference = new MySavePreference(source_class);
        if (preference.get_Ad_Status().equalsIgnoreCase("on")) {
            if (preference.get_Qureka_Flag().equalsIgnoreCase("qureka")) {
                MySavePreference.isFullScreenShow = true;
                final Dialog dialog = new Dialog(source_class, R.style.transparent_dialog);
                dialog.setContentView(R.layout.custome_interstitial);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                Random r = new Random();
                int i1 = r.nextInt(4 + 1);
                Glide.with(source_class).load(MyStaticMethod.qureka_icon[i1]).into(((ImageView) dialog.findViewById(R.id.img_icon)));
                Glide.with(source_class).load(MyStaticMethod.qureka_native[i1]).into(((ImageView) dialog.findViewById(R.id.img_banner)));
                ((TextView) dialog.findViewById(R.id.txt_main_title)).setText("Qureka Lite/Play Game");
                ((TextView) dialog.findViewById(R.id.txt_title)).setText(MyStaticMethod.qureka_header[i1]);
                ((TextView) dialog.findViewById(R.id.txt_description)).setText(MyStaticMethod.qureka_description[i1]);
                dialog.setOnDismissListener(dialog1 -> {
                    MySavePreference.isFullScreenShow = false;
                    if (adCloseListener != null) {
                        adCloseListener.onAdClosed();
                    }
                });
                dialog.findViewById(R.id.img_close).setOnClickListener(v -> dialog.dismiss());
                dialog.findViewById(R.id.btn_install).setOnClickListener(v -> MyStaticMethod.Open_Qureka(source_class));
                dialog.show();
            } else if (preference.get_Qureka_Flag().equalsIgnoreCase("predchamp")) {
                MySavePreference.isFullScreenShow = true;
                final Dialog dialog = new Dialog(source_class, R.style.transparent_dialog);
                dialog.setContentView(R.layout.custome_interstitial);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                Random r = new Random();
                int i1 = r.nextInt(4 + 1);
                Glide.with(source_class).load(MyStaticMethod.predchamp_icon[i1]).into(((ImageView) dialog.findViewById(R.id.img_icon)));
                Glide.with(source_class).load(MyStaticMethod.predchamp_native[i1]).into(((ImageView) dialog.findViewById(R.id.img_banner)));
                ((TextView) dialog.findViewById(R.id.txt_main_title)).setText("Predchamp/Play Game");
                ((TextView) dialog.findViewById(R.id.txt_title)).setText(MyStaticMethod.predchamp_header[i1]);
                ((TextView) dialog.findViewById(R.id.txt_description)).setText(MyStaticMethod.predchamp_description[i1]);
                dialog.setOnDismissListener(dialog12 -> {
                    MySavePreference.isFullScreenShow = false;
                    if (adCloseListener != null) {
                        adCloseListener.onAdClosed();
                    }
                });
                dialog.findViewById(R.id.img_close).setOnClickListener(v -> dialog.dismiss());
                dialog.findViewById(R.id.btn_install).setOnClickListener(v -> MyStaticMethod.Open_Qureka(source_class));
                dialog.show();
            } else {
                if (adCloseListener != null) {
                    adCloseListener.onAdClosed();
                }
            }
        } else {
            if (adCloseListener != null) {
                adCloseListener.onAdClosed();
            }
        }
    }

    public static void Show_Qureka_Predchamp_Ads(Activity source_class) {
        MySavePreference preference = new MySavePreference(source_class);
        if (preference.get_Ad_Status().equalsIgnoreCase("on")) {
            if (preference.get_Qureka_Flag().equalsIgnoreCase("qureka")) {
                MySavePreference.isFullScreenShow = true;
                Dialog dialog = new Dialog(source_class, R.style.transparent_dialog);
                dialog.setContentView(R.layout.custome_interstitial);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                Random r = new Random();
                int i1 = r.nextInt(4 + 1);
                Glide.with(source_class).load(MyStaticMethod.qureka_icon[i1]).into(((ImageView) dialog.findViewById(R.id.img_icon)));
                Glide.with(source_class).load(MyStaticMethod.qureka_native[i1]).into(((ImageView) dialog.findViewById(R.id.img_banner)));
                ((TextView) dialog.findViewById(R.id.txt_main_title)).setText("Qureka Lite/Play Game");
                ((TextView) dialog.findViewById(R.id.txt_title)).setText(MyStaticMethod.qureka_header[i1]);
                ((TextView) dialog.findViewById(R.id.txt_description)).setText(MyStaticMethod.qureka_description[i1]);
                dialog.setOnDismissListener(dialog12 -> {
                    MySavePreference.isFullScreenShow = false;
                });
                dialog.findViewById(R.id.img_close).setOnClickListener(v -> dialog.dismiss());
                dialog.findViewById(R.id.btn_install).setOnClickListener(v -> MyStaticMethod.Open_Qureka(source_class));
                dialog.show();
            } else if (preference.get_Qureka_Flag().equalsIgnoreCase("predchamp")) {
                MySavePreference.isFullScreenShow = true;
                Dialog dialog = new Dialog(source_class, R.style.transparent_dialog);
                dialog.setContentView(R.layout.custome_interstitial);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                Random r = new Random();
                int i1 = r.nextInt(4 + 1);
                Glide.with(source_class).load(MyStaticMethod.predchamp_icon[i1]).into(((ImageView) dialog.findViewById(R.id.img_icon)));
                Glide.with(source_class).load(MyStaticMethod.predchamp_native[i1]).into(((ImageView) dialog.findViewById(R.id.img_banner)));
                ((TextView) dialog.findViewById(R.id.txt_main_title)).setText("Predchamp/Play Game");
                ((TextView) dialog.findViewById(R.id.txt_title)).setText(MyStaticMethod.predchamp_header[i1]);
                ((TextView) dialog.findViewById(R.id.txt_description)).setText(MyStaticMethod.predchamp_description[i1]);
                dialog.setOnDismissListener(dialog1 -> {
                    MySavePreference.isFullScreenShow = false;
                });
                dialog.findViewById(R.id.img_close).setOnClickListener(v -> dialog.dismiss());
                dialog.findViewById(R.id.btn_install).setOnClickListener(v -> MyStaticMethod.Open_Qureka(source_class));
                dialog.show();
            }
        }
    }
}
