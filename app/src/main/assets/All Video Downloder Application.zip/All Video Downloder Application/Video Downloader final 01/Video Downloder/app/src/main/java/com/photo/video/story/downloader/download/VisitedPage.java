

package com.photo.video.story.downloader.download;

public class VisitedPage {
    public String title;
    public String link;
}
