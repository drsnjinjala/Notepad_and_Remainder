package com.photo.video.story.downloader.fragment;


import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_MEDIA_AUDIO;
import static android.Manifest.permission.READ_MEDIA_IMAGES;
import static android.Manifest.permission.READ_MEDIA_VIDEO;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.ads.mynew.InterstitialAdLoad;
import com.ads.mynew.MySavePreference;
import com.ads.mynew.NativeAdsPreload1;
import com.photo.video.story.downloader.Activity.BaseActivity;
import com.photo.video.story.downloader.Activity.HowtoDownload;
import com.photo.video.story.downloader.Activity.PlayMusicActivity;
import com.photo.video.story.downloader.Activity.SettingActivity;
import com.photo.video.story.downloader.Activity.WhatsapppActivity;
import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.Utils.Utility;
import com.photo.video.story.downloader.databinding.FragmentTabBinding;
import com.photo.video.story.downloader.download.browser.BrowsingActivity;

@SuppressWarnings("All")
public class TabFragment extends Fragment {
    private String checkButtonClick = "0";
    private FragmentTabBinding binding;
    private static final int BELOW_ANDROID_13 = 101;
    private static final int ABOVE_ANDROID_13 = 202;
    private static final int REQUEST_PERMISSIONS = 1234;
    private static final String[] PERMISSIONS = {READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    private Context context;
    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {
            Intent data = result.getData();
            assert data != null;
            Log.d("HEY: ", data.getData().toString());
            context.getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    });

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTabBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        context = requireContext();
        clickEvent();
        NativeAdsPreload1.getInstance(requireActivity()).addNativeAd(binding.nativeAd, false);
        return view;
    }
    private void clickEvent() {
        binding.popupMenu.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(requireContext(), binding.popupMenu);
                popupMenu.getMenuInflater().inflate(R.menu.main_menu, popupMenu.getMenu());
                popupMenu.setForceShowIcon(true);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        if (menuItem.getTitle().equals("Check for update")) {
                            Toast.makeText(requireContext(), "App is already updated", Toast.LENGTH_SHORT).show();
                        }
                        if (menuItem.getTitle().equals("Copy Link")) {
                            TextCopy();
                        }
                        if (menuItem.getTitle().equals("Rate Us")) {
                            openAppRating();
                        }
                        if (menuItem.getTitle().equals("Share App")) {
                            shareApp();
                        }
                        if (menuItem.getTitle().equals("Privacy Policy")) {
                            MySavePreference preference = new MySavePreference(requireContext());
                            final Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(preference.get_Privacy_Policy()));
                            startActivity(intent);

                        }
                        if (menuItem.getTitle().equals("More Apps (AD)")) {
                            openMoreAppDialog();

                        }
                        if (menuItem.getTitle().equals("Setting")) {

                            BaseActivity.GotoNext(requireActivity(), SettingActivity.class);
                        }
                        return true;
                    }
                });
                popupMenu.show();
            }
        });
        binding.btnadsremove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.icSetting.performClick();
            }
        });

        binding.icSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BaseActivity.GotoNext(requireActivity(), SettingActivity.class);
            }
        });


        binding.searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!binding.editSearch.getText().toString().trim().equals("")) {
                    binding.editSearch.setFocusable(true);
                    binding.editSearch.setFocusableInTouchMode(true);
                    binding.editSearch.requestFocus();
                    Utility.hideSoftKeyboard(getActivity(), binding.editSearch.getWindowToken());

                    setIntentActivity(binding.editSearch.getText().toString());
                } else {
                    binding.editSearch.setError("It can't be Empty");
                }
            }
        });


        binding.btnrigtone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButtonClick = "1";
                if (checkPermissionGranted()) {
                    nextScreen();
                } else {
                    takePermission();
                }
            }
        });
        binding.btnvimeo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButtonClick = "2";
                if (checkPermissionGranted()) {
                    nextScreen();
                } else {
                    takePermission();
                }

            }
        });
        binding.btndailymotion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButtonClick = "3";
                if (checkPermissionGranted()) {
                    nextScreen();
                } else {
                    takePermission();
                }

            }
        });
        binding.btnInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButtonClick = "4";
                if (checkPermissionGranted()) {
                    nextScreen();
                } else {
                    takePermission();
                }


            }
        });
        binding.btnfacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButtonClick = "5";
                if (checkPermissionGranted()) {
                    nextScreen();
                } else {
                    takePermission();
                }

            }
        });
        binding.btntwitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButtonClick = "6";
                if (checkPermissionGranted()) {
                    nextScreen();
                } else {
                    takePermission();
                }
            }
        });
        binding.BtnHowToDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBottomDialog();
            }
        });
        binding.BtnWhatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!arePermissionDenied()) {
                    nextActivity();
                    return;
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && arePermissionDenied()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        requestPermissionQ();
                        return;
                    }
                    requestPermissions(PERMISSIONS, REQUEST_PERMISSIONS);
                }
            }
        });
    }

    private void nextScreen() {
        if (checkButtonClick.equals("1")) {
            BaseActivity.GotoNext(requireActivity(), PlayMusicActivity.class);
        } else if (checkButtonClick.equals("2")) {
            setIntentActivity("https://vimeo.com/watch");
        } else if (checkButtonClick.equals("3")) {
            setIntentActivity("https://www.dailymotion.com/");
        } else if (checkButtonClick.equals("4")) {
            setIntentActivity("https://www.instagram.com");
        } else if (checkButtonClick.equals("5")) {
            setIntentActivity("https://m.facebook.com/");
        } else if (checkButtonClick.equals("6")) {
            setIntentActivity("https://twitter.com/aajtak");
        }
    }

    private void openMoreAppDialog() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(android.net.Uri.parse("market://search?q=pub:" + getActivity().getPackageName()));
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(intent);
        }
    }



    private void TextCopy() {
        ClipboardManager clipboard = (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("label", binding.editSearch.getText());
        clipboard.setPrimaryClip(clip);
        Toast.makeText(requireContext(), "Text copied to clipboard", Toast.LENGTH_SHORT).show();
    }

    private void nextActivity() {
        BaseActivity.GotoNext(requireActivity(), WhatsapppActivity.class);
    }

    private void showBottomDialog() {
        final Dialog dialog = new Dialog(requireContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_exit_custom);
        TextView BtnView = dialog.findViewById(R.id.BtnView);
        ImageView cancelButton = dialog.findViewById(R.id.Btnclose);

        BtnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.GotoNext(requireActivity(), HowtoDownload.class);
                dialog.dismiss();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }

    private boolean arePermissionDenied() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return requireActivity().getContentResolver().getPersistedUriPermissions().size() <= 0;
        }
        for (String permissions : PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(requireActivity().getApplicationContext(), permissions) != PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void requestPermissionQ() {
        StorageManager sm = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
        Intent intent = sm.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        String startDir = "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses";
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        scheme += "%3A" + startDir;
        uri = Uri.parse(scheme);
        Log.d("URI", uri.toString());
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        activityResultLauncher.launch(intent);
    }

    public void setIntentActivity(String data) {
        if (BaseActivity.isNetworkAvailable(getActivity())) {
            InterstitialAdLoad.ShowfullAd(requireActivity(), () -> {
                Intent intent = new Intent(getActivity(), BrowsingActivity.class);
                intent.setData(Uri.parse(data));
                startActivity(intent);
            });
        } else {
            Toast.makeText(getActivity(), R.string.no_net_conn, Toast.LENGTH_SHORT).show();
        }
    }

    private void openAppRating() {
        try {
            Uri uri = Uri.parse("market://details?id=" + getActivity().getPackageName());
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=" + getActivity().getPackageName());
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(goToMarket);
        }
    }

    private void shareApp() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String shareSubject = "Check out this awesome app!";
        String shareText = "I found this amazing app that you might like. Download it from the Play Store: https://play.google.com/store/apps/details?id=" + getActivity().getPackageName();
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

    public boolean checkPermissionGranted() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {

            int read_external_storage = ContextCompat.checkSelfPermission(requireActivity(), READ_EXTERNAL_STORAGE);

            return read_external_storage == PackageManager.PERMISSION_GRANTED;

        } else {

            int read_media_images = ContextCompat.checkSelfPermission(requireActivity(), READ_MEDIA_IMAGES);
            int read_media_audio = ContextCompat.checkSelfPermission(requireActivity(), READ_MEDIA_AUDIO);
            int read_media_video = ContextCompat.checkSelfPermission(requireActivity(), READ_MEDIA_VIDEO);
            int post_notifications = ContextCompat.checkSelfPermission(requireActivity(), POST_NOTIFICATIONS);

            return read_media_images == PackageManager.PERMISSION_GRANTED
                    && read_media_audio == PackageManager.PERMISSION_GRANTED
                    && read_media_video == PackageManager.PERMISSION_GRANTED
                    && post_notifications == PackageManager.PERMISSION_GRANTED;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {

            case BELOW_ANDROID_13:
                boolean gotPermission1 = grantResults.length > 0;

                for (int result : grantResults) {
                    gotPermission1 &= result == PackageManager.PERMISSION_GRANTED;
                }

                if (gotPermission1) {
                    nextScreen();
                } else {
                    Toast.makeText(requireActivity(), "Permission Denied", Toast.LENGTH_SHORT).show();
                }
                break;

            case ABOVE_ANDROID_13:
                boolean gotPermission2 = grantResults.length > 0;

                for (int result : grantResults) {
                    gotPermission2 &= result == PackageManager.PERMISSION_GRANTED;
                }

                if (gotPermission2) {
                    nextScreen();
                } else {
                    Toast.makeText(requireActivity(), "Permission Denied", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void takePermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {

            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{
                            READ_EXTERNAL_STORAGE}, BELOW_ANDROID_13);
        } else {

            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{
                            READ_MEDIA_IMAGES,
                            READ_MEDIA_AUDIO,
                            READ_MEDIA_VIDEO,
                            POST_NOTIFICATIONS}, ABOVE_ANDROID_13);
        }
    }
}


