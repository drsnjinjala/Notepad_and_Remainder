package com.photo.video.story.downloader.Utils;

import android.app.DownloadManager;
import android.content.Intent;

import com.intuit.sdp.BuildConfig;
import com.ads.mynew.MyApplication;

@SuppressWarnings("All")
public class PlayApp extends MyApplication {

    public static PlayApp instance;
    public Intent downloadService;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
         downloadService = new Intent(getApplicationContext(), DownloadManager.class);
        if (BuildConfig.DEBUG) {

        }

    }

    public static PlayApp getInstance() {
        return instance;
    }

    public Intent getDownloadService() {
        return downloadService;
    }

}

