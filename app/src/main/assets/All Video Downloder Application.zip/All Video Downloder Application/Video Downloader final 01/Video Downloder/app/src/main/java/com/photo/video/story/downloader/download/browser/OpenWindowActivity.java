package com.photo.video.story.downloader.download.browser;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.databinding.ActivityOpenWindowBinding;
import com.photo.video.story.downloader.databinding.DialogDeleteBinding;

import java.util.List;

@SuppressWarnings("All")
public class OpenWindowActivity extends AppCompatActivity {

    ActivityOpenWindowBinding openWindowBinding;
    BrowserManager browserManager;
    private List<BrowserWindow> windows;
    boolean aBoolean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.white));

        openWindowBinding = ActivityOpenWindowBinding.inflate(getLayoutInflater());
        setContentView(openWindowBinding.getRoot());

        browserManager = BrowserWindow.browserManager;

        windows = browserManager.getAllWindow();

        if (windows.size() == 0) {
            openWindowBinding.noDataText.setVisibility(View.VISIBLE);
            openWindowBinding.windowList.setVisibility(View.GONE);
        } else {
            openWindowBinding.noDataText.setVisibility(View.GONE);
            openWindowBinding.windowList.setVisibility(View.VISIBLE);
        }

//        openWindowBinding.nameText.getPaint().setShader(Utility.setTextGradient(OpenWindowActivity.this, openWindowBinding.nameText));

        openWindowBinding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        openWindowBinding.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(OpenWindowActivity.this, R.style.WideDialog);
                DialogDeleteBinding deleteBinding = DialogDeleteBinding.inflate(LayoutInflater.from(OpenWindowActivity.this), null, false);
                dialog.setContentView(deleteBinding.getRoot());
                dialog.setCancelable(false);
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.show();

                deleteBinding.titleText.setText(R.string.alert);
                deleteBinding.msgText.setText(R.string.are_you_sure_to_close_all_window);

                deleteBinding.yesButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        browserManager.closeWindowAll();
                        windows = browserManager.getAllWindow();
                        dialog.dismiss();


                        if (windows.size() == 0) {
                            setResult(123);
                            finish();
                        } else {
                            finish();
                        }


                    }
                });

                deleteBinding.noButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });
        openWindowBinding.windowList.setLayoutManager(new LinearLayoutManager(OpenWindowActivity.this, RecyclerView.VERTICAL, false));

    }
}