package com.photo.video.story.downloader.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;

import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.adapter.HowtoDowPagerAdapter;
import com.google.android.material.tabs.TabLayout;
import com.photo.video.story.downloader.databinding.ActivityHowToDownloadBinding;

@SuppressWarnings("All")
public class HowtoDownload extends BaseActivity {
    private HowtoDowPagerAdapter adapter;
    private ActivityHowToDownloadBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHowToDownloadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        StutasBarbgColor();
        setLightTheme(false);
        TabLayout tabLayout = findViewById(R.id.tabs);
        adapter = new HowtoDowPagerAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        binding.viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(binding.viewPager);
        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.viewPager.getCurrentItem() < adapter.getCount()) {
                    binding.viewPager.setCurrentItem(binding.viewPager.getCurrentItem() + 1);
                }
                if (binding.viewPager.getCurrentItem() == 2) {
                    binding.button1.setVisibility(View.VISIBLE);
                    binding.button.setVisibility(View.GONE);
                } else {
                    binding.button.setVisibility(View.VISIBLE);
                    binding.button1.setVisibility(View.GONE);
                }
            }
        });

        binding.button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.viewPager.getCurrentItem() == 2) {
                    onBackPressed();
                }
            }
        });

        binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 2) {
                    binding.button1.setVisibility(View.VISIBLE);
                    binding.button.setVisibility(View.GONE);
                } else {
                    binding.button.setVisibility(View.VISIBLE);
                    binding.button1.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    private void StutasBarbgColor() {
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.how_color));
    }
}
