package com.ads.mynew;

public interface AdCloseListeners {
    void onAdClosed();
}
