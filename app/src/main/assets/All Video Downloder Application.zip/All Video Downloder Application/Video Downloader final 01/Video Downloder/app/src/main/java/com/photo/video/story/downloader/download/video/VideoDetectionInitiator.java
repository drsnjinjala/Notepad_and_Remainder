package com.photo.video.story.downloader.download.video;

import android.os.Handler;
import android.os.HandlerThread;

import com.photo.video.story.downloader.download.browser.BrowserWindow;

import java.util.ArrayDeque;
import java.util.Queue;

@SuppressWarnings("All")
final public class VideoDetectionInitiator {
    private Queue<VideoSearch> reservedSearches = new ArrayDeque<>();
    private Handler handler;
    private BrowserWindow.ConcreteVideoContentSearch videoContentSearch;

    public VideoDetectionInitiator(BrowserWindow.ConcreteVideoContentSearch concreteVideoContentSearch) {
        HandlerThread thread = new HandlerThread("Video Detect Thread");
        thread.start();
        handler = new Handler(thread.getLooper());

        this.videoContentSearch = concreteVideoContentSearch;


    }

    public void reserve(String url, String page, String title) {
        VideoSearch videoSearch = new VideoSearch();
        videoSearch.url = url;
        videoSearch.page = page;
        videoSearch.title = title;
        reservedSearches.add(videoSearch);
    }

    public void initiate() {
        try {
            while (reservedSearches.size() != 0) {
                VideoSearch search = reservedSearches.remove();
                videoContentSearch.newSearch(search.url, search.page, search.title);
                handler.post(videoContentSearch);
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    public void clear() {
        handler.getLooper().quit();
        HandlerThread thread = new HandlerThread("Video Detect Thread");
        thread.start();
        handler = new Handler(thread.getLooper());
        reservedSearches.clear();
    }

    class VideoSearch {
        String url;
        String page;
        String title;
    }
}
