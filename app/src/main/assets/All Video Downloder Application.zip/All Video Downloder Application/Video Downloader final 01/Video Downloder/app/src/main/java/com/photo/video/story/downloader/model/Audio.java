package com.photo.video.story.downloader.model;
@SuppressWarnings("All")
public class Audio {
    private String Data, title, album, artist,duration,bitrate ;

    public Audio(String data, String title, String album, String artist, String duration, String bitrate ) {
        Data = data;
        this.title = title;
        this.album = album;
        this.artist = artist;
        this.duration = duration;
        this.bitrate  = bitrate ;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getBitrate() {
        return bitrate;
    }

    public void setBitrate(String bitrate) {
        this.bitrate = bitrate;
    }
}

