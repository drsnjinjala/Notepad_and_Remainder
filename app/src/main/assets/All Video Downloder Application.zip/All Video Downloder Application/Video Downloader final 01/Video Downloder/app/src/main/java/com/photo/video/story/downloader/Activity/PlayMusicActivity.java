package com.photo.video.story.downloader.Activity;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.photo.video.story.downloader.adapter.MusicPlayerAdapter;
import com.photo.video.story.downloader.databinding.ActivityPlayMusicBinding;
import com.photo.video.story.downloader.model.Audio;
import com.ads.mynew.NativeAdmobAds;

import java.util.ArrayList;
import java.util.Objects;

@SuppressWarnings("ALl")
public class PlayMusicActivity extends BaseActivity {
    private ArrayList<Audio> audioList;
    private ActivityPlayMusicBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPlayMusicBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadAudioFromLocal();

        new NativeAdmobAds(this).Adaptive_Banner(binding.adBanner);


        binding.imBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void loadAudioFromLocal() {
        ContentResolver contentResolver = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + "!= 0";
        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";
        Cursor cursor = contentResolver.query(uri, null, selection, null, sortOrder);
        if (cursor != null && cursor.getCount() > 0) {
            audioList = new ArrayList<>();
            while (cursor.moveToNext()) {
                try {
                    String data = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                    String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                    String album = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
                    String artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                    String duration = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                    audioList.add(new Audio(data, title, album, artist, duration, ""));
                } catch (Exception e) {
                }
            }
        }
        Objects.requireNonNull(cursor).close();
        MusicPlayerAdapter adapter = new MusicPlayerAdapter(this, audioList, new MusicPlayerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String item) {
                shareAudio(item);
            }

            @Override
            public void SetRingtone(String item) {
                setRingtone(item);
            }
        });
        binding.rvMusicPlayer.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        binding.rvMusicPlayer.setAdapter(adapter);
    }

    private void shareAudio(String path) {
        Uri audioUri = Uri.parse(path);
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("audio/*");
        shareIntent.putExtra(Intent.EXTRA_STREAM, audioUri);

        startActivity(Intent.createChooser(shareIntent, "Share Audio"));
    }

    private void setRingtone(String ringtonePath) {
        try {
            Uri ringtoneUri = Uri.parse(ringtonePath);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(PlayMusicActivity.this)) {
                    Toast.makeText(PlayMusicActivity.this, "Please grant permission to modify system settings", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                    PlayMusicActivity.this.startActivity(intent);
                    return;
                }
            }
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DATA, ringtonePath);
            values.put(MediaStore.MediaColumns.TITLE, "My Ringtone");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/*");
            values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
            Uri newUri = PlayMusicActivity.this.getContentResolver().insert(MediaStore.Audio.Media.getContentUriForPath(ringtonePath), values);
            RingtoneManager.setActualDefaultRingtoneUri(PlayMusicActivity.this, RingtoneManager.TYPE_RINGTONE, newUri);
            Toast.makeText(PlayMusicActivity.this, "Ringtone set successfully", Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Ringtone set successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("TAG", "setRingtone: " + e.getMessage());
            Toast.makeText(this, "Failed to set ringtone", Toast.LENGTH_SHORT).show();
        }
    }
}