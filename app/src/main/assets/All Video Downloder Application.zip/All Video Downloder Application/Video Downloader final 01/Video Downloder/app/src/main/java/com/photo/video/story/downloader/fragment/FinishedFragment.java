package com.photo.video.story.downloader.fragment;

import static com.photo.video.story.downloader.Utils.Utils.RootDirectory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.photo.video.story.downloader.adapter.FileListAdapter;
import com.photo.video.story.downloader.databinding.FragmentFinishedBinding;
import com.ads.mynew.NativeAdsPreload1;

import java.io.File;
import java.util.ArrayList;

@SuppressWarnings("All")
public class FinishedFragment extends Fragment {
    private FragmentFinishedBinding binding;
    private FileListAdapter fileListAdapter;
    private ArrayList<File> fileArrayList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentFinishedBinding.inflate(inflater, container, false);
        NativeAdsPreload1.getInstance(requireActivity()).addNativeAd(binding.nativeAd,false);

        getAllFiles();
        return binding.getRoot();
    }

    private void getAllFiles() {
        fileArrayList = new ArrayList<>();
        File[] files = RootDirectory.listFiles();
        if (files != null) {
            for (File file : files) {
                fileArrayList.add(file);
            }
            fileListAdapter = new FileListAdapter(requireContext(), fileArrayList);
            binding.rvFileList.setAdapter(fileListAdapter);
        }
        if (fileArrayList.size() == 0) {
            binding.noHistory.setVisibility(View.VISIBLE);
        } else binding.noHistory.setVisibility(View.GONE);
    }


}