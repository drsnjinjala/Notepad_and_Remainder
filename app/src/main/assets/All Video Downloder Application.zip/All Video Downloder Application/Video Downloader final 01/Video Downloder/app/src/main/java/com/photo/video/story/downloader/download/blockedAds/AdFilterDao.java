package com.photo.video.story.downloader.download.blockedAds;

import androidx.room.Dao;
import androidx.room.Query;

import java.util.List;

@Dao
public interface AdFilterDao {
    @Query("SELECT * FROM adfilter")
    List<AdFilter> getAll();


}
