package com.photo.video.story.downloader.fragment;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;

import com.photo.video.story.downloader.R;

@SuppressWarnings("All")
public class SliderItemFragment extends Fragment {
    private static final String ARG_POSITION = "slider-position";

    @StringRes
    private static final int[] TITLE_TEXT =
            new int[]{
                    R.string.title_tv_1, R.string.title_tv_2, R.string.title_tv_3
            };
    private static final int[] Des_TEXT =
            new int[]{
                    R.string.dec_1, R.string.dec_2, R.string.dec_3
            };
    @StringRes
    private static final int[] PAGE_IMAGE =
            new int[]{
                    R.drawable.intro_1, R.drawable.intro_2, R.drawable.intro_3
            };

    @StringRes
    private int position;

    public SliderItemFragment() {
        // Required empty public constructor
    }

    public static SliderItemFragment newInstance(int position) {
        SliderItemFragment fragment = new SliderItemFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_POSITION, position);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            position = getArguments().getInt(ARG_POSITION);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_slider_item, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView title = view.findViewById(R.id.Tvtitle);
        TextView Tvdec = view.findViewById(R.id.Tvdec);
        ImageView imageView = view.findViewById(R.id.imageView2);
        title.setText(TITLE_TEXT[position]);
        Tvdec.setText(Des_TEXT[position]);
        imageView.setImageResource(PAGE_IMAGE[position]);

    }
}