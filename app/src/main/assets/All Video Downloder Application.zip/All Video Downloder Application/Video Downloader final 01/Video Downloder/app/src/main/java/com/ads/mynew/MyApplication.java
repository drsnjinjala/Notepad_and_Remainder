package com.ads.mynew;

import android.app.Application;
import android.content.Context;

import androidx.multidex.MultiDex;

import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.messaging.FirebaseMessaging;
import com.onesignal.OneSignal;

public class MyApplication extends Application {

    private static MyApplication instance;
    private Context mContext;

    public static void loadAds(OnInitializationCompleteListener listener) {
        MobileAds.initialize(
                instance,
                initializationStatus -> {
                    listener.onInitializationComplete(initializationStatus);
                    if (new MySavePreference(instance).get_Ad_Status().equalsIgnoreCase("on")) {
                        if (new MySavePreference(instance).getNativeflag().equalsIgnoreCase("on")) {
                            new NativeAdsLoad(instance);
                        }
                        if (new MySavePreference(instance).getFullflag().equalsIgnoreCase("on")) {
                            new InterstitialAdLoad(instance);
                            new InterstitialAdLoadBack(instance);
                        }
                    }
                });
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true);
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        mContext = getApplicationContext();
        String ONESIGNAL_APP_ID = "ffc3c7c8-a6c2-42e8-b3d6-539dbb8b140d";
        OneSignal.setAppId(ONESIGNAL_APP_ID);
        OneSignal.initWithContext(mContext);
        AudienceNetworkAds.initialize(this);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
}
