package com.photo.video.story.downloader.Activity;

import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_MEDIA_AUDIO;
import static android.Manifest.permission.READ_MEDIA_VIDEO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.ads.mynew.MySavePreference;
import com.ads.mynew.NativeAdmobAds;
import com.photo.video.story.downloader.Utils.TinyDB;
import com.photo.video.story.downloader.databinding.ActivityWelcomeBinding;

@SuppressWarnings("All")
public class WelcomeActivity extends BaseActivity {
    private ActivityWelcomeBinding binding;
    private static final int BELOW_ANDROID_13 = 101;
    private static final int ABOVE_ANDROID_13 = 202;
    TinyDB tinyDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWelcomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        tinyDB = new TinyDB(this);

        new NativeAdmobAds(this).Adaptive_Banner(binding.adBanner);

        binding.BtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    ActivityCompat.requestPermissions(WelcomeActivity.this, new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, BELOW_ANDROID_13);
                } else {
                    ActivityCompat.requestPermissions(WelcomeActivity.this, new String[]{READ_MEDIA_VIDEO, READ_MEDIA_AUDIO, POST_NOTIFICATIONS}, ABOVE_ANDROID_13);
                }
            }
        });
    }

    private void nextScreen() {
        GotoNext(WelcomeActivity.this, StartActivity.class);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case BELOW_ANDROID_13:
                boolean gotPermission1 = grantResults.length > 0;
                for (int result : grantResults) {
                    gotPermission1 &= result == PackageManager.PERMISSION_GRANTED;
                }
                if (gotPermission1) {
                    nextScreen();
                } else {
                    Toast.makeText(WelcomeActivity.this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
                break;
            case ABOVE_ANDROID_13:
                boolean gotPermission2 = grantResults.length > 0;
                for (int result : grantResults) {
                    gotPermission2 &= result == PackageManager.PERMISSION_GRANTED;
                }
                if (gotPermission2) {
                    nextScreen();
                } else {
                    Toast.makeText(WelcomeActivity.this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public void privacyDialog(View view) {
        MySavePreference preference = new MySavePreference(this);
        final Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(preference.get_Privacy_Policy()));
        startActivity(intent);
    }
}