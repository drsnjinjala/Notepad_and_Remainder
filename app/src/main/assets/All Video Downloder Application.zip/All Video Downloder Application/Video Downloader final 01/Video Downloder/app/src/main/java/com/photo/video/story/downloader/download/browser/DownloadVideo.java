package com.photo.video.story.downloader.download.browser;

import java.io.Serializable;

@SuppressWarnings("All")
public class DownloadVideo implements Serializable {
    public String size, type, link, name, page, website;
    public boolean chunked;
}
