package com.photo.video.story.downloader.adapter;


import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.photo.video.story.downloader.fragment.FinishedFragment;
import com.photo.video.story.downloader.fragment.ProgressFragment;
import com.photo.video.story.downloader.fragment.TabFragment;

@SuppressWarnings("All")
public class MyAdapter extends FragmentPagerAdapter {
    private Context myContext;
    int totalTabs;
    public MyAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                TabFragment homeFragment = new TabFragment();
                return homeFragment;
            case 1:
                ProgressFragment sportFragment = new ProgressFragment();
                return sportFragment;
            case 2:
                FinishedFragment movieFragment = new FinishedFragment();
                return movieFragment;
            default:
                return null;
        }
    }
    @Override
    public int getCount() {
        return totalTabs;
    }
}