package com.photo.video.story.downloader.adapter;

import android.app.Activity;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.story.downloader.R;
import com.photo.video.story.downloader.databinding.MusicItemBinding;
import com.photo.video.story.downloader.model.Audio;

import java.io.IOException;
import java.util.ArrayList;

@SuppressWarnings("All")
public class MusicPlayerAdapter extends RecyclerView.Adapter<MusicPlayerAdapter.ViewHolder> {
    private Activity activity;
    private ArrayList<Audio> audioList;
    private OnItemClickListener listener;
    private int playingPosition = -1;
    private MediaPlayer mediaPlayer;
    public MusicPlayerAdapter(Activity activity, ArrayList<Audio> audioList, OnItemClickListener itemClickListener) {
        this.activity = activity;
        this.audioList = audioList;
        this.listener = itemClickListener;
        mediaPlayer = new MediaPlayer();
    }

    @NonNull
    @Override
    public MusicPlayerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MusicItemBinding itemBinding = MusicItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(itemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull MusicPlayerAdapter.ViewHolder holder, int position) {
        if (playingPosition == holder.getAdapterPosition()) {
            holder.binding.imgMusicPlayer.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_music_stop));
        } else {
            holder.binding.imgMusicPlayer.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_play_circle_filled_black_24dp));
        }
        holder.binding.TvName.setText(audioList.get(position).getTitle().toString().trim());
        holder.binding.Tvartist.setText(audioList.get(position).getArtist().toString().trim());
        holder.binding.TvTime.setText(millisecondsToTime(Long.parseLong(audioList.get(position).getDuration())));

        holder.binding.btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                listener.onItemClick(audioList.get(position).getData());
            }
        });
        holder.binding.btnNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.SetRingtone(audioList.get(position).getData());
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    if (playingPosition == holder.getAdapterPosition()) {
                        stopPlayback();
                        holder.binding.imgMusicPlayer.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_play_circle_filled_black_24dp));
                    } else {
                        playAudio(audioList.get(holder.getAdapterPosition()).getData());
                        holder.binding.imgMusicPlayer.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_music_stop));
                        playingPosition = holder.getAdapterPosition();
                    }
                } else {
                    playAudio(audioList.get(holder.getAdapterPosition()).getData());
                    holder.binding.imgMusicPlayer.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_music_stop));
                    playingPosition = holder.getAdapterPosition();
                }
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return audioList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(String item);

        void SetRingtone(String item);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private MusicItemBinding binding;

        public ViewHolder(MusicItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public String millisecondsToTime(Long millie) {
        if (millie != null) {
            long seconds = (millie / 1000);
            long sec = seconds % 60;
            long min = (seconds / 60) % 60;
            long hrs = (seconds / (60 * 60)) % 24;
            if (hrs > 0) {
                return String.format("%02d:%02d:%02d", hrs, min, sec);
            } else {
                return String.format("%02d:%02d", min, sec);
            }
        } else {
            return null;
        }
    }

    private void playAudio(String filePath) {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(filePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopPlayback() {
        mediaPlayer.stop();
        mediaPlayer.reset();
    }


}
