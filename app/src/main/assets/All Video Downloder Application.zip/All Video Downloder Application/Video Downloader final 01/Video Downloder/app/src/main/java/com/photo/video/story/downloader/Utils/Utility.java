package com.photo.video.story.downloader.Utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import com.photo.video.story.downloader.R;
import com.google.android.material.color.MaterialColors;

import java.io.File;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

@SuppressWarnings("All")
public class Utility {
    public static boolean isConverter = false;

    public static void hideNavigation(Activity activity) {
        View decorView = activity.getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    public static String getFileName(String fileName) {
        return fileName.split("\\.")[0];
    }

    public static boolean isMarshmallow() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    public static String getFileExtension(String fileName) {
        String fileNameArray[] = fileName.split("\\.");
        return fileNameArray[fileNameArray.length - 1];

    }

    public static String getNameFromFile(String name) {
        if (name.indexOf(".") > 0) name = name.substring(0, name.lastIndexOf("."));
        return name;
    }

    public static long getFilePathToMediaID(String videoPath, Context context) {
        long id = 0;
        ContentResolver cr = context.getContentResolver();

        Uri uri = MediaStore.Files.getContentUri("external");
        String selection = MediaStore.Video.Media.DATA;
        String[] selectionArgs = {videoPath};
        String[] projection = {MediaStore.Video.Media._ID};
        String sortOrder = MediaStore.Video.Media.TITLE + " ASC";

        Cursor cursor = cr.query(uri, projection, selection + "=?", selectionArgs, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(MediaStore.Video.Media._ID);
                id = Long.parseLong(cursor.getString(idIndex));
            }
        }

        return id;
    }

    public static long getFilePathToMediaIDAudio(String songPath, Context context) {
        long id = 0;
        ContentResolver cr = context.getContentResolver();

        Uri uri = MediaStore.Files.getContentUri("external");
        String selection = MediaStore.Audio.Media.DATA;
        String[] selectionArgs = {songPath};
        String[] projection = {MediaStore.Audio.Media._ID};
        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";

        Cursor cursor = cr.query(uri, projection, selection + "=?", selectionArgs, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
                id = Long.parseLong(cursor.getString(idIndex));
            }
        }

        return id;
    }


    public static boolean appInstalledOrNot(Context context, String uri) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed = false;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
            Log.e("pm", "appInstalledOrNot: " + pm + "  " + uri);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("TAG ", "appInstalledOrNot: " + e.getMessage());
            app_installed = false;
        }
        return app_installed;
    }

    public static String getFormatType(String path) {
        FileNameMap fileNameMap = URLConnection.getFileNameMap();
        String mime = fileNameMap.getContentTypeFor("file://" + path);
        return mime;
    }

    public static String getModifiedDateString(String longDate) {
        return (String) DateFormat.format("dd/MM/yyyy hh:mm:ss", new Date(Long.parseLong(longDate)));
    }

    public static String getModifiedDateString(long longDate) {
        return (String) DateFormat.format("dd/MM/yyyy", new Date(longDate));
    }

    public static String getFileNameFromPath(String path) {
        if (path == null) return "Unknown File";
        int i = path.lastIndexOf("/");
        if (i == 0) return path;
        return path.substring(i);

    }

    public static boolean isServiceRunning(Class<?> serviceClass, Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void disableSSLCertificateChecking() {
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            @SuppressLint("TrustAllX509TrustManager")
            @Override
            public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

            }

            @SuppressLint("TrustAllX509TrustManager")
            @Override
            public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

            }
        }};

        try {
            SSLContext sc = SSLContext.getInstance("TLS");

            sc.init(null, trustAllCerts, new java.security.SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @SuppressLint("BadHostnameVerifier")
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (KeyManagementException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    public static void hideSoftKeyboard(Activity activity, IBinder token) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && token != null) {
            inputMethodManager.hideSoftInputFromWindow(token, 0);
        }
    }

    public static int[] getGradientColor(Context context) {
        int[] shaderColor = new int[]{MaterialColors.getColor(context, R.attr.gradientColo1, context.getResources().getColor(R.color.color01)), MaterialColors.getColor(context, R.attr.gradientColo2, context.getResources().getColor(R.color.color02)), MaterialColors.getColor(context, R.attr.gradientColo3, context.getResources().getColor(R.color.color03))};
        return shaderColor;
    }


    public static Shader setTextGradient(Context context, TextView txt) {
        Shader textShader = new LinearGradient(0, 0, txt.getPaint().measureText(txt.getText().toString()), txt.getTextSize(), getGradientColor(context), null, Shader.TileMode.REPEAT);
        return textShader;
    }

    public static long getDuration(Context context,/* Uri uri*/File path) {
        int duration = 0;
        Uri uri = getRealUri(context, path);
        ;
        MediaPlayer mp = MediaPlayer.create(context, uri);
        if (mp != null) {
            duration = mp.getDuration();
        }
        return duration;
    }

    public static Uri getRealUri(Context context, File file) {
        Uri uri;
        if (Build.VERSION.SDK_INT > 21) {
            uri = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", file);
        } else {
            uri = Uri.fromFile(file);
        }
        return uri;
    }

}
