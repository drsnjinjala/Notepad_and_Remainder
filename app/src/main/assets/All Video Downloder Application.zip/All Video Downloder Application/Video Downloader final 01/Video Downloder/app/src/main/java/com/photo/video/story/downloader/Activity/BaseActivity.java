package com.photo.video.story.downloader.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;

import androidx.appcompat.app.AppCompatActivity;

import com.ads.mynew.InterstitialAdLoad;
import com.ads.mynew.InterstitialAdLoadBack;
import com.photo.video.story.downloader.R;

import java.util.Random;

@SuppressWarnings("All")
public class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StutasBarbgColor();
        setLightTheme(true);
        hideNavigationBar(false);
    }

    public static int getRandomnumber(int i, int i1) {
        Random random = new Random();
        int randomNumber = random.nextInt(i1) + i; // Generates 2 to 9
        System.out.println("Random number between 2 and 9: " + randomNumber);
        return randomNumber;
    }

    public static void GotoNext(Activity activity, Class<?> aClass) {
        InterstitialAdLoad.ShowfullAd(activity, () -> {
            activity.startActivity(new Intent(activity, aClass));

        });
    }

    public static void GotoBack(Activity activity) {
        InterstitialAdLoadBack.ShowfullAd(activity, () -> {
            activity.finish();
        });
    }
    private void StutasBarbgColor() {
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.white));
    }

    @Override
    public void onBackPressed() {
        GotoBack(this);
    }

    void setLightTheme(boolean b) {
        if (b) {
            View decor = getWindow().getDecorView();
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } else {
            View decor = getWindow().getDecorView();
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    }

    void hideNavigationBar(boolean b) {
        if (b) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean isNetworkAvailable(Activity context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}