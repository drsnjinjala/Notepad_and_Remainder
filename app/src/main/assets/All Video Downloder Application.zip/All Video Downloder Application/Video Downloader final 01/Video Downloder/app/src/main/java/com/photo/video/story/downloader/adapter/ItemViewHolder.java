package com.photo.video.story.downloader.adapter;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.story.downloader.R;

@SuppressWarnings("All")
public class ItemViewHolder extends RecyclerView.ViewHolder {
    public ImageButton save;
    public ImageView imageView;

    public ItemViewHolder(@NonNull View itemView) {
        super(itemView);

        imageView = itemView.findViewById(R.id.ivThumbnail);
        save = itemView.findViewById(R.id.save);
    }
}